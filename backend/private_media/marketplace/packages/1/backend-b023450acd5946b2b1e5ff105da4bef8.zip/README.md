# Story Publishing Platform (Django + React)

Roadmap progress: **Phase 2** (Django foundation), **Phase 3** (accounts, auth, permissions, rate limiting) and **Phase 4** (Story CMS backend) and **Phase 5** (media system).
The React frontend arrives in later phases.

## What is here
- `backend/` Django 5.2 + DRF, project `config` (split settings: base / development / production)
- `backend/apps/accounts` custom email-based `User`, `Profile`, auth API, django-allauth (Google), lockout throttle
- `backend/apps/core` response envelope, permissions, health + admin ping endpoints
- `backend/apps/stories` stories, categories, tags, revisions, content schema, admin API (Phase 4)
- `backend/apps/media` image library: upload validation, gallery API, storage (Phase 5)
- `backend/apps/{comments,reactions,analytics,audit}` empty skeletons for later phases

## First time setup

**1. Redis (required).** It holds the rate-limit counters and is the Celery broker. Install it on your machine:

```bash
# macOS
brew install redis && brew services start redis
# Ubuntu / Debian
sudo apt install redis-server && sudo systemctl enable --now redis-server
# Windows: use WSL2 (Ubuntu) and run the Ubuntu commands above
redis-cli ping        # must answer PONG
```

**2. PostgreSQL (optional in development).** If `DATABASE_URL` is empty the app uses SQLite (`backend/db.sqlite3`) automatically,
so you can skip this. To use PostgreSQL, install it, create the database, and set `DATABASE_URL` in `backend/.env`:

```bash
sudo -u postgres psql -c "CREATE USER story WITH PASSWORD 'story';"
sudo -u postgres createdb -O story story_platform
# backend/.env:  DATABASE_URL=postgresql://story:story@localhost:5432/story_platform
```

**3. Backend**

```bash
# Python environment
cd backend
python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                # Windows: copy .env.example .env

# Database
python manage.py migrate
python manage.py create_admin you@example.com    # asks for the password (hidden)

# Run
python manage.py runserver
```

### Reset the database (needed once when upgrading from Phase 2: the user table changed)
```bash
# PostgreSQL:  dropdb story_platform && createdb story_platform     (add -U story or use sudo -u postgres to match your setup)
# SQLite:      rm backend/db.sqlite3
cd backend
python manage.py migrate
python manage.py create_admin you@example.com
```

### After changing models
```bash
python manage.py makemigrations
python manage.py migrate
```

### Tests (no Redis, Postgres, Google or SMTP needed)
```bash
pytest
```

## Environment variables (backend/.env)

| Variable | Purpose |
|---|---|
| `DJANGO_SECRET_KEY`, `DJANGO_DEBUG`, `DJANGO_ALLOWED_HOSTS` | core Django |
| `DATABASE_URL` or `DB_*` | PostgreSQL (empty in development = SQLite) |
| `REDIS_URL` | cache (throttle counters) + Celery broker |
| `FRONTEND_URL` | CORS/CSRF origin, email links, Google redirects |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google login (empty = Google login disabled, nothing crashes) |
| `SITE_NAME`, `DEFAULT_FROM_EMAIL` | email text |
| `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_HOST_USER`, `EMAIL_HOST_PASSWORD`, `EMAIL_USE_TLS` | production email (development prints emails in the terminal) |
| `NUM_PROXIES` | reverse proxies in front of Django. **Set to 1 behind Nginx**, otherwise every visitor shares one IP in rate limits |
| `THROTTLE_LOGIN` etc. | optional rate overrides, e.g. `THROTTLE_LOGIN=20/min`; the public read API uses `THROTTLE_PUBLIC_READ` (default `120/min` per IP) |

## Google Cloud setup
1. Google Cloud Console -> **APIs & Services -> Credentials -> Create credentials -> OAuth client ID -> Web application**.
2. **Authorized JavaScript origins:** `http://localhost:5173`
3. **Authorized redirect URI:** `http://localhost:8000/accounts/google/login/callback/`
   (in production use your real API domain with the same path).
4. Put the client ID and secret in `backend/.env`.

### Starting Google login from React
allauth requires a **POST**. The React app submits a real HTML form so the browser follows the redirects:

```js
function loginWithGoogle() {
  const csrf = document.cookie.split("; ").find((c) => c.startsWith("csrftoken="))?.split("=")[1];
  const form = document.createElement("form");
  form.method = "POST";
  form.action = "/accounts/google/login/";   // proxied to Django in development
  for (const [name, value] of [["csrfmiddlewaretoken", csrf], ["process", "login"]]) {
    const input = document.createElement("input");
    input.type = "hidden"; input.name = name; input.value = value;
    form.appendChild(input);
  }
  document.body.appendChild(form);
  form.submit();
}
```
After Google, the browser returns to `FRONTEND_URL`; on failure to `FRONTEND_URL/login?error=google`.
Call `GET /api/v1/auth/csrf/` once on app start so the `csrftoken` cookie exists.
In development the Vite dev server must proxy both `/api` and `/accounts` to `http://localhost:8000`.

## API (all under /api/v1/, every response is `{data, pagination, errors, message}`)

| Method + path | Auth | What it does |
|---|---|---|
| GET `auth/csrf/` | none | sets the CSRF cookie |
| POST `auth/register/` | none | email, password (min 10), display_name -> creates user, logs in, sends verification email |
| POST `auth/login/` | none | email, password. Same error for unknown email and wrong password |
| POST `auth/logout/` | session + CSRF | ends the session |
| GET `auth/me/` | none | the user, or `{"data": null}` |
| PATCH `auth/me/` | login | `display_name`, `bio` only |
| POST `auth/email/verify/` | none | `{key}` from the email link |
| POST `auth/email/resend/` | login | resend verification |
| POST `auth/password/reset/` | none | `{email}`; identical answer for any email |
| POST `auth/password/reset/confirm/` | none | `{uid, token, password}` |
| GET `admin/ping/` | staff | permission smoke test |

## Security notes
- Session cookie (HttpOnly, SameSite=Lax, 14 days) + CSRF token. No JWT, nothing in localStorage.
- Failed logins: after 5 failures per email+IP in 15 minutes -> 429 with `Retry-After`. A good login clears it.
- Other limits: login 10/min, register 10/hour, password reset 5/hour, email resend 5/hour, profile update 30/hour.
- Only superusers may create or remove staff (`create_admin`, or Admin > Users). Public sign-up never creates staff.
- Never commit `.env`. Never log passwords, tokens or reset links.

## Phase 4: Story CMS (admin API)

Stories are TipTap JSON, validated by an allowlist (`docs/CONTENT_SCHEMA.md`). Only staff can use these endpoints.

```bash
cd backend
python manage.py makemigrations stories     # no-op if the shipped 0001 migration already matches
python manage.py migrate
python manage.py runserver
pytest
```
No database reset is needed. Optional: `python manage.py publish_scheduled` (also runs as a Celery beat task every minute).

| Method + path (under `/api/v1/admin/`) | What it does |
|---|---|
| GET `stories/` | paginated list (12), no content. Filters `status`, `q`, `category` (slug), `tag` (slug), `featured=1`, `ordering` |
| POST `stories/` | create a **draft** (revision 1) |
| GET / PATCH / DELETE `stories/{id}/` | read, partial update (`?autosave=1` limits revisions), hard delete |
| POST `stories/{id}/publish/` `unpublish/` `archive/` | status changes (publish refuses empty stories) |
| POST `stories/{id}/schedule/` | `{"scheduled_at": "<future ISO datetime>"}` |
| GET `stories/{id}/revisions/` | revision history, newest first |
| POST `stories/{id}/revisions/{rev}/restore/` | copy an old revision back (as a new revision) |
| GET / POST `categories/`, `tags/` | lists with `story_count` (not paginated); tags accept `?q=` |
| GET / PATCH / DELETE `categories/{id}/`, `tags/{id}/` | deleting only unlinks stories |

Rules: `status`, `published_at`, `scheduled_at` and the counters can never be set through create or PATCH; slugs are
unique and stay stable when the title changes; category and tag names are unique ignoring case.

## Phase 5: Media system (image library)

Staff upload images once and reuse them in many stories. Full details: `docs/MEDIA.md`.

```bash
cd backend
python manage.py makemigrations media stories   # no-op if the shipped migrations already match
python manage.py migrate
python manage.py runserver
pytest
```
No database reset needed. New migrations: `media/0001` and `stories/0002` (adds `Story.cover_image`).

| Method + path (under `/api/v1/admin/`) | What it does |
|---|---|
| POST `media/` | upload 1-10 images (`files`), validated all-or-nothing |
| GET `media/` | gallery (24 per page, `?q=`, `?ordering=`) |
| GET / PATCH / DELETE `media/{id}/` | detail with `used_in`; edit alt text and caption; delete (blocked while in use, `?force=1`) |
| POST `media/{id}/replace/` | new file, same id |

Stories now accept `cover_image` (a media id) and return `cover`. Saving content with an image that is not in the
library is rejected.

New environment variables: `MEDIA_MAX_UPLOAD_BYTES`, `MEDIA_STORAGE_BUCKET`, `MEDIA_STORAGE_REGION`,
`MEDIA_STORAGE_ACCESS_KEY`, `MEDIA_STORAGE_SECRET_KEY`, `MEDIA_STORAGE_ENDPOINT`, `MEDIA_CDN_DOMAIN`,
`THROTTLE_MEDIA_UPLOAD`. Leave the `MEDIA_STORAGE_*` ones empty to keep files on local disk.
Optional local object storage: run MinIO directly on your machine (see `docs/MEDIA.md`).

---

## Phase 6 — React admin frontend and rich story editor (`frontend/`)

React 18 + Vite + React Router 6 + TanStack Query 5 + TipTap 2. Admin only: login, story list, media library, the story
editor with autosave and revisions, and preview. The public website arrives in Phase 7.

### Run frontend and backend together

Two terminals:

```bash
# 1) backend  (from backend/, with your virtualenv active; see the Phase 2-5 sections above)
python manage.py migrate
python manage.py create_admin          # a staff account to log in with
python manage.py runserver             # http://localhost:8000

# 2) frontend (from frontend/)
npm install
npm run dev                            # http://localhost:5173  <- open THIS address
npm test                               # unit tests (Vitest)
npm run build                          # production build into frontend/dist
```

Open **http://localhost:5173** and log in with a staff account. Normal reader accounts are refused ("Staff access only").

### The dev proxy (why there is no CORS setup)

`vite.config.js` forwards `/api`, `/accounts` and `/media` to Django (`http://localhost:8000`, change it with
`VITE_BACKEND_URL` in `frontend/.env`). The browser only ever talks to `localhost:5173`, so the Django session and CSRF
cookies are same-origin and work with no CORS or cookie tricks. Uploaded images (`/media/...`) load through the same proxy.
The API client sends cookies (`withCredentials`) and copies the `csrftoken` cookie into the `X-CSRFToken` header; the app calls
`GET /api/v1/auth/csrf/` once on start. No token or password is stored anywhere in the browser.

The frontend route guard (`RequireStaff`) is a convenience. The real protection is that every `/api/v1/admin/*` endpoint checks `is_staff` on the server.

### How the editor relates to the content schema

The server stores story content as JSON and **rejects anything outside the schema** in `docs/CONTENT_SCHEMA.md`. The editor is built so it cannot produce anything else:

- `src/editor/extensions.js` is the schema: StarterKit with `codeBlock` and `code` switched off, Underline, Link (http/https/mailto only), TextAlign, Placeholder, and two custom nodes, `image` and `youtube`. Anything not loaded cannot be typed, pasted or produced by a shortcut.
- **Clean paste:** pasted HTML is parsed only through those extensions. Tables, scripts, styles, classes, stray `<img>` tags and `javascript:` links do not survive. Only an `image` that carries one of our own `data-asset-id` figures is accepted, so nothing outside the media library can enter a story.
- `src/editor/schema.js` has `toServerDoc()` (editor JSON → API: whitelists attributes on every node and mark, strips the display-only `src`/`width`/`height` of images, keeps only `href` on links) and `fromServerDoc()` (API → editor, keeps the `src` the server resolved so the picture shows).
- `youtube` stores only the 11-character `videoId`; the iframe is generated from it (`youtube-nocookie.com`). Extraction uses the same rules as the server (`src/utils/youtube.js`).
- `src/components/StoryRenderer.jsx` renders the JSON as React elements with a `switch` over node types: no raw-HTML injection, unknown nodes render nothing, only http/https/mailto links, `rel="noopener noreferrer nofollow"`. Preview uses it now; Phase 7 reuses it for the public site.

### How autosave works

1. Every edit restarts a **3 second** timer (`src/hooks/useAutosave.js`). When it fires, only the fields that differ from the last server-confirmed copy are sent: `PATCH /api/v1/admin/stories/{id}/?autosave=1`.
2. **One request at a time.** Autosave and the manual Save share one queue. A save that starts always reads the latest data, so edits made while one is in flight go out in the next one.
3. The status shows **Saving…**, **Saved 12:41**, or **Autosave failed — retrying…**. Network/server errors retry with backoff (3 s, 6 s, 12 s … up to 30 s); local changes are never discarded. Validation or permission errors (400/401/403/404) do not retry, they are shown on the fields.
4. **Save** / **Save draft** does a normal PATCH (without `?autosave=1`). A **new** story has no id yet, so autosave is off; the first Save does a `POST`, then the page moves to `/admin/stories/:id/edit`.
5. A copy of the unsaved form is kept in `sessionStorage` per story id (this tab only). If the tab crashes or reloads, the next visit offers **Restore** when that copy is newer than the server's.
6. Leaving with unsaved changes asks first (browser prompt on reload/close, a dialog on in-app navigation).
7. **Published stories are not autosaved.** Autosave writes straight to the story, so on a live story it would publish half-finished edits. Use **Save changes** there. Drafts, scheduled and archived stories autosave normally.

### Frontend layout

```
frontend/src
  api/          axios client (err.friendly, err.fieldErrors) + one function per endpoint
  auth/         AuthContext, RequireStaff
  layouts/      AdminLayout
  pages/        LoginPage, NotFoundPage, admin/{StoryList,StoryEdit,StoryPreview,Media}Page
  components/   StoryRenderer, Modal, ConfirmDialog, ErrorBoundary, TagsInput, RevisionsDrawer, media/*
  editor/       StoryEditor, Toolbar, ImageNode, YoutubeNode, extensions, schema, dialogs
  hooks/        useAutosave
  utils/        youtube, links, autosave helpers, stats, draftStore, format
  __tests__/    Vitest tests for the pure logic and the renderer
```


---

## Phase 7 — Public website

The reader-facing site: home, story list, story page, categories, tags, search, related stories and SEO metadata.
Admin (`/admin`) and login (`/login`) are unchanged.

### Public routes (React)

| Route | Page |
|---|---|
| `/` | Home: intro, hero (latest featured story), latest stories, categories, popular tags |
| `/stories` | All stories, filters `?category=` and `?tag=`, `?page=` |
| `/stories/:slug` | Story: cover, text, tags, share buttons, related stories |
| `/categories`, `/categories/:slug` | Category index and one category |
| `/tags`, `/tags/:slug` | Tag index and one tag |
| `/search?q=` | Search results (needs 2 to 100 characters) |
| anything else | Public 404 page |

Every list page has loading skeletons, an empty state and an error state with a **Try again** button. A story that is missing or
not public shows the 404 page.

### Public API (Django)

Eight read-only endpoints, no login, GET only: `/api/v1/stories/`, `/stories/{slug}/`, `/stories/{slug}/related/`, `/categories/`,
`/categories/{slug}/stories/`, `/tags/`, `/search/?q=` and `/sitemap-data/`. The full list of parameters and response fields is in
[`docs/PUBLIC_API.md`](docs/PUBLIC_API.md). The important rules:

- Everything goes through `Story.objects.public()` (published **and** `published_at` in the past). Drafts, scheduled, archived and
  future-dated stories never appear anywhere, and asking for one gives 404 (not 403).
- Separate public serializers with an explicit field list. Status, scheduled time, user ids/emails, counters, revisions and
  `search_text` are never sent.
- Own rate limit `public_read` (120/min per IP, `THROTTLE_PUBLIC_READ`), replacing the site-wide anonymous limit of 100/hour.
- Lists use a fixed number of queries (tested).

Backend tests for it are in `backend/tests/test_public_api.py` (run with the rest: `pytest`).

### SEO approach and its limits

This is a single-page app (Vite + React). Each page sets its own `<title>`, description, canonical link, robots, Open Graph and
Twitter tags, and the story page adds a JSON-LD `Article` block, from the browser with `useDocumentMeta`
(`src/hooks/useDocumentMeta.js`). JSON-LD is written as text with `<` escaped, never as HTML. The admin and login pages send `noindex`,
search results and filtered/paged lists send `noindex,follow`. `public/robots.txt` allows the site and blocks `/admin` and `/login`.

Limits you should know about:

- **Google runs JavaScript** and will normally read these tags, but later and less reliably than plain HTML.
- **Link previews do not.** WhatsApp, Facebook, X, Slack and similar read only the HTML the server sends, so a shared story link will
  show the generic site title and no cover image. This is the biggest practical weakness of a client-side SPA.
- **The upgrade path is pre-rendering or server-side rendering**: for example rendering story pages on the server (a Node SSR step
  or a framework such as Next.js) or pre-rendering each story to static HTML when it is published, so the right tags are in the first response.
  The public API and `StoryRenderer` were written so they can be reused for that.
- **Sitemap:** `GET /api/v1/sitemap-data/` returns `[{slug, updated_at}]` for all public stories (cached 5 minutes). A small generator
  (a management command or a scheduled job) can turn it into `sitemap.xml` with `https://YOUR-DOMAIN/stories/<slug>` entries. That
  generator is not built yet. Until then, remove or edit the `Sitemap:` line in `frontend/public/robots.txt`, and set the real domain there when you deploy.

### Run it

```bash
# terminal 1: backend (from backend/)
python manage.py migrate && python manage.py runserver
# terminal 2: frontend (from frontend/)
npm install && npm run dev        # open http://localhost:5173
```

The public site is the home page (`/`). Publish a story in the admin first (it needs `status = published`), otherwise the public pages will
correctly show nothing. Set the site name with `VITE_SITE_NAME` in `frontend/.env`.

## Phase 8 — Reader engagement (likes, comments, moderation, accounts)

Readers can sign up, like stories and comment; staff moderate. Full reference: [`docs/ENGAGEMENT.md`](docs/ENGAGEMENT.md).

### What is new

- **Backend:** `apps/reactions` (likes) and `apps/comments` (comments, reports, moderation, the `comment_moderation` site
  setting), `GET /api/v1/auth/providers/`, the command `python manage.py recount_engagement`, new throttle scopes
  (`like`, `comment`, `report`). Public story list/detail gained `like_count` and `comment_count`; the detail also has
  `liked_by_me` for logged-in readers (see `docs/PUBLIC_API.md`).
- **Frontend:** `/register`, `/forgot-password`, `/reset-password`, `/verify-email`, `/account`; `/login` now works for readers
  too; header with Log in / Sign up or a name menu; like button; comments with replies, edit, delete, report; the signup prompt;
  admin `/admin/comments` with a pending badge in the sidebar.

### Upgrading from Phase 7

```bash
cd backend
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt   # nothing new, safe to run
python manage.py migrate          # creates the likes, comments, reports and settings tables
```
Optional in `backend/.env`: `COMMENT_EDIT_WINDOW_MINUTES`, `COMMENT_BLOCKED_WORDS`, `THROTTLE_LIKE`, `THROTTLE_COMMENT`,
`THROTTLE_REPORT` (see `backend/.env.example`). Choose the moderation mode in **Admin > Comments**.

### Run the tests

```bash
# backend (no Redis, Postgres, Google or SMTP needed)
cd backend && source .venv/bin/activate && pytest

# frontend
cd frontend && npm install && npm test
```

### Run the app (Redis must be running)

```bash
# terminal 1: Redis (start it your usual way, e.g. `redis-server`, or the Windows/macOS service)
# terminal 2: backend
cd backend && source .venv/bin/activate && python manage.py runserver     # http://localhost:8000
# terminal 3: frontend
cd frontend && npm run dev                                                   # http://localhost:5173
```

### Things worth knowing

- A reader must **verify their email** to comment; the link in the email goes to `/verify-email?key=...`.
  In development emails are printed in the backend terminal.
- "Continue with Google" is hidden until `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` are set. It starts the login with a form
  POST (allauth requires it), see "Starting Google login from React" above.
- The count shown on story cards and pages is a stored counter kept correct with atomic updates; if you ever edit rows by hand,
  run `python manage.py recount_engagement`.
- Not in this phase (Phases 9 and 10): analytics and page-view tracking, user management, audit logs, cookie-consent screens.

## Phase 9 — Analytics (visitors, page views, reports)

Anonymous, privacy-minimal visitor counting with an admin dashboard. Full reference: [`docs/ANALYTICS.md`](docs/ANALYTICS.md).

### What is new

- **Backend:** `apps/analytics` (visitor and page-view tables, `POST /api/v1/analytics/collect/`, daily/weekly/monthly aggregation, retention purge,
  staff-only `GET /api/v1/admin/analytics/{overview,daily,stories,traffic}/`), new throttle scope `analytics`, Celery beat jobs.
- **Frontend:** a tracker in the public layout (one page view per route change), a footer "Analytics: on / off" switch, the `/privacy` page, and the admin
  page `/admin/analytics` (range and grouping controls, tiles with change versus the previous period, two SVG charts with a table fallback, top stories, referrers, devices).
- **Privacy:** no cookies; the browser id is stored hashed; raw IPs and user-agent strings are never stored; Do Not Track and Global Privacy Control are respected;
  bots, staff, the admin and auth pages are not counted; raw events are deleted after 90 days. This is a notice plus an opt-out, not a consent banner.

### Upgrading from Phase 8

```bash
cd backend
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt   # nothing new, safe to run
python manage.py migrate          # creates the analytics tables
```
Optional in `backend/.env`: `ANALYTICS_ENABLED`, `ANALYTICS_DEDUPE_MINUTES`, `ANALYTICS_RETENTION_DAYS`, `ANALYTICS_HASH_SECRET`, `THROTTLE_ANALYTICS`.
Set `NUM_PROXIES` correctly behind a proxy, otherwise the collect throttle sees one IP for all visitors.

### Run the aggregation and purge

```bash
cd backend && source .venv/bin/activate
python manage.py aggregate_analytics                                   # yesterday and today
python manage.py aggregate_analytics --from 2026-01-01 --to 2026-03-31 # back-fill (safe to repeat)
python manage.py purge_analytics --dry-run                             # what would be deleted
python manage.py purge_analytics                                       # aggregates first, then deletes old raw events
```
Without Celery the dashboard refreshes today's numbers itself; run the commands for older days. With Celery (Redis running):
`celery -A config worker -l info` and `celery -A config beat -l info` run the aggregation every 15 minutes, close the previous day/week/month
at 00:10 UTC and purge at 03:30 UTC.

### Run the tests

```bash
# backend (no Redis, Postgres, Google or SMTP needed)
cd backend && source .venv/bin/activate && pytest

# frontend
cd frontend && npm install && npm test
```

### Things worth knowing

- Open a few public stories, then run `python manage.py aggregate_analytics` (or just open **Admin > Analytics**). Your own visits are not counted while you are logged in as staff;
  use a private window, or switch to a non-staff account, to try it.
- Days are UTC and weeks start on Monday.
- Security hardening, audit logs, user management, MFA and the full privacy policy arrived in Phase 10 (below).

## Phase 10 — Security and privacy

The full reference is **`docs/SECURITY.md`** (threat model, audit findings, headers and the Nginx CSP, rate limits, endpoint
inventory, MFA procedures, audit events, retention, pre-deployment checklist, known limits).

What was added:

- **Production guard**: with `config.settings.production` the server refuses to start without a long real secret key, `DEBUG` off,
  real hosts, `https://` origins and PostgreSQL. `manage.py check --deploy` is clean.
- **Headers**: nosniff, referrer policy, permissions policy, COOP, frame denial, HSTS (production) and a Content-Security-Policy
  (`CSP_REPORT_ONLY=true` for a trial run) with a report receiver at `POST /api/v1/csp-report/`. The CSP for the React app is a
  ready-to-paste Nginx snippet in `docs/SECURITY.md`.
- **Sessions and passwords**: reset links last 1 hour, verification links 3 days; the session id rotates on login, logout and
  password change; changing the password signs out other devices; staff sessions end after `STAFF_SESSION_IDLE_MINUTES` (120)
  idle; **Account > Security** lists your devices and has "Sign out of all devices".
- **No account enumeration**: sign-up answers "check your email" for new and existing addresses alike (a deliberate change: registering no
  longer logs you in; you log in after verifying).
- **Two-step verification (TOTP) for staff**, standard library only, optional by default, mandatory with `STAFF_MFA_REQUIRED=true`.
  Enforced in the permission layer, so Google login or a stolen cookie cannot skip it. 10 recovery codes shown once.
- **Audit log** (`Admin > Audit log`): append-only record of story, taxonomy, media, comment, user, settings, analytics-purge and
  staff-login events. IPs are stored only as keyed hashes. `python manage.py purge_audit_logs` (monthly Celery job) removes entries
  older than `AUDIT_RETENTION_DAYS` (365).
- **User management** (`Admin > Users`): filters, activate/deactivate, make or remove staff (superusers only), sign a user out
  everywhere, resend verification. Nobody can demote themselves; the last active superuser is protected.
- **Privacy rights**: **Account > Security** has "Download my data" (JSON) and "Delete my account" (anonymises; cannot be undone).
- **Uploads**: every image is decoded and re-encoded (all metadata gone, animations too), pixel and frame caps, random names,
  per-user hourly quota, sandboxed media headers.
- **Content safety**: link and image URL protocol allowlist, YouTube ids only, XSS test corpus across every text field, a frontend
  scan test that fails on `dangerouslySetInnerHTML` or `innerHTML`.
- **Privacy policy and consent**: `/privacy` is generated from your settings (retention numbers, cookie and storage tables stay in
  sync with the code, tested). `PRIVACY_CONSENT_MODE` = `notice` (default), `opt_in` or `opt_out` adds a consent banner and a
  footer "Privacy settings" link. See `docs/ANALYTICS.md`.

### New settings (`backend/.env`, all optional; see `backend/.env.example`)

`DJANGO_ADMIN_URL`, `DJANGO_ADMIN_ENABLED`, `STAFF_SESSION_IDLE_MINUTES`, `STAFF_MFA_REQUIRED`, `MFA_ENCRYPTION_KEY`, `MFA_ISSUER`,
`AUDIT_RETENTION_DAYS`, `AUDIT_HASH_SECRET`, `CSP_REPORT_ONLY`, `MEDIA_UPLOAD_QUOTA_PER_HOUR`, `PRIVACY_CONSENT_MODE`,
`SITE_OPERATOR_NAME`, `SITE_CONTACT_EMAIL`, `PRIVACY_POLICY_DATE`, `LOG_LEVEL`, and the new throttles `THROTTLE_ADMIN_WRITE`,
`THROTTLE_MFA`, `THROTTLE_DATA_EXPORT`, `THROTTLE_ACCOUNT_DELETE`, `THROTTLE_CSP_REPORT`.

### Run it

```bash
# backend (Redis must be running for the dev server and Celery; the tests need neither Redis nor Postgres)
cd backend && source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate                 # new: accounts 0002 (MFA, sessions), audit 0001, media 0002
python manage.py create_admin            # a superuser who can manage staff
python manage.py runserver               # http://localhost:8000
pytest                                   # backend tests
python manage.py purge_audit_logs --dry-run
python manage.py purge_audit_logs
python manage.py clearsessions           # run daily in production
celery -A config worker -l info          # separate terminals
celery -A config beat -l info

# frontend
cd frontend && npm install && npm run dev   # http://localhost:5173
npm test                                    # frontend tests
```

Behaviour you will notice: registering no longer logs the new user in (they get "check your email"); staff who turn on two-step
verification get a code prompt when they open the admin; `/admin/` on the Django side moved to `/django-admin/`.
