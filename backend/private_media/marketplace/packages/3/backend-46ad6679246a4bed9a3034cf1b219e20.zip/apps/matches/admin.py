from django.contrib import admin
from .models import Match, MatchEvent, MatchStatistic, Lineup


class MatchEventInline(admin.TabularInline):
    model = MatchEvent
    extra = 0
    raw_id_fields = ("team", "player", "assist_player")


@admin.register(Match)
class MatchAdmin(admin.ModelAdmin):
    list_display = ("home_team", "away_team", "scheduled_at", "status", "home_score", "away_score", "league")
    list_filter = ("status", "league")
    search_fields = ("home_team__name", "away_team__name", "provider_id")
    date_hierarchy = "scheduled_at"
    raw_id_fields = ("home_team", "away_team", "league", "season")
    inlines = [MatchEventInline]


@admin.register(MatchEvent)
class MatchEventAdmin(admin.ModelAdmin):
    list_display = ("match", "type", "minute", "team", "player")
    list_filter = ("type",)
    raw_id_fields = ("match", "team", "player", "assist_player")


@admin.register(MatchStatistic)
class MatchStatisticAdmin(admin.ModelAdmin):
    list_display = ("match", "team", "possession", "shots", "corners")
    raw_id_fields = ("match", "team")


@admin.register(Lineup)
class LineupAdmin(admin.ModelAdmin):
    list_display = ("match", "team", "player", "starter", "captain", "shirt_number")
    list_filter = ("starter", "captain")
    raw_id_fields = ("match", "team", "player")
