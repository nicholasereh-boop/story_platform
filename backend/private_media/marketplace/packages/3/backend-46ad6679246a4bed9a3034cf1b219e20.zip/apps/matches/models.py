from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import F, Q

from apps.football.models import League, Season, Team, Player, TimeStamped


class Match(TimeStamped):
    STATUS_CHOICES = [
        ("SCHEDULED", "Scheduled"),
        ("LIVE", "Live"),
        ("HT", "Half Time"),
        ("ET", "Extra Time"),
        ("PEN", "Penalties"),
        ("FT", "Full Time"),
        ("POSTPONED", "Postponed"),
        ("SUSPENDED", "Suspended"),
        ("ABANDONED", "Abandoned"),
        ("CANCELLED", "Cancelled"),
    ]
    provider_id = models.PositiveBigIntegerField(unique=True)
    league = models.ForeignKey(League, null=True, blank=True, on_delete=models.SET_NULL, related_name="matches")
    season = models.ForeignKey(Season, null=True, blank=True, on_delete=models.SET_NULL, related_name="matches")
    home_team = models.ForeignKey(Team, on_delete=models.PROTECT, related_name="home_matches")
    away_team = models.ForeignKey(Team, on_delete=models.PROTECT, related_name="away_matches")
    scheduled_at = models.DateTimeField(db_index=True)
    started_at = models.DateTimeField(null=True, blank=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="SCHEDULED", db_index=True)
    minute = models.PositiveIntegerField(null=True, blank=True)
    home_score = models.PositiveIntegerField(default=0)
    away_score = models.PositiveIntegerField(default=0)
    home_ht_score = models.PositiveIntegerField(null=True, blank=True)
    away_ht_score = models.PositiveIntegerField(null=True, blank=True)
    venue = models.CharField(max_length=200, blank=True)
    referee = models.CharField(max_length=200, blank=True)
    round = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ["scheduled_at"]
        indexes = [
            models.Index(fields=["status", "scheduled_at"], name="matches_mat_status_1d5f4f_idx"),
            models.Index(fields=["league", "scheduled_at"], name="matches_mat_league_7d7a1a_idx"),
            models.Index(fields=["home_team", "scheduled_at"], name="matches_match_home_sched_idx"),
            models.Index(fields=["away_team", "scheduled_at"], name="matches_match_away_sched_idx"),
            models.Index(fields=["season", "scheduled_at"], name="matches_match_ssn_sched_idx"),
        ]
        constraints = [
            models.CheckConstraint(condition=~Q(home_team=F("away_team")), name="match_home_away_differ"),
            models.CheckConstraint(
                condition=Q(started_at__isnull=True) | Q(ended_at__isnull=True) | Q(ended_at__gte=F("started_at")),
                name="match_end_after_start",
            ),
            models.CheckConstraint(
                condition=Q(minute__isnull=True) | Q(minute__lte=150),
                name="match_minute_lte_150",
            ),
        ]

    def clean(self):
        if self.season_id and self.league_id and self.season.league_id != self.league_id:
            raise ValidationError("Match league must match the season's league.")

    def __str__(self):
        return f"{self.home_team} vs {self.away_team} ({self.scheduled_at:%Y-%m-%d})"


class MatchTeamValidationMixin:
    def clean(self):
        if self.match_id and self.team_id and self.team_id not in (self.match.home_team_id, self.match.away_team_id):
            raise ValidationError("Team must be the home or away team of the match.")


class MatchEvent(MatchTeamValidationMixin, TimeStamped):
    EVENT_TYPES = [
        ("GOAL", "Goal"),
        ("OWN_GOAL", "Own goal"),
        ("YELLOW_CARD", "Yellow card"),
        ("RED_CARD", "Red card"),
        ("SUBSTITUTION", "Substitution"),
        ("VAR", "VAR"),
        ("OTHER", "Other"),
    ]
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name="events")
    provider_id = models.PositiveBigIntegerField(unique=True)
    type = models.CharField(max_length=30, choices=EVENT_TYPES)
    minute = models.PositiveIntegerField(null=True, blank=True)
    extra_minute = models.PositiveIntegerField(null=True, blank=True)
    team = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name="match_events")
    player = models.ForeignKey(Player, null=True, blank=True, on_delete=models.SET_NULL, related_name="match_events")
    assist_player = models.ForeignKey(Player, null=True, blank=True, on_delete=models.SET_NULL, related_name="assists")
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["minute", "extra_minute", "id"]
        indexes = [
            models.Index(fields=["match", "minute", "extra_minute"], name="matches_event_match_min_idx"),
            models.Index(fields=["player", "type"], name="matches_event_plr_type_idx"),
        ]
        constraints = [
            models.CheckConstraint(
                condition=Q(assist_player__isnull=True) | ~Q(assist_player=F("player")),
                name="event_assist_not_scorer",
            ),
        ]

    def __str__(self):
        return f"{self.type} {self.minute or 0}' ({self.match_id})"


class MatchStatistic(MatchTeamValidationMixin, TimeStamped):
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name="statistics")
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="match_statistics")
    possession = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    shots = models.PositiveIntegerField(null=True, blank=True)
    shots_on_target = models.PositiveIntegerField(null=True, blank=True)
    shots_off_target = models.PositiveIntegerField(null=True, blank=True)
    corners = models.PositiveIntegerField(null=True, blank=True)
    fouls = models.PositiveIntegerField(null=True, blank=True)
    offsides = models.PositiveIntegerField(null=True, blank=True)
    yellow_cards = models.PositiveIntegerField(null=True, blank=True)
    red_cards = models.PositiveIntegerField(null=True, blank=True)
    passes = models.PositiveIntegerField(null=True, blank=True)
    passes_completed = models.PositiveIntegerField(null=True, blank=True)
    expected_goals = models.DecimalField(max_digits=6, decimal_places=3, null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["match", "team"], name="unique_match_team_stats"),
            models.CheckConstraint(
                condition=Q(possession__isnull=True) | (Q(possession__gte=0) & Q(possession__lte=100)),
                name="statistic_possession_0_100",
            ),
        ]

    def __str__(self):
        return f"Stats {self.team} ({self.match_id})"


class Lineup(MatchTeamValidationMixin, TimeStamped):
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name="lineups")
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="lineups")
    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name="lineups")
    position = models.CharField(max_length=20, blank=True)
    starter = models.BooleanField(default=False)
    captain = models.BooleanField(default=False)
    shirt_number = models.PositiveIntegerField(null=True, blank=True)
    minutes_played = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["match", "starter"], name="matches_lineup_start_idx"),
        ]
        constraints = [
            models.UniqueConstraint(fields=["match", "team", "player"], name="unique_match_team_player_lineup"),
        ]

    def __str__(self):
        return f"{self.player} ({self.match_id})"
