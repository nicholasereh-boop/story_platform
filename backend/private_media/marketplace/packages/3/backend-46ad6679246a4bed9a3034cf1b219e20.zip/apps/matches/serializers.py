from rest_framework import serializers

from apps.football.serializers import LeagueMiniSerializer, PlayerMiniSerializer, TeamMiniSerializer

from apps.streams.services import playable_streams

from .live import EVENT_KINDS
from .models import Lineup, Match, MatchEvent, MatchStatistic

SCORE_FIELDS = ("status", "minute", "home_score", "away_score", "home_ht_score", "away_ht_score")


class MatchEventSerializer(serializers.ModelSerializer):
    """Same shape as the WebSocket `event` payload, so REST and live data merge cleanly."""

    id = serializers.IntegerField(source="provider_id", read_only=True)
    kind = serializers.SerializerMethodField()
    team = TeamMiniSerializer(read_only=True)
    player = PlayerMiniSerializer(read_only=True)
    assist = PlayerMiniSerializer(source="assist_player", read_only=True)

    class Meta:
        model = MatchEvent
        fields = ("id", "type", "kind", "minute", "extra_minute", "team", "player", "assist", "description")

    def get_kind(self, event):
        return EVENT_KINDS.get(event.type, "other")


class MatchStatisticSerializer(serializers.ModelSerializer):
    team = TeamMiniSerializer(read_only=True)

    class Meta:
        model = MatchStatistic
        fields = (
            "team", "possession", "shots", "shots_on_target", "shots_off_target", "corners", "fouls",
            "offsides", "yellow_cards", "red_cards", "passes", "passes_completed", "expected_goals",
        )


class LineupSerializer(serializers.ModelSerializer):
    team = TeamMiniSerializer(read_only=True)
    player = PlayerMiniSerializer(read_only=True)

    class Meta:
        model = Lineup
        fields = ("team", "player", "position", "starter", "captain", "shirt_number", "minutes_played")


class MatchListSerializer(serializers.ModelSerializer):
    league = LeagueMiniSerializer(read_only=True)
    home_team = TeamMiniSerializer(read_only=True)
    away_team = TeamMiniSerializer(read_only=True)
    home_team_name = serializers.CharField(source="home_team.name", read_only=True)
    away_team_name = serializers.CharField(source="away_team.name", read_only=True)

    class Meta:
        model = Match
        fields = (
            "id", "league", "season", "home_team", "away_team", "home_team_name", "away_team_name",
            "scheduled_at", "started_at", "ended_at", *SCORE_FIELDS, "venue", "round",
        )


class MatchDetailSerializer(MatchListSerializer):
    referee = serializers.CharField(read_only=True)
    events = MatchEventSerializer(many=True, read_only=True)
    statistics = MatchStatisticSerializer(many=True, read_only=True)
    lineups = LineupSerializer(many=True, read_only=True)
    # Empty unless the match is in play and a stream is active, inside its window and from an approved host.
    streams = serializers.SerializerMethodField()

    class Meta(MatchListSerializer.Meta):
        fields = (*MatchListSerializer.Meta.fields, "referee", "events", "statistics", "lineups", "streams")

    def get_streams(self, obj):
        return playable_streams(obj)

