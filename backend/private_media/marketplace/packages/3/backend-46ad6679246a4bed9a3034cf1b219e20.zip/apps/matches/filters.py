from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import django_filters as filters
from django.db.models import Q
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import Match


def request_timezone(request):
    """Time zone used for day boundaries: ?tz=Africa/Lagos, otherwise the server default."""
    name = request.query_params.get("tz") if request is not None else None
    if not name:
        return timezone.get_current_timezone()
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        raise ValidationError({"tz": "Unknown time zone."})


def day_bounds(day, tz):
    start = datetime.combine(day, time.min, tzinfo=tz)
    return start, start + timedelta(days=1)


class MatchFilter(filters.FilterSet):
    status = filters.CharFilter(method="filter_status", help_text="One or more statuses, comma separated.")
    team = filters.NumberFilter(method="filter_team", help_text="Matches played by this team, home or away.")
    date = filters.DateFilter(method="filter_date")
    date_from = filters.DateFilter(method="filter_date_from")
    date_to = filters.DateFilter(method="filter_date_to")

    class Meta:
        model = Match
        fields = ["league", "season"]

    def filter_status(self, queryset, name, value):
        statuses = [part.strip().upper() for part in value.split(",") if part.strip()]
        return queryset.filter(status__in=statuses) if statuses else queryset

    def filter_team(self, queryset, name, value):
        return queryset.filter(Q(home_team_id=value) | Q(away_team_id=value))

    def filter_date(self, queryset, name, value):
        start, end = day_bounds(value, request_timezone(self.request))
        return queryset.filter(scheduled_at__gte=start, scheduled_at__lt=end)

    def filter_date_from(self, queryset, name, value):
        start, _ = day_bounds(value, request_timezone(self.request))
        return queryset.filter(scheduled_at__gte=start)

    def filter_date_to(self, queryset, name, value):
        _, end = day_bounds(value, request_timezone(self.request))
        return queryset.filter(scheduled_at__lt=end)

