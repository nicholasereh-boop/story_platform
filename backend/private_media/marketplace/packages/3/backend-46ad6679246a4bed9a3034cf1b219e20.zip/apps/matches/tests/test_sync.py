import pytest

from apps.core.cache import get_live_match_ids, last_sync
from apps.football.models import Team
from apps.matches import sync
from apps.matches.models import Lineup, Match, MatchEvent, MatchStatistic

pytestmark = pytest.mark.django_db


class FakeClient:
    def __init__(self, inplay=(), multi=None):
        self._inplay = list(inplay)
        self._multi = multi or {}
        self.multi_calls = []

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def livescores_inplay(self, includes):
        return iter(self._inplay)

    def fixtures_multi(self, ids, includes):
        self.multi_calls.append(list(ids))
        return iter([self._multi[i] for i in ids if i in self._multi])

    def fixtures_between(self, start, end, includes, league_ids=None):
        return iter(self._inplay)


def fixture(match_id=100, state="INPLAY_1ST_HALF", home_goals=0, away_goals=0, **extra):
    raw = {
        "id": match_id, "league_id": 8, "season_id": 1,
        "starting_at": "2026-10-21 19:00:00", "starting_at_timestamp": 1792609200,
        "state": {"developer_name": state},
        "participants": [
            {"id": 1, "name": "Arsenal", "meta": {"location": "home"}},
            {"id": 2, "name": "Chelsea", "meta": {"location": "away"}},
        ],
        "scores": [
            {"description": "CURRENT", "score": {"goals": home_goals, "participant": "home"}},
            {"description": "CURRENT", "score": {"goals": away_goals, "participant": "away"}},
        ],
        "periods": [{"started": 1792609260, "ended": None, "ticking": True, "minutes": 30}],
    }
    raw.update(extra)
    return raw


def test_upsert_fixtures_creates_teams_and_updates_scores():
    sync.upsert_fixtures([fixture(home_goals=0)])
    sync.upsert_fixtures([fixture(home_goals=2, away_goals=1)])
    match = Match.objects.get(provider_id=100)
    assert Match.objects.count() == 1 and Team.objects.count() == 2
    assert (match.home_score, match.away_score, match.status, match.minute) == (2, 1, "LIVE", 30)


def test_unknown_state_keeps_the_existing_status():
    sync.upsert_fixtures([fixture(state="INPLAY_1ST_HALF")])
    sync.upsert_fixtures([fixture(state="NEW_PROVIDER_STATE")])
    assert Match.objects.get().status == "LIVE"


def test_invalid_fixtures_are_skipped():
    result = sync.upsert_fixtures([{"id": 5, "participants": []}, fixture()])
    assert result == {"matches": 1, "skipped": 1}


def test_events_are_upserted_and_stale_events_removed():
    events = [
        {"id": 1, "type": {"developer_name": "GOAL"}, "player_id": 9, "player_name": "Saka",
         "related_player_id": 10, "related_player_name": "Odegaard", "participant_id": 1, "minute": 12},
        {"id": 2, "type": {"developer_name": "YELLOWCARD"}, "player_id": 11, "player_name": "Palmer",
         "participant_id": 2, "minute": 30},
    ]
    sync.upsert_fixtures([fixture(events=events)])
    sync.upsert_events([fixture(events=events)])
    assert MatchEvent.objects.count() == 2

    sync.upsert_events([fixture(events=events[:1])])
    goal = MatchEvent.objects.get()
    assert goal.type == "GOAL" and goal.assist_player.display_name == "Odegaard"
    assert goal.team.provider_id == 1


def test_event_team_outside_the_match_is_dropped():
    events = [{"id": 1, "type": {"developer_name": "GOAL"}, "player_id": 9, "participant_id": 999}]
    sync.upsert_fixtures([fixture(events=events)])
    sync.upsert_events([fixture(events=events)])
    assert MatchEvent.objects.get().team is None


def test_lineups_and_statistics():
    raw = fixture(
        lineups=[
            {"player_id": 9, "player_name": "Saka", "team_id": 1, "type_id": 11, "jersey_number": 7, "position_id": 27},
            {"player_id": 12, "player_name": "Sub", "team_id": 1, "type_id": 12},
        ],
        statistics=[
            {"participant_id": 1, "type": {"developer_name": "BALL_POSSESSION"}, "data": {"value": 58}},
            {"participant_id": 1, "type": {"developer_name": "CORNERS"}, "data": {"value": 7}},
            {"participant_id": 2, "type": {"developer_name": "CORNERS"}, "data": {"value": 3}},
        ],
    )
    sync.upsert_fixtures([raw])
    sync.upsert_details([raw])
    assert Lineup.objects.filter(starter=True).count() == 1 and Lineup.objects.count() == 2
    assert MatchStatistic.objects.count() == 2
    assert MatchStatistic.objects.get(team__provider_id=1).corners == 7

    sync.upsert_details([fixture(lineups=raw["lineups"][:1], statistics=raw["statistics"])])
    assert Lineup.objects.count() == 1


def test_live_sync_refreshes_matches_that_left_the_inplay_feed():
    sync.upsert_fixtures([fixture(match_id=100), fixture(match_id=200)])
    finished = fixture(match_id=200, state="FT", home_goals=3, away_goals=1, periods=[
        {"started": 1792609260, "ended": 1792616000, "ticking": False, "minutes": 90},
    ])
    client = FakeClient(inplay=[fixture(match_id=100)], multi={200: finished})

    result = sync.sync_live_scores(client)

    assert client.multi_calls == [[200]]
    assert Match.objects.get(provider_id=200).status == "FT"
    assert Match.objects.get(provider_id=200).home_score == 3
    assert result["live"] == 1 and result["refreshed"] == 1
    assert get_live_match_ids() == [100]
    assert last_sync("live") is not None


def test_match_details_sync_uses_multi_endpoint():
    sync.upsert_fixtures([fixture(match_id=100)])
    raw = fixture(match_id=100, statistics=[
        {"participant_id": 1, "type": {"developer_name": "CORNERS"}, "data": {"value": 4}},
    ])
    client = FakeClient(multi={100: raw})
    result = sync.sync_match_details(provider_ids=[100], client=client)
    assert result["statistics"] == 1 and client.multi_calls == [[100]]


def test_sync_fixtures_window_filters_by_allow_list(settings):
    settings.SPORTMONKS_LEAGUE_IDS = {564}
    client = FakeClient(inplay=[fixture()])
    assert sync.sync_fixtures(client=client)["matches"] == 0
    assert Match.objects.count() == 0
