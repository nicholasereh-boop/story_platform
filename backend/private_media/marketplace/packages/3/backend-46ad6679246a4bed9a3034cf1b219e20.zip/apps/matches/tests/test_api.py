from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Player, Season, Team
from apps.matches.models import Lineup, Match, MatchEvent, MatchStatistic

pytestmark = pytest.mark.django_db
BASE = "/api/v1/matches/"


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def world():
    league = League.objects.create(provider_id=8, name="Premier League", country="England")
    other_league = League.objects.create(provider_id=9, name="La Liga", country="Spain")
    teams = {n: Team.objects.create(provider_id=i, name=n) for i, n in enumerate(["Arsenal", "Chelsea", "Spurs", "Real"], 1)}
    return {"league": league, "other_league": other_league, **teams}


_counter = iter(range(1000, 100000))


def make_match(world, home="Arsenal", away="Chelsea", status="SCHEDULED", when=None, league="league", **extra):
    return Match.objects.create(
        provider_id=next(_counter), league=world[league], home_team=world[home], away_team=world[away],
        status=status, scheduled_at=when or timezone.now() + timedelta(days=1), **extra,
    )


def ids(response):
    data = response.data["results"] if isinstance(response.data, dict) else response.data
    return [m["id"] for m in data]


def test_list_is_paginated_and_uses_the_nested_shape(client, world):
    make_match(world)
    response = client.get(BASE)
    assert response.status_code == 200
    assert response.data["count"] == 1
    match = response.data["results"][0]
    assert match["home_team"]["name"] == "Arsenal" and match["league"]["name"] == "Premier League"
    assert match["home_team_name"] == "Arsenal"


def test_page_size_is_capped(client, world):
    for _ in range(3):
        make_match(world)
    assert len(client.get(BASE, {"page_size": 2}).data["results"]) == 2
    assert client.get(BASE, {"page_size": 1000}).status_code == 200


def test_filters_by_status_league_and_team(client, world):
    live = make_match(world, status="LIVE")
    done = make_match(world, "Spurs", "Real", status="FT", league="other_league")
    assert ids(client.get(BASE, {"status": "live"})) == [live.id]
    assert set(ids(client.get(BASE, {"status": "live,ft"}))) == {live.id, done.id}
    assert ids(client.get(BASE, {"league": world["other_league"].id})) == [done.id]
    assert ids(client.get(BASE, {"team": world["Real"].id})) == [done.id]
    assert set(ids(client.get(BASE, {"team": world["Arsenal"].id}))) == {live.id}


def test_filters_by_date_in_the_requested_time_zone(client, world):
    late = timezone.now().replace(hour=23, minute=30, second=0, microsecond=0)
    match = make_match(world, when=late)
    local_day = late.astimezone(timezone.get_current_timezone()).date().isoformat()
    assert ids(client.get(BASE, {"date": local_day})) == [match.id]
    lagos_day = (late + timedelta(hours=1)).date().isoformat()
    assert ids(client.get(BASE, {"date": lagos_day, "tz": "Africa/Lagos"})) == [match.id]
    assert ids(client.get(BASE, {"date_from": (late + timedelta(days=1)).date().isoformat()})) == []


def test_unknown_time_zone_is_a_400(client, world):
    assert client.get(BASE, {"date": "2026-10-21", "tz": "Mars/Base"}).status_code == 400
    assert client.get(BASE + "today/", {"tz": "Mars/Base"}).status_code == 400


def test_live_endpoint_returns_only_matches_in_play_unpaginated(client, world):
    live = make_match(world, status="LIVE", minute=33)
    ht = make_match(world, "Spurs", "Real", status="HT")
    make_match(world, status="FT")
    make_match(world, status="SCHEDULED")
    response = client.get(BASE + "live/")
    assert isinstance(response.data, list)
    assert set(ids(response)) == {live.id, ht.id}


def test_live_endpoint_can_be_filtered_by_league(client, world):
    make_match(world, status="LIVE")
    other = make_match(world, "Spurs", "Real", status="LIVE", league="other_league")
    assert ids(client.get(BASE + "live/", {"league": world["other_league"].id})) == [other.id]


def test_today_endpoint(client, world):
    now = timezone.now()
    tz = timezone.get_current_timezone()
    noon = now.astimezone(tz).replace(hour=12, minute=0, second=0, microsecond=0)
    today = make_match(world, when=noon)
    make_match(world, when=noon + timedelta(days=2))
    assert ids(client.get(BASE + "today/")) == [today.id]


def test_upcoming_endpoint_only_returns_future_scheduled_matches_in_order(client, world):
    soon = make_match(world, when=timezone.now() + timedelta(hours=2))
    later = make_match(world, when=timezone.now() + timedelta(days=3))
    make_match(world, when=timezone.now() - timedelta(hours=2))
    make_match(world, status="FT", when=timezone.now() + timedelta(days=1))
    assert ids(client.get(BASE + "upcoming/")) == [soon.id, later.id]
    assert ids(client.get(BASE + "upcoming/", {"days": 1})) == [soon.id]


def test_upcoming_days_is_validated(client, world):
    for bad in ("0", "abc", "-1", "9999"):
        assert client.get(BASE + "upcoming/", {"days": bad}).status_code == 400, bad


def test_results_endpoint_is_newest_first(client, world):
    old = make_match(world, status="FT", when=timezone.now() - timedelta(days=5))
    new = make_match(world, status="FT", when=timezone.now() - timedelta(days=1))
    make_match(world, status="LIVE")
    assert ids(client.get(BASE + "results/")) == [new.id, old.id]


def test_detail_includes_events_statistics_and_lineups(client, world):
    match = make_match(world, status="LIVE", home_score=1)
    saka = Player.objects.create(provider_id=1, display_name="Saka")
    odegaard = Player.objects.create(provider_id=2, display_name="Odegaard")
    MatchEvent.objects.create(
        match=match, provider_id=77, type="GOAL", minute=12, team=world["Arsenal"], player=saka, assist_player=odegaard
    )
    MatchStatistic.objects.create(match=match, team=world["Arsenal"], shots=7, possession="55.50")
    Lineup.objects.create(match=match, team=world["Arsenal"], player=saka, starter=True, shirt_number=7)

    data = client.get(f"{BASE}{match.id}/").data
    event = data["events"][0]
    assert event["id"] == 77 and event["kind"] == "goal"
    assert event["player"]["name"] == "Saka" and event["assist"]["name"] == "Odegaard"
    assert data["statistics"][0]["shots"] == 7
    assert data["lineups"][0]["player"]["name"] == "Saka"


def test_detail_event_shape_matches_the_websocket_payload(client, world):
    from apps.matches.live import serialize_event

    match = make_match(world, status="LIVE")
    player = Player.objects.create(provider_id=1, display_name="Saka")
    event = MatchEvent.objects.create(match=match, provider_id=5, type="YELLOW_CARD", minute=20,
                                      team=world["Arsenal"], player=player)
    rest = client.get(f"{BASE}{match.id}/").data["events"][0]
    ws = serialize_event(event)
    for key in ("id", "type", "kind", "minute", "extra_minute", "description"):
        assert rest[key] == ws[key]
    assert rest["player"]["id"] == ws["player"]["id"] and rest["player"]["name"] == ws["player"]["name"]


def test_detail_is_served_in_a_fixed_number_of_queries(client, world, django_assert_max_num_queries):
    match = make_match(world, status="LIVE")
    player = Player.objects.create(provider_id=1, display_name="Saka")
    for i in range(10):
        MatchEvent.objects.create(match=match, provider_id=100 + i, type="GOAL", minute=i, team=world["Arsenal"], player=player)
    with django_assert_max_num_queries(7):  # match, events, statistics, lineups and streams, with headroom
        assert client.get(f"{BASE}{match.id}/").status_code == 200


def test_nested_resources_and_404s(client, world):
    match = make_match(world)
    for name in ("events", "statistics", "lineups"):
        response = client.get(f"{BASE}{match.id}/{name}/")
        assert response.status_code == 200 and response.data == []
        assert client.get(f"{BASE}999999/{name}/").status_code == 404
    assert client.get(BASE + "abc/").status_code == 404
    assert client.get(BASE + "abc/h2h/").status_code == 404


def test_h2h_summarises_from_the_home_teams_point_of_view(client, world):
    now = timezone.now()
    target = make_match(world, "Arsenal", "Chelsea", when=now + timedelta(days=1))
    make_match(world, "Arsenal", "Chelsea", "FT", now - timedelta(days=10), home_score=2, away_score=0)
    make_match(world, "Chelsea", "Arsenal", "FT", now - timedelta(days=20), home_score=1, away_score=1)
    make_match(world, "Chelsea", "Arsenal", "FT", now - timedelta(days=30), home_score=3, away_score=1)
    make_match(world, "Spurs", "Real", "FT", now - timedelta(days=5), home_score=9, away_score=9)
    make_match(world, "Arsenal", "Chelsea", "LIVE")

    data = client.get(f"{BASE}{target.id}/h2h/").data
    assert data["summary"] == {"played": 3, "home_wins": 1, "draws": 1, "away_wins": 1, "home_goals": 4, "away_goals": 4}
    assert [m["home_score"] for m in data["matches"]] == [2, 1, 3]


def test_h2h_limit_and_validation(client, world):
    now = timezone.now()
    target = make_match(world)
    for days in (1, 2, 3):
        make_match(world, status="FT", when=now - timedelta(days=days), home_score=1)
    assert client.get(f"{BASE}{target.id}/h2h/", {"limit": 2}).data["summary"]["played"] == 2
    assert client.get(f"{BASE}{target.id}/h2h/", {"limit": 500}).status_code == 400


def test_the_api_is_read_only(client, world):
    match = make_match(world)
    assert client.post(BASE, {}, format="json").status_code in (401, 403, 405)
    assert client.delete(f"{BASE}{match.id}/").status_code in (401, 403, 405)
