from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import ProtectedError
from django.utils import timezone

from apps.football.models import League, Player, Season, Team
from apps.matches.models import Lineup, Match, MatchEvent, MatchStatistic

pytestmark = pytest.mark.django_db


@pytest.fixture
def teams():
    return Team.objects.create(provider_id=1, name="Home FC"), Team.objects.create(provider_id=2, name="Away FC")


@pytest.fixture
def match(teams):
    home, away = teams
    return Match.objects.create(provider_id=1, home_team=home, away_team=away, scheduled_at=timezone.now())


def test_home_and_away_must_differ(teams):
    home, _ = teams
    with pytest.raises(IntegrityError), transaction.atomic():
        Match.objects.create(provider_id=9, home_team=home, away_team=home, scheduled_at=timezone.now())


def test_end_cannot_precede_start(teams):
    home, away = teams
    now = timezone.now()
    with pytest.raises(IntegrityError), transaction.atomic():
        Match.objects.create(
            provider_id=9, home_team=home, away_team=away, scheduled_at=now,
            started_at=now, ended_at=now - timedelta(hours=1),
        )


def test_minute_upper_bound(teams):
    home, away = teams
    with pytest.raises(IntegrityError), transaction.atomic():
        Match.objects.create(
            provider_id=9, home_team=home, away_team=away, scheduled_at=timezone.now(), minute=200,
        )


def test_team_with_matches_cannot_be_deleted(match, teams):
    with pytest.raises(ProtectedError):
        teams[0].delete()


def test_match_league_must_match_season_league(teams):
    home, away = teams
    league = League.objects.create(provider_id=1, name="League A")
    other = League.objects.create(provider_id=2, name="League B")
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026")
    m = Match(provider_id=5, home_team=home, away_team=away, scheduled_at=timezone.now(), league=other, season=season)
    with pytest.raises(ValidationError):
        m.clean()


def test_event_assist_cannot_be_scorer(match):
    player = Player.objects.create(provider_id=1, display_name="Scorer")
    with pytest.raises(IntegrityError), transaction.atomic():
        MatchEvent.objects.create(match=match, provider_id=1, type="GOAL", player=player, assist_player=player)


def test_event_team_must_belong_to_match(match):
    outsider = Team.objects.create(provider_id=99, name="Outsider")
    event = MatchEvent(match=match, provider_id=2, type="GOAL", team=outsider)
    with pytest.raises(ValidationError):
        event.clean()


def test_statistics_unique_per_match_team_and_possession_range(match, teams):
    home, away = teams
    MatchStatistic.objects.create(match=match, team=home, possession=55)
    with pytest.raises(IntegrityError), transaction.atomic():
        MatchStatistic.objects.create(match=match, team=home)
    with pytest.raises(IntegrityError), transaction.atomic():
        MatchStatistic.objects.create(match=match, team=away, possession=120)


def test_lineup_unique_per_match_team_player(match, teams):
    home, _ = teams
    player = Player.objects.create(provider_id=1, display_name="Keeper")
    Lineup.objects.create(match=match, team=home, player=player, starter=True)
    with pytest.raises(IntegrityError), transaction.atomic():
        Lineup.objects.create(match=match, team=home, player=player)


def test_deleting_match_cascades(match, teams):
    home, _ = teams
    MatchEvent.objects.create(match=match, provider_id=1, type="GOAL", team=home)
    MatchStatistic.objects.create(match=match, team=home)
    match.delete()
    assert MatchEvent.objects.count() == 0
    assert MatchStatistic.objects.count() == 0
