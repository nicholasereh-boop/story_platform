import logging
from collections import defaultdict
from datetime import timedelta

from django.conf import settings
from django.db.models import Q
from django.utils import timezone

from apps.core import pubsub
from apps.core.apicache import invalidate
from integrations.sportmonks.constants import LIVE_STATUSES

from .models import Match, MatchEvent

logger = logging.getLogger(__name__)

EVENT_KINDS = {
    "GOAL": "goal",
    "OWN_GOAL": "goal",
    "YELLOW_CARD": "card",
    "RED_CARD": "card",
    "SUBSTITUTION": "substitution",
    "VAR": "var",
}


def _iso(value):
    return value.isoformat() if value else None


def _score(home, away):
    return f"{home}-{away}"


def serialize_team(team):
    return {"id": team.id, "name": team.name, "logo": team.logo} if team else None


def serialize_person(player):
    return {"id": player.id, "name": player.display_name} if player else None


def serialize_event(event):
    return {
        "id": event.provider_id,
        "type": event.type,
        "kind": EVENT_KINDS.get(event.type, "other"),
        "minute": event.minute,
        "extra_minute": event.extra_minute,
        "team": serialize_team(event.team),
        "player": serialize_person(event.player),
        "assist": serialize_person(event.assist_player),
        "description": event.description,
    }


def serialize_match(match, events=None):
    data = {
        "id": match.id,
        "provider_id": match.provider_id,
        "league": {"id": match.league_id, "name": match.league.name} if match.league_id else None,
        "home": serialize_team(match.home_team),
        "away": serialize_team(match.away_team),
        "status": match.status,
        "minute": match.minute,
        "home_score": match.home_score,
        "away_score": match.away_score,
        "home_ht_score": match.home_ht_score,
        "away_ht_score": match.away_ht_score,
        "scheduled_at": _iso(match.scheduled_at),
        "started_at": _iso(match.started_at),
    }
    if events is not None:
        data["events"] = [serialize_event(e) for e in events]
    return data


def _events_queryset(**filters):
    return (
        MatchEvent.objects.filter(**filters)
        .select_related("team", "player", "assist_player")
        .order_by("minute", "extra_minute", "id")
    )


def _signature(event):
    return (
        event.type, event.minute, event.extra_minute, event.team_id, event.player_id, event.assist_player_id,
    )


def capture_state(provider_ids, include_events=True):
    """What the matches looked like before a sync, so the sync can tell what changed."""
    ids = list(provider_ids)
    state = {
        m["provider_id"]: {**m, "events": {}}
        for m in Match.objects.filter(provider_id__in=ids).values(
            "id", "provider_id", "status", "minute", "home_score", "away_score"
        )
    }
    if include_events and state:
        rows = MatchEvent.objects.filter(match__provider_id__in=ids).values_list(
            "match__provider_id", "provider_id", "type", "minute", "extra_minute", "team_id", "player_id",
            "assist_player_id",
        )
        for match_provider_id, event_provider_id, *signature in rows:
            state[match_provider_id]["events"][event_provider_id] = tuple(signature)
    return state


def _diff(old, match):
    if old is None:
        return {"created": True}
    changes = {}
    if old["status"] != match.status:
        changes["status"] = {"from": old["status"], "to": match.status}
    old_score = _score(old["home_score"], old["away_score"])
    new_score = _score(match.home_score, match.away_score)
    if old_score != new_score:
        changes["score"] = {"from": old_score, "to": new_score}
    if old["minute"] != match.minute:
        changes["minute"] = {"from": old["minute"], "to": match.minute}
    return changes


def detect(before, provider_ids, include_events=True, announce_new=True):
    """Compares the database with `before` and returns one record per match that changed."""
    matches = list(
        Match.objects.filter(provider_id__in=list(provider_ids)).select_related("home_team", "away_team", "league")
    )
    events_by_match = defaultdict(list)
    if include_events and matches:
        for event in _events_queryset(match_id__in=[m.id for m in matches]):
            events_by_match[event.match_id].append(event)

    records = []
    for match in matches:
        old = before.get(match.provider_id)
        if old is None and not announce_new:
            continue
        events = events_by_match.get(match.id, [])
        new, updated, removed = [], [], []
        if include_events:
            known = old["events"] if old else {}
            for event in events:
                if event.provider_id not in known:
                    new.append(event)
                elif known[event.provider_id] != _signature(event):
                    updated.append(event)
            removed = sorted(set(known) - {e.provider_id for e in events})
        changes = _diff(old, match)
        if changes or new or updated or removed:
            records.append(
                {
                    "match": match, "old": old, "changes": changes, "events": events,
                    "new": new, "updated": updated, "removed": removed,
                }
            )
    return records


def publish(records, include_events=True):
    stats = {"updates": 0, "events": 0, "removed": 0}
    for record in records:
        match, old = record["match"], record["old"]
        base = {"match_id": match.id, "provider_id": match.provider_id, "league_id": match.league_id}
        if record["changes"]:
            message = {"type": "match_update", **base, "changes": record["changes"], "match": serialize_match(match)}
            if old is None and include_events:
                message["events"] = [serialize_event(e) for e in record["events"]]
            if pubsub.publish_sequenced(pubsub.LIVE_CHANNEL, message):
                stats["updates"] += 1
        for event, corrected in [(e, False) for e in record["new"]] + [(e, True) for e in record["updated"]]:
            message = {"type": "match_event", **base, "event": serialize_event(event), "match": serialize_match(match)}
            if corrected:
                message["updated"] = True
            if pubsub.publish_sequenced(pubsub.EVENTS_CHANNEL, message):
                stats["events"] += 1
        if record["removed"]:
            message = {"type": "event_removed", **base, "event_ids": record["removed"]}
            if pubsub.publish_sequenced(pubsub.EVENTS_CHANNEL, message):
                stats["removed"] += 1
    return stats


def notify(records):
    """Hands changes to the notification system. A failure here must never break a sync."""
    try:
        from apps.notifications import services

        services.queue_for_changes(records)
    except Exception:
        logger.exception("Could not queue notifications")


def _significant(record):
    """A score, status or event change. A ticking minute alone must not wipe the API cache every cycle."""
    return bool(set(record["changes"]) - {"minute"} or record["new"] or record["updated"] or record["removed"])


def publish_changes(before, provider_ids, include_events=True, announce_new=True):
    records = detect(before, provider_ids, include_events=include_events, announce_new=announce_new)
    stats = publish(records, include_events=include_events)
    if any(_significant(record) for record in records):
        invalidate("matches")
    if records:
        notify(records)
    return stats


def build_snapshot():
    matches = list(
        Match.objects.filter(status__in=LIVE_STATUSES)
        .select_related("home_team", "away_team", "league")
        .order_by("league__name", "scheduled_at")
    )
    events_by_match = defaultdict(list)
    if matches:
        for event in _events_queryset(match_id__in=[m.id for m in matches]):
            events_by_match[event.match_id].append(event)
    return [serialize_match(m, events_by_match.get(m.id, [])) for m in matches]


def publish_snapshot():
    """Stores what is live right now for clients that connect later.

    The sequence number is read before the matches are built: anything published while we build has a
    higher number, so a client that applies only newer messages never misses or double-applies a change.
    """
    if not settings.REALTIME_PUBLISH_ENABLED:
        return 0
    seq = pubsub.current_seq()
    matches = build_snapshot()
    pubsub.store_snapshot(
        {"v": 1, "type": "snapshot", "seq": seq, "sent_at": timezone.now().isoformat(), "matches": matches}
    )
    return len(matches)


def should_poll(now=None):
    """False when nothing is live and nothing kicks off soon, so idle hours cost no API calls."""
    if not settings.LIVE_ADAPTIVE_POLLING:
        return True
    now = now or timezone.now()
    return Match.objects.filter(
        Q(status__in=LIVE_STATUSES)
        | Q(status="SCHEDULED", scheduled_at__lte=now + timedelta(minutes=15), scheduled_at__gte=now - timedelta(hours=3))
    ).exists()
