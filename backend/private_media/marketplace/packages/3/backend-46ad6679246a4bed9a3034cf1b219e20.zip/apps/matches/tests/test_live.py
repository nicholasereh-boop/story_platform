import json
from datetime import timedelta

import pytest
from django.utils import timezone

from apps.core import pubsub
from apps.matches import live, sync
from apps.matches.tasks import fetch_live_scores
from apps.matches.models import Match, MatchEvent
from apps.matches.tests.test_sync import FakeClient, fixture

pytestmark = pytest.mark.django_db

GOAL = {
    "id": 1, "type": {"developer_name": "GOAL"}, "player_id": 9, "player_name": "Saka",
    "related_player_id": 10, "related_player_name": "Odegaard", "participant_id": 1, "minute": 12,
}


def snapshot_matches(fake_redis):
    return json.loads(fake_redis.store[pubsub.SNAPSHOT_KEY])["matches"]


def test_first_cycle_announces_the_match_and_stores_a_snapshot(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture(events=[GOAL])]))

    (update,) = fake_redis.messages(pubsub.LIVE_CHANNEL, "match_update")
    assert update["changes"] == {"created": True}
    assert update["match"]["home"]["name"] == "Arsenal"
    (event,) = fake_redis.messages(pubsub.EVENTS_CHANNEL, "match_event")
    assert event["event"]["kind"] == "goal"
    (match,) = snapshot_matches(fake_redis)
    assert match["status"] == "LIVE" and match["events"][0]["player"]["name"] == "Saka"


def test_score_change_and_new_goal_are_published_in_order(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture()]))
    fake_redis.published.clear()

    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1, events=[GOAL])]))

    (update,) = fake_redis.messages(pubsub.LIVE_CHANNEL, "match_update")
    assert update["changes"] == {"score": {"from": "0-0", "to": "1-0"}}
    (event,) = fake_redis.messages(pubsub.EVENTS_CHANNEL, "match_event")
    assert event["event"]["kind"] == "goal" and event["event"]["assist"]["name"] == "Odegaard"
    assert event["match"]["home_score"] == 1
    seqs = [message["seq"] for _, message in fake_redis.published]
    assert seqs == sorted(seqs) and len(set(seqs)) == len(seqs)


def test_corrected_event_is_published_as_an_update(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1, events=[GOAL])]))
    fake_redis.published.clear()

    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1, events=[{**GOAL, "minute": 13}])]))

    (event,) = fake_redis.messages(pubsub.EVENTS_CHANNEL, "match_event")
    assert event["updated"] is True and event["event"]["minute"] == 13
    assert MatchEvent.objects.get().minute == 13


def test_unchanged_cycle_publishes_nothing(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture(events=[GOAL])]))
    fake_redis.published.clear()
    sync.sync_live_scores(FakeClient(inplay=[fixture(events=[GOAL])]))
    assert fake_redis.published == []


def test_removed_event_is_announced_for_var_decisions(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1, events=[GOAL])]))
    fake_redis.published.clear()

    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=0, events=[])]))

    (removed,) = fake_redis.messages(pubsub.EVENTS_CHANNEL, "event_removed")
    assert removed["event_ids"] == [1]
    (update,) = fake_redis.messages(pubsub.LIVE_CHANNEL, "match_update")
    assert update["changes"]["score"] == {"from": "1-0", "to": "0-0"}


def test_card_substitution_and_var_kinds(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture()]))
    fake_redis.published.clear()
    events = [
        {"id": 2, "type": {"developer_name": "YELLOWCARD"}, "player_id": 11, "participant_id": 2, "minute": 20},
        {"id": 3, "type": {"developer_name": "SUBSTITUTION"}, "player_id": 12, "related_player_id": 13,
         "participant_id": 1, "minute": 25},
        {"id": 4, "type": {"developer_name": "VAR"}, "player_id": 9, "participant_id": 1, "minute": 26},
    ]
    sync.sync_live_scores(FakeClient(inplay=[fixture(events=events)]))
    kinds = [m["event"]["kind"] for m in fake_redis.messages(pubsub.EVENTS_CHANNEL, "match_event")]
    assert kinds == ["card", "substitution", "var"]


def test_finished_match_is_announced_and_leaves_the_snapshot(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture(match_id=200)]))
    fake_redis.published.clear()
    finished = fixture(match_id=200, state="FT", home_goals=2, periods=[
        {"started": 1792609260, "ended": 1792616000, "ticking": False, "minutes": 90},
    ])

    sync.sync_live_scores(FakeClient(inplay=[], multi={200: finished}))

    (update,) = fake_redis.messages(pubsub.LIVE_CHANNEL, "match_update")
    assert update["changes"]["status"] == {"from": "LIVE", "to": "FT"}
    assert snapshot_matches(fake_redis) == []


def test_snapshot_sequence_is_read_before_matches_are_built(fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture()]))
    stored = json.loads(fake_redis.store[pubsub.SNAPSHOT_KEY])
    assert stored["type"] == "snapshot" and stored["seq"] == 1


def test_redis_outage_never_breaks_the_database_sync(fake_redis):
    fake_redis.fail = True
    result = sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1)]))
    assert Match.objects.get().home_score == 1
    assert result["live"] == 1
    assert fake_redis.published == []


def test_fixture_sync_announces_status_changes_but_not_new_matches(fake_redis):
    sync.sync_fixtures(client=FakeClient(inplay=[fixture(state="NS")]))
    assert fake_redis.published == []

    sync.sync_fixtures(client=FakeClient(inplay=[fixture(state="POSTPONED")]))
    (update,) = fake_redis.messages(pubsub.LIVE_CHANNEL, "match_update")
    assert update["changes"]["status"] == {"from": "SCHEDULED", "to": "POSTPONED"}


def test_publishing_can_be_switched_off(fake_redis, settings):
    settings.REALTIME_PUBLISH_ENABLED = False
    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1)]))
    assert Match.objects.get().home_score == 1
    assert fake_redis.published == [] and fake_redis.store == {}


def test_should_poll_is_false_when_nothing_is_live_or_about_to_start(settings):
    settings.LIVE_ADAPTIVE_POLLING = True
    assert live.should_poll() is False
    sync.upsert_fixtures([fixture(state="FT")])
    assert live.should_poll() is False


def test_should_poll_when_a_match_is_live(settings):
    settings.LIVE_ADAPTIVE_POLLING = True
    sync.upsert_fixtures([fixture(state="INPLAY_1ST_HALF")])
    assert live.should_poll() is True


def test_should_poll_shortly_before_kickoff(settings):
    settings.LIVE_ADAPTIVE_POLLING = True
    sync.upsert_fixtures([fixture(state="NS")])
    Match.objects.update(scheduled_at=timezone.now() + timedelta(minutes=10))
    assert live.should_poll() is True
    Match.objects.update(scheduled_at=timezone.now() + timedelta(hours=5))
    assert live.should_poll() is False


def test_should_poll_always_true_when_adaptive_polling_is_off(settings):
    settings.LIVE_ADAPTIVE_POLLING = False
    assert live.should_poll() is True


def test_idle_task_skips_the_provider_call(settings):
    settings.LIVE_ADAPTIVE_POLLING = True
    assert fetch_live_scores.apply().get() == {"skipped": "idle"}
