from celery import shared_task

from apps.core.sync_utils import run_sync

from . import live, sync


@shared_task(bind=True, max_retries=1)
def fetch_live_scores(self):
    if not live.should_poll():
        return {"skipped": "idle"}
    return run_sync(self, "live_scores", sync.sync_live_scores, lock_timeout=60)


@shared_task(bind=True, max_retries=3)
def sync_fixtures(self, days_back=1, days_ahead=7):
    return run_sync(
        self, "fixtures", lambda: sync.sync_fixtures(days_back=days_back, days_ahead=days_ahead), lock_timeout=900
    )


@shared_task(bind=True, max_retries=2)
def sync_match_details(self, provider_ids=None):
    return run_sync(
        self, "match_details", lambda: sync.sync_match_details(provider_ids=provider_ids), lock_timeout=300
    )
