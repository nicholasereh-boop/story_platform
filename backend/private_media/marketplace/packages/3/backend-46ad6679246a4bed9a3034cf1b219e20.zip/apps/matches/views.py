from datetime import timedelta

from django.db.models import Prefetch, Q
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response

from apps.streams.models import MatchStream
from integrations.sportmonks.constants import LIVE_STATUSES

from .filters import MatchFilter, day_bounds, request_timezone
from .models import Lineup, Match, MatchEvent, MatchStatistic
from .serializers import (
    LineupSerializer, MatchDetailSerializer, MatchEventSerializer, MatchListSerializer,
    MatchStatisticSerializer,
)

H2H_DEFAULT_LIMIT = 10
H2H_MAX_LIMIT = 20
UPCOMING_MAX_DAYS = 60


def _int_param(request, name, default, low, high):
    raw = request.query_params.get(name)
    if raw is None:
        return default
    if not raw.isdigit() or not low <= int(raw) <= high:
        raise ValidationError({name: f"Must be a whole number between {low} and {high}."})
    return int(raw)


class MatchViewSet(viewsets.ReadOnlyModelViewSet):
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_class = MatchFilter
    ordering_fields = ["scheduled_at", "status"]
    ordering = ["scheduled_at"]

    def get_queryset(self):
        queryset = Match.objects.select_related("home_team", "away_team", "league")
        if self.action == "retrieve":
            queryset = queryset.prefetch_related(
                Prefetch("events", MatchEvent.objects.select_related("team", "player", "assist_player")),
                Prefetch("statistics", MatchStatistic.objects.select_related("team")),
                Prefetch("lineups", Lineup.objects.select_related("team", "player").order_by("-starter", "shirt_number")),
                Prefetch("streams", MatchStream.objects.filter(is_active=True)),
            )
        return queryset

    def get_serializer_class(self):
        return MatchDetailSerializer if self.action == "retrieve" else MatchListSerializer

    def _listing(self, request, queryset, ordering, paginate=True):
        self.ordering = ordering
        queryset = self.filter_queryset(queryset)
        if paginate:
            page = self.paginate_queryset(queryset)
            if page is not None:
                return self.get_paginated_response(self.get_serializer(page, many=True).data)
        return Response(self.get_serializer(queryset, many=True).data)

    @action(detail=False, methods=["get"])
    def live(self, request):
        """Matches in play right now. Not paginated: the set is small and mirrors the WebSocket snapshot."""
        queryset = self.get_queryset().filter(status__in=LIVE_STATUSES)
        return self._listing(request, queryset, ["league__name", "scheduled_at"], paginate=False)

    @action(detail=False, methods=["get"])
    def today(self, request):
        tz = request_timezone(request)
        start, end = day_bounds(timezone.now().astimezone(tz).date(), tz)
        queryset = self.get_queryset().filter(scheduled_at__gte=start, scheduled_at__lt=end)
        return self._listing(request, queryset, ["scheduled_at"])

    @action(detail=False, methods=["get"])
    def upcoming(self, request):
        now = timezone.now()
        queryset = self.get_queryset().filter(status="SCHEDULED", scheduled_at__gte=now)
        if "days" in request.query_params:
            days = _int_param(request, "days", UPCOMING_MAX_DAYS, 1, UPCOMING_MAX_DAYS)
            queryset = queryset.filter(scheduled_at__lt=now + timedelta(days=days))
        return self._listing(request, queryset, ["scheduled_at"])

    @action(detail=False, methods=["get"])
    def results(self, request):
        queryset = self.get_queryset().filter(status="FT")
        return self._listing(request, queryset, ["-scheduled_at"])

    def _match(self, pk):
        return get_object_or_404(Match.objects.select_related("home_team", "away_team"), pk=pk)

    @action(detail=True, methods=["get"])
    def events(self, request, pk=None):
        queryset = MatchEvent.objects.filter(match=self._match(pk)).select_related("team", "player", "assist_player")
        return Response(MatchEventSerializer(queryset, many=True).data)

    @action(detail=True, methods=["get"])
    def statistics(self, request, pk=None):
        queryset = MatchStatistic.objects.filter(match=self._match(pk)).select_related("team")
        return Response(MatchStatisticSerializer(queryset, many=True).data)

    @action(detail=True, methods=["get"])
    def lineups(self, request, pk=None):
        queryset = (
            Lineup.objects.filter(match=self._match(pk))
            .select_related("team", "player")
            .order_by("team_id", "-starter", "shirt_number")
        )
        return Response(LineupSerializer(queryset, many=True).data)

    @action(detail=True, methods=["get"])
    def h2h(self, request, pk=None):
        """Recent finished meetings of the two teams, with totals from this match's home side's view."""
        match = self._match(pk)
        limit = _int_param(request, "limit", H2H_DEFAULT_LIMIT, 1, H2H_MAX_LIMIT)
        home_id, away_id = match.home_team_id, match.away_team_id
        meetings = list(
            Match.objects.filter(status="FT")
            .filter(Q(home_team_id=home_id, away_team_id=away_id) | Q(home_team_id=away_id, away_team_id=home_id))
            .exclude(pk=match.pk)
            .select_related("home_team", "away_team", "league")
            .order_by("-scheduled_at")[:limit]
        )
        summary = {"played": len(meetings), "home_wins": 0, "draws": 0, "away_wins": 0, "home_goals": 0, "away_goals": 0}
        for meeting in meetings:
            if meeting.home_team_id == home_id:
                ours, theirs = meeting.home_score, meeting.away_score
            else:
                ours, theirs = meeting.away_score, meeting.home_score
            summary["home_goals"] += ours
            summary["away_goals"] += theirs
            summary["home_wins" if ours > theirs else "away_wins" if ours < theirs else "draws"] += 1
        return Response(
            {
                "home_team": match.home_team_id,
                "away_team": match.away_team_id,
                "summary": summary,
                "matches": MatchListSerializer(meetings, many=True).data,
            }
        )

