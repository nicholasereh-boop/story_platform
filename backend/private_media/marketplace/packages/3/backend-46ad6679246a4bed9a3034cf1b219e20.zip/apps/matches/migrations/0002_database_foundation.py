import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("football", "0002_database_foundation"),
        ("matches", "0001_initial"),
    ]

    operations = [
        migrations.AlterModelOptions(name="matchevent", options={"ordering": ["minute", "extra_minute", "id"]}),
        migrations.AlterField(
            model_name="match",
            name="status",
            field=models.CharField(
                choices=[
                    ("SCHEDULED", "Scheduled"),
                    ("LIVE", "Live"),
                    ("HT", "Half Time"),
                    ("ET", "Extra Time"),
                    ("PEN", "Penalties"),
                    ("FT", "Full Time"),
                    ("POSTPONED", "Postponed"),
                    ("SUSPENDED", "Suspended"),
                    ("ABANDONED", "Abandoned"),
                    ("CANCELLED", "Cancelled"),
                ],
                db_index=True,
                default="SCHEDULED",
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name="matchevent",
            name="team",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="match_events",
                to="football.team",
            ),
        ),
        migrations.AlterField(
            model_name="lineup",
            name="team",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.CASCADE,
                related_name="lineups",
                to="football.team",
            ),
        ),
        migrations.AlterField(
            model_name="lineup",
            name="player",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.CASCADE,
                related_name="lineups",
                to="football.player",
            ),
        ),
        migrations.AddIndex(
            model_name="match",
            index=models.Index(fields=["home_team", "scheduled_at"], name="matches_match_home_sched_idx"),
        ),
        migrations.AddIndex(
            model_name="match",
            index=models.Index(fields=["away_team", "scheduled_at"], name="matches_match_away_sched_idx"),
        ),
        migrations.AddIndex(
            model_name="match",
            index=models.Index(fields=["season", "scheduled_at"], name="matches_match_ssn_sched_idx"),
        ),
        migrations.AddIndex(
            model_name="matchevent",
            index=models.Index(fields=["match", "minute", "extra_minute"], name="matches_event_match_min_idx"),
        ),
        migrations.AddIndex(
            model_name="matchevent",
            index=models.Index(fields=["player", "type"], name="matches_event_plr_type_idx"),
        ),
        migrations.AddIndex(
            model_name="lineup",
            index=models.Index(fields=["match", "starter"], name="matches_lineup_start_idx"),
        ),
        migrations.AddConstraint(
            model_name="match",
            constraint=models.CheckConstraint(
                condition=~models.Q(home_team=models.F("away_team")),
                name="match_home_away_differ",
            ),
        ),
        migrations.AddConstraint(
            model_name="match",
            constraint=models.CheckConstraint(
                condition=models.Q(started_at__isnull=True)
                | models.Q(ended_at__isnull=True)
                | models.Q(ended_at__gte=models.F("started_at")),
                name="match_end_after_start",
            ),
        ),
        migrations.AddConstraint(
            model_name="match",
            constraint=models.CheckConstraint(
                condition=models.Q(minute__isnull=True) | models.Q(minute__lte=150),
                name="match_minute_lte_150",
            ),
        ),
        migrations.AddConstraint(
            model_name="matchevent",
            constraint=models.CheckConstraint(
                condition=models.Q(assist_player__isnull=True) | ~models.Q(assist_player=models.F("player")),
                name="event_assist_not_scorer",
            ),
        ),
        migrations.AddConstraint(
            model_name="matchstatistic",
            constraint=models.CheckConstraint(
                condition=models.Q(possession__isnull=True)
                | (models.Q(possession__gte=0) & models.Q(possession__lte=100)),
                name="statistic_possession_0_100",
            ),
        ),
    ]
