import logging
from datetime import timedelta

from django.conf import settings
from django.db.models import Q
from django.utils import timezone

from apps.core.cache import record_sync, set_live_match_ids
from apps.core.upsert import bulk_upsert
from apps.football.models import League, Season, Team
from apps.football.sync import ensure_players, ensure_teams
from integrations.sportmonks import constants as const
from integrations.sportmonks import normalizers as norm
from integrations.sportmonks.client import client_scope

from . import live
from .models import Lineup, Match, MatchEvent, MatchStatistic

logger = logging.getLogger(__name__)

FIXTURE_INCLUDES = "participants;scores;state;periods;venue;round"
LIVE_INCLUDES = FIXTURE_INCLUDES + ";events.type"
DETAIL_INCLUDES = "events.type;lineups;statistics.type"
MULTI_BATCH = 50

MATCH_UPDATE_FIELDS = [
    "league", "season", "home_team", "away_team", "scheduled_at", "started_at", "ended_at",
    "status", "minute", "home_score", "away_score", "home_ht_score", "away_ht_score", "venue", "round",
]
EVENT_UPDATE_FIELDS = [
    "match", "type", "minute", "extra_minute", "team", "player", "assist_player", "description",
]
LINEUP_UPDATE_FIELDS = ["position", "starter", "shirt_number"]
STATISTIC_UPDATE_FIELDS = list(const.STAT_FIELDS)


def _raw_id(raw):
    try:
        return int(raw.get("id"))
    except (TypeError, ValueError):
        return None


def _allowed(raws):
    allowed = settings.SPORTMONKS_LEAGUE_IDS
    if not allowed:
        return raws
    return [r for r in raws if r.get("league_id") in allowed]


def _match_index(raws):
    ids = [i for i in (_raw_id(r) for r in raws) if i is not None]
    matches = Match.objects.filter(provider_id__in=ids).only("id", "provider_id", "home_team_id", "away_team_id")
    return {m.provider_id: m for m in matches}


def upsert_fixtures(raws):
    fixtures = [f for f in (norm.normalize_fixture(r) for r in raws) if f]
    if not fixtures:
        return {"matches": 0, "skipped": len(raws)}

    teams = ensure_teams([f["home"] for f in fixtures] + [f["away"] for f in fixtures])
    league_map = dict(
        League.objects.filter(provider_id__in={f["league_provider_id"] for f in fixtures})
        .values_list("provider_id", "id")
    )
    season_map = dict(
        Season.objects.filter(provider_id__in={f["season_provider_id"] for f in fixtures})
        .values_list("provider_id", "id")
    )
    existing = {
        m["provider_id"]: m
        for m in Match.objects.filter(provider_id__in=[f["provider_id"] for f in fixtures]).values(
            "provider_id", "status", "started_at", "ended_at", "home_ht_score", "away_ht_score"
        )
    }

    rows = []
    for f in fixtures:
        old = existing.get(f["provider_id"], {})
        status = f["status"] or old.get("status") or "SCHEDULED"
        rows.append(
            {
                "provider_id": f["provider_id"],
                "league_id": league_map.get(f["league_provider_id"]),
                "season_id": season_map.get(f["season_provider_id"]),
                "home_team_id": teams[f["home"]["provider_id"]],
                "away_team_id": teams[f["away"]["provider_id"]],
                "scheduled_at": f["scheduled_at"],
                "started_at": f["started_at"] or old.get("started_at"),
                "ended_at": f["ended_at"] or (old.get("ended_at") if status == "FT" else None),
                "status": status,
                "minute": f["minute"],
                "home_score": f["home_score"],
                "away_score": f["away_score"],
                "home_ht_score": f["home_ht_score"] if f["home_ht_score"] is not None else old.get("home_ht_score"),
                "away_ht_score": f["away_ht_score"] if f["away_ht_score"] is not None else old.get("away_ht_score"),
                "venue": f["venue"],
                "round": f["round"],
            }
        )
    count = bulk_upsert(Match, rows, ["provider_id"], MATCH_UPDATE_FIELDS)
    return {"matches": count, "skipped": len(raws) - len(fixtures)}


def upsert_events(raws):
    matches = _match_index(raws)
    parsed = {}
    for raw in raws:
        pid = _raw_id(raw)
        if pid in matches and "events" in raw:
            parsed[pid] = [e for e in (norm.normalize_event(x) for x in raw["events"] or []) if e]

    people = []
    for events in parsed.values():
        for e in events:
            people.append({"provider_id": e["player_provider_id"], "display_name": e["player_name"]})
            people.append({"provider_id": e["assist_provider_id"], "display_name": e["assist_name"]})
    player_map = ensure_players(people)
    team_map = dict(
        Team.objects.filter(
            provider_id__in={e["team_provider_id"] for events in parsed.values() for e in events}
        ).values_list("provider_id", "id")
    )

    total = 0
    for pid, events in parsed.items():
        match = matches[pid]
        valid_teams = {match.home_team_id, match.away_team_id}
        rows = []
        for e in events:
            team_id = team_map.get(e["team_provider_id"])
            player_id = player_map.get(e["player_provider_id"])
            assist_id = player_map.get(e["assist_provider_id"])
            rows.append(
                {
                    "provider_id": e["provider_id"],
                    "match_id": match.id,
                    "type": e["type"],
                    "minute": e["minute"],
                    "extra_minute": e["extra_minute"],
                    "team_id": team_id if team_id in valid_teams else None,
                    "player_id": player_id,
                    "assist_player_id": assist_id if assist_id != player_id else None,
                    "description": e["description"],
                }
            )
        total += bulk_upsert(MatchEvent, rows, ["provider_id"], EVENT_UPDATE_FIELDS)
        MatchEvent.objects.filter(match_id=match.id).exclude(
            provider_id__in=[r["provider_id"] for r in rows]
        ).delete()
    return {"events": total}


def upsert_lineups(raws):
    matches = _match_index(raws)
    parsed = {}
    for raw in raws:
        pid = _raw_id(raw)
        if pid in matches and raw.get("lineups"):
            parsed[pid] = [x for x in (norm.normalize_lineup(l) for l in raw["lineups"]) if x]

    player_map = ensure_players(
        {"provider_id": x["player_provider_id"], "display_name": x["player_name"]}
        for entries in parsed.values() for x in entries
    )
    team_map = dict(
        Team.objects.filter(
            provider_id__in={x["team_provider_id"] for entries in parsed.values() for x in entries}
        ).values_list("provider_id", "id")
    )

    total = 0
    for pid, entries in parsed.items():
        match = matches[pid]
        valid_teams = {match.home_team_id, match.away_team_id}
        rows = []
        for x in entries:
            team_id, player_id = team_map.get(x["team_provider_id"]), player_map.get(x["player_provider_id"])
            if team_id not in valid_teams or player_id is None:
                continue
            rows.append(
                {
                    "match_id": match.id,
                    "team_id": team_id,
                    "player_id": player_id,
                    "position": x["position"],
                    "starter": x["starter"],
                    "shirt_number": x["shirt_number"],
                }
            )
        if not rows:
            continue
        total += bulk_upsert(Lineup, rows, ["match", "team", "player"], LINEUP_UPDATE_FIELDS)
        keep = {(r["team_id"], r["player_id"]) for r in rows}
        stale = [
            l.id for l in Lineup.objects.filter(match_id=match.id).only("id", "team_id", "player_id")
            if (l.team_id, l.player_id) not in keep
        ]
        Lineup.objects.filter(id__in=stale).delete()
    return {"lineups": total}


def upsert_statistics(raws):
    matches = _match_index(raws)
    parsed = {}
    for raw in raws:
        pid = _raw_id(raw)
        if pid in matches and raw.get("statistics"):
            parsed[pid] = norm.normalize_statistics(raw["statistics"])
    team_map = dict(
        Team.objects.filter(provider_id__in={t for stats in parsed.values() for t in stats})
        .values_list("provider_id", "id")
    )

    total = 0
    for pid, by_team in parsed.items():
        match = matches[pid]
        valid_teams = {match.home_team_id, match.away_team_id}
        rows = [
            {"match_id": match.id, "team_id": team_map[team_pid], **values}
            for team_pid, values in by_team.items()
            if team_map.get(team_pid) in valid_teams
        ]
        total += bulk_upsert(MatchStatistic, rows, ["match", "team"], STATISTIC_UPDATE_FIELDS)
    return {"statistics": total}


def upsert_details(raws):
    result = {}
    result.update(upsert_events(raws))
    result.update(upsert_lineups(raws))
    result.update(upsert_statistics(raws))
    return result


def sync_fixtures(days_back=1, days_ahead=7, client=None):
    today = timezone.now().date()
    start, end = today - timedelta(days=days_back), today + timedelta(days=days_ahead)
    with client_scope(client) as api:
        raws = _allowed(list(api.fixtures_between(start, end, FIXTURE_INCLUDES, settings.SPORTMONKS_LEAGUE_IDS)))
    ids = [i for i in (_raw_id(r) for r in raws) if i is not None]
    before = live.capture_state(ids, include_events=False)
    result = upsert_fixtures(raws)
    live.publish_changes(before, ids, include_events=False, announce_new=False)
    record_sync("fixtures")
    return result


def _apply_live(raws):
    ids = [i for i in (_raw_id(r) for r in raws) if i is not None]
    before = live.capture_state(ids)
    result = upsert_fixtures(raws)
    upsert_events(raws)
    return result, live.publish_changes(before, ids)


def _merge_counts(a, b):
    return {key: a.get(key, 0) + b.get(key, 0) for key in set(a) | set(b)}


def sync_live_scores(client=None):
    with client_scope(client) as api:
        raws = _allowed(list(api.livescores_inplay(LIVE_INCLUDES)))
        result, published = _apply_live(raws)

        seen = {i for i in (_raw_id(r) for r in raws) if i is not None}
        stale = list(
            Match.objects.filter(status__in=const.LIVE_STATUSES)
            .exclude(provider_id__in=seen)
            .values_list("provider_id", flat=True)
        )
        refreshed = 0
        for start in range(0, len(stale), MULTI_BATCH):
            batch = _allowed(list(api.fixtures_multi(stale[start:start + MULTI_BATCH], LIVE_INCLUDES)))
            _, extra = _apply_live(batch)
            published = _merge_counts(published, extra)
            refreshed += len(batch)

    live_ids = list(Match.objects.filter(status__in=const.LIVE_STATUSES).values_list("provider_id", flat=True))
    set_live_match_ids(live_ids)
    snapshot_matches = live.publish_snapshot()
    record_sync("live")
    return {
        **result,
        "live": len(live_ids),
        "refreshed": refreshed,
        "published": published,
        "snapshot_matches": snapshot_matches,
    }


def matches_needing_details(limit=100):
    now = timezone.now()
    return list(
        Match.objects.filter(
            Q(status__in=const.LIVE_STATUSES) | Q(scheduled_at__range=(now - timedelta(hours=3), now + timedelta(hours=2)))
        )
        .order_by("scheduled_at")
        .values_list("provider_id", flat=True)[:limit]
    )


def sync_match_details(provider_ids=None, client=None):
    ids = list(provider_ids) if provider_ids else matches_needing_details()
    result = {"events": 0, "lineups": 0, "statistics": 0}
    with client_scope(client) as api:
        for start in range(0, len(ids), MULTI_BATCH):
            raws = list(api.fixtures_multi(ids[start:start + MULTI_BATCH], DETAIL_INCLUDES))
            for key, value in upsert_details(raws).items():
                result[key] += value
    record_sync("details")
    return result
