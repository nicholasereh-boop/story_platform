import django_filters as filters

from .models import Article


class ArticleFilter(filters.FilterSet):
    league = filters.NumberFilter(field_name="leagues__id")
    team = filters.NumberFilter(field_name="teams__id")
    player = filters.NumberFilter(field_name="players__id")
    category = filters.ChoiceFilter(choices=Article.CATEGORY_CHOICES)

    class Meta:
        model = Article
        fields = ["league", "team", "player", "category"]
