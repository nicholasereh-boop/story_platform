from rest_framework import serializers

from apps.football.serializers import LeagueMiniSerializer, PlayerMiniSerializer, TeamMiniSerializer

from .models import Article


class ArticleListSerializer(serializers.ModelSerializer):
    leagues = LeagueMiniSerializer(many=True, read_only=True)
    teams = TeamMiniSerializer(many=True, read_only=True)
    players = PlayerMiniSerializer(many=True, read_only=True)

    class Meta:
        model = Article
        fields = ("id", "slug", "title", "summary", "image", "category", "published_at", "leagues", "teams", "players")


class ArticleDetailSerializer(ArticleListSerializer):
    related = serializers.SerializerMethodField()

    class Meta(ArticleListSerializer.Meta):
        fields = (*ArticleListSerializer.Meta.fields, "body", "source_name", "source_url", "related")

    def get_related(self, article):
        return self.context.get("related", [])
