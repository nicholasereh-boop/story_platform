from django.db.models import Q
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets
from rest_framework.filters import SearchFilter
from rest_framework.response import Response

from .filters import ArticleFilter
from .models import Article
from .serializers import ArticleDetailSerializer, ArticleListSerializer

RELATED_LIMIT = 4


class ArticleViewSet(viewsets.ReadOnlyModelViewSet):
    """Public, read-only news. Articles are written in the admin."""

    lookup_field = "slug"
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_class = ArticleFilter
    search_fields = ["title", "summary"]
    serializer_class = ArticleListSerializer

    def get_queryset(self):
        queryset = Article.objects.visible().prefetch_related("leagues", "teams", "players")
        if self.action == "list":
            queryset = queryset.defer("body")
        return queryset

    def retrieve(self, request, *args, **kwargs):
        article = self.get_object()
        context = {**self.get_serializer_context(), "related": self._related(article)}
        return Response(ArticleDetailSerializer(article, context=context).data)

    def _related(self, article):
        """Other recent articles about the same teams, leagues or players."""
        links = (
            Q(teams__in=article.teams.all()) | Q(leagues__in=article.leagues.all()) | Q(players__in=article.players.all())
        )
        rows = (
            Article.objects.visible()
            .filter(links)
            .exclude(pk=article.pk)
            .distinct()
            .order_by("-published_at", "-id")
            .defer("body")
            .prefetch_related("leagues", "teams", "players")[:RELATED_LIMIT]
        )
        return ArticleListSerializer(rows, many=True, context={"request": self.request}).data
