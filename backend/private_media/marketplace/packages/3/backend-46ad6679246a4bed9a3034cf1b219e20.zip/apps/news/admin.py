from django.contrib import admin
from django.utils import timezone

from .models import Article


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("title", "category", "status", "published_at", "author")
    list_filter = ("status", "category")
    search_fields = ("title", "summary", "body")
    date_hierarchy = "published_at"
    prepopulated_fields = {"slug": ("title",)}
    autocomplete_fields = ("leagues", "teams", "players")
    readonly_fields = ("author", "created_at", "updated_at")
    actions = ["publish_now", "move_to_drafts"]
    fieldsets = (
        (None, {"fields": ("title", "slug", "summary", "body", "image", "category")}),
        ("Links", {"fields": ("leagues", "teams", "players")}),
        ("Publishing", {"fields": ("status", "published_at", "source_name", "source_url")}),
        ("Record", {"fields": ("author", "created_at", "updated_at")}),
    )

    def save_model(self, request, obj, form, change):
        if not change and obj.author_id is None:
            obj.author = request.user
        super().save_model(request, obj, form, change)

    @admin.action(description="Publish selected articles now")
    def publish_now(self, request, queryset):
        count = 0
        for article in queryset.exclude(status=Article.PUBLISHED):
            article.status = Article.PUBLISHED
            article.published_at = timezone.now()
            article.save()
            count += 1
        self.message_user(request, f"Published {count} article(s).")

    @admin.action(description="Move selected articles back to drafts")
    def move_to_drafts(self, request, queryset):
        self.message_user(request, f"Moved {queryset.update(status=Article.DRAFT)} article(s) to drafts.")
