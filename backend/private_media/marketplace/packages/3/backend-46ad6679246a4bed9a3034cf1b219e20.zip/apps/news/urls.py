from rest_framework.routers import SimpleRouter

from .views import ArticleViewSet

router = SimpleRouter()
router.register("news", ArticleViewSet, basename="news")
urlpatterns = router.urls
