import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("football", "0003_search_indexes"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Article",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=200)),
                ("slug", models.SlugField(blank=True, max_length=220, unique=True)),
                ("summary", models.CharField(blank=True, max_length=300)),
                ("body", models.TextField(help_text="Plain text. A blank line starts a new paragraph.")),
                ("image", models.URLField(blank=True)),
                (
                    "category",
                    models.CharField(choices=[("general", "General"), ("transfer", "Transfer")], default="general", max_length=20),
                ),
                (
                    "status",
                    models.CharField(choices=[("draft", "Draft"), ("published", "Published")], default="draft", max_length=10),
                ),
                (
                    "published_at",
                    models.DateTimeField(
                        blank=True, null=True,
                        help_text="Leave empty to publish immediately; set a future time to schedule.",
                    ),
                ),
                ("source_name", models.CharField(blank=True, max_length=100)),
                ("source_url", models.URLField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "author",
                    models.ForeignKey(
                        blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                        related_name="articles", to=settings.AUTH_USER_MODEL,
                    ),
                ),
                ("leagues", models.ManyToManyField(blank=True, related_name="articles", to="football.league")),
                ("players", models.ManyToManyField(blank=True, related_name="articles", to="football.player")),
                ("teams", models.ManyToManyField(blank=True, related_name="articles", to="football.team")),
            ],
            options={"ordering": ["-published_at", "-id"]},
        ),
        migrations.AddIndex(
            model_name="article",
            index=models.Index(fields=["status", "-published_at"], name="news_status_pub_idx"),
        ),
        migrations.AddConstraint(
            model_name="article",
            constraint=models.CheckConstraint(
                condition=models.Q(("status", "draft"), ("published_at__isnull", False), _connector="OR"),
                name="news_published_has_time",
            ),
        ),
    ]
