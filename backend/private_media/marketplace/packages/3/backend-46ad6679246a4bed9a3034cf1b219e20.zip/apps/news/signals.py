from django.db.models.signals import m2m_changed, post_delete, post_save

from apps.core.apicache import invalidate

from .models import Article


def _retire_news_cache(**kwargs):
    invalidate("news")


def connect():
    post_save.connect(_retire_news_cache, sender=Article, dispatch_uid="news_saved")
    post_delete.connect(_retire_news_cache, sender=Article, dispatch_uid="news_deleted")
    for field in (Article.leagues, Article.teams, Article.players):
        m2m_changed.connect(_retire_news_cache, sender=field.through, dispatch_uid=f"news_links_{field.field.name}")
