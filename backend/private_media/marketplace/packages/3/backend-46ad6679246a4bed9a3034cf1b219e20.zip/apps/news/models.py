from django.conf import settings
from django.db import models
from django.db.models import Q
from django.utils import timezone
from django.utils.text import slugify


class ArticleQuerySet(models.QuerySet):
    def visible(self, now=None):
        """Published articles whose publish time has arrived (so articles can be scheduled)."""
        return self.filter(status=Article.PUBLISHED, published_at__lte=now or timezone.now())


class Article(models.Model):
    DRAFT, PUBLISHED = "draft", "published"
    STATUS_CHOICES = [(DRAFT, "Draft"), (PUBLISHED, "Published")]
    GENERAL, TRANSFER = "general", "transfer"
    CATEGORY_CHOICES = [(GENERAL, "General"), (TRANSFER, "Transfer")]

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.CharField(max_length=300, blank=True)
    body = models.TextField(help_text="Plain text. A blank line starts a new paragraph.")
    image = models.URLField(blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default=GENERAL)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=DRAFT)
    published_at = models.DateTimeField(null=True, blank=True, help_text="Leave empty to publish immediately; set a future time to schedule.")
    source_name = models.CharField(max_length=100, blank=True)
    source_url = models.URLField(blank=True)

    leagues = models.ManyToManyField("football.League", blank=True, related_name="articles")
    teams = models.ManyToManyField("football.Team", blank=True, related_name="articles")
    players = models.ManyToManyField("football.Player", blank=True, related_name="articles")

    author = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="articles")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ArticleQuerySet.as_manager()

    class Meta:
        ordering = ["-published_at", "-id"]
        indexes = [models.Index(fields=["status", "-published_at"], name="news_status_pub_idx")]
        constraints = [
            models.CheckConstraint(
                condition=Q(status="draft") | Q(published_at__isnull=False),
                name="news_published_has_time",
            ),
        ]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if self.status == self.PUBLISHED and self.published_at is None:
            self.published_at = timezone.now()
        if not self.slug:
            self.slug = self.unique_slug(self.title)
        super().save(*args, **kwargs)

    @classmethod
    def unique_slug(cls, title):
        base = (slugify(title) or "article")[:200]
        slug, number = base, 2
        while cls.objects.filter(slug=slug).exists():
            slug = f"{base}-{number}"
            number += 1
        return slug
