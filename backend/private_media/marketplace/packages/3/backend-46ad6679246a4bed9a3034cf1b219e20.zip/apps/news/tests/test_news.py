from datetime import timedelta

import pytest
from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Player, Team
from apps.news.models import Article

pytestmark = pytest.mark.django_db
URL = "/api/v1/news/"
_ids = iter(range(1, 10000))


@pytest.fixture
def client():
    return APIClient()


def article(title="Headline", hours_ago=1, status="published", **extra):
    published_at = timezone.now() - timedelta(hours=hours_ago) if status == "published" else None
    return Article.objects.create(title=title, body="First paragraph.\n\nSecond paragraph.", status=status, published_at=published_at, **extra)


def team(name="Arsenal"):
    return Team.objects.create(provider_id=next(_ids), name=name)


def titles(response):
    return [row["title"] for row in response.json()["results"]]


def test_slug_is_generated_and_made_unique():
    first, second = article("Big Win!"), article("Big Win!")
    assert first.slug == "big-win" and second.slug == "big-win-2"
    assert article("???").slug == "article"


def test_publishing_stamps_the_time_and_drafts_need_none():
    live = Article.objects.create(title="Live", body="x", status="published")
    assert live.published_at is not None
    draft = Article.objects.create(title="Draft", body="x")
    assert draft.published_at is None
    with pytest.raises(IntegrityError), transaction.atomic():
        Article.objects.filter(pk=draft.pk).update(status="published")


def test_only_published_articles_whose_time_has_come_are_listed(client):
    article("Out now", hours_ago=2)
    article("Draft", status="draft")
    article("Scheduled", hours_ago=-5)
    assert titles(client.get(URL)) == ["Out now"]


def test_list_is_public_paginated_and_newest_first(client):
    article("Old", hours_ago=30)
    article("New", hours_ago=1)
    article("Middle", hours_ago=10)
    data = client.get(URL).json()
    assert data["count"] == 3
    assert [row["title"] for row in data["results"]] == ["New", "Middle", "Old"]
    assert "body" not in data["results"][0]
    assert set(data["results"][0]) == {
        "id", "slug", "title", "summary", "image", "category", "published_at", "leagues", "teams", "players",
    }


def test_detail_has_the_body_and_hides_unpublished_articles(client):
    live, draft = article("Live"), article("Secret", status="draft")
    data = client.get(f"{URL}{live.slug}/").json()
    assert data["body"].startswith("First paragraph.") and data["related"] == []
    assert client.get(f"{URL}{draft.slug}/").status_code == 404
    assert client.get(f"{URL}missing/").status_code == 404
    scheduled = article("Soon", hours_ago=-3)
    assert client.get(f"{URL}{scheduled.slug}/").status_code == 404


def test_filters_by_team_league_player_and_category(client):
    arsenal, spurs = team("Arsenal"), team("Spurs")
    league = League.objects.create(provider_id=1, name="Premier League")
    saka = Player.objects.create(provider_id=1, display_name="Saka")
    a = article("Arsenal news")
    a.teams.add(arsenal)
    b = article("League news")
    b.leagues.add(league)
    c = article("Saka news", category="transfer")
    c.players.add(saka)
    c.teams.add(arsenal)
    article("Unrelated")
    assert sorted(titles(client.get(URL, {"team": arsenal.id}))) == ["Arsenal news", "Saka news"]
    assert titles(client.get(URL, {"team": spurs.id})) == []
    assert titles(client.get(URL, {"league": league.id})) == ["League news"]
    assert titles(client.get(URL, {"player": saka.id})) == ["Saka news"]
    assert titles(client.get(URL, {"category": "transfer"})) == ["Saka news"]
    assert client.get(URL, {"category": "gossip"}).status_code == 400


def test_search_matches_title_and_summary(client):
    article("Arsenal sign striker")
    article("Quiet day", summary="Nothing about arsenal here")
    article("Other")
    assert sorted(titles(client.get(URL, {"search": "ARSENAL"}))) == ["Arsenal sign striker", "Quiet day"]


def test_related_articles_share_a_team_league_or_player(client):
    arsenal = team("Arsenal")
    main = article("Main", hours_ago=1)
    main.teams.add(arsenal)
    same = article("Same team", hours_ago=2)
    same.teams.add(arsenal)
    article("Unrelated", hours_ago=3)
    hidden = article("Hidden draft", status="draft")
    hidden.teams.add(arsenal)
    related = client.get(f"{URL}{main.slug}/").json()["related"]
    assert [row["title"] for row in related] == ["Same team"]


def test_related_never_repeats_an_article(client):
    arsenal, spurs = team("Arsenal"), team("Spurs")
    main, other = article("Main"), article("Other", hours_ago=2)
    main.teams.add(arsenal, spurs)
    other.teams.add(arsenal, spurs)
    assert len(client.get(f"{URL}{main.slug}/").json()["related"]) == 1


def test_articles_cannot_be_changed_through_the_api(client):
    live = article("Live")
    assert client.post(URL, {"title": "x", "body": "y"}, format="json").status_code in (401, 403, 405)
    assert client.delete(f"{URL}{live.slug}/").status_code in (401, 403, 405)
    assert Article.objects.filter(pk=live.pk).exists()


def test_list_query_count_does_not_grow_with_articles(client, django_assert_max_num_queries):
    arsenal = team()
    for index in range(10):
        row = article(f"Story {index}", hours_ago=index + 1)
        row.teams.add(arsenal)
    with django_assert_max_num_queries(6):
        assert client.get(URL).status_code == 200
