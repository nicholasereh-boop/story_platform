from celery import shared_task


@shared_task
def ping():
    return "pong"


@shared_task
def scheduled_live_sync():
    from apps.matches.tasks import fetch_live_scores

    return fetch_live_scores.delay().id
