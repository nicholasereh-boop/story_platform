import json
import os
import time

import redis
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.core.tasks import ping
from apps.core.views import check_database, check_redis

TEST_CHANNEL = "football:events"


class Command(BaseCommand):
    help = "Verify Phase 1: database, Redis, Celery, Node WebSocket relay and Sportmonks token."

    def add_arguments(self, parser):
        parser.add_argument("--skip-celery", action="store_true", help="Skip the Celery worker round-trip.")

    def line(self, name, ok, detail=""):
        text = f"[{'PASS' if ok else 'FAIL'}] {name}"
        if detail:
            text += f" - {detail}"
        self.stdout.write(self.style.SUCCESS(text) if ok else self.style.ERROR(text))
        return ok

    def handle(self, *args, **options):
        results = []

        results.append(self.line("PostgreSQL", check_database()["ok"]))
        results.append(self.line("Redis cache", check_redis()["ok"]))

        if options["skip_celery"]:
            self.stdout.write("[SKIP] Celery worker")
        else:
            try:
                answer = ping.delay().get(timeout=10)
                results.append(self.line("Celery worker", answer == "pong"))
            except Exception as exc:
                results.append(self.line("Celery worker", False, str(exc)))

        try:
            client = redis.Redis.from_url(settings.REDIS_URL)
            payload = json.dumps({"type": "setup_check", "sent_at": time.time()})
            receivers = client.publish(TEST_CHANNEL, payload)
            results.append(
                self.line(
                    "Redis Pub/Sub -> Node WebSocket",
                    receivers > 0,
                    f"{receivers} subscriber(s) on {TEST_CHANNEL}",
                )
            )
        except Exception as exc:
            results.append(self.line("Redis Pub/Sub -> Node WebSocket", False, str(exc)))

        token = os.getenv("SPORTMONKS_API_TOKEN", "")
        configured = bool(token) and token != "your_sportmonks_token"
        results.append(self.line("Sportmonks token configured", configured))

        if not all(results):
            raise CommandError("Phase 1 verification failed.")
        self.stdout.write(self.style.SUCCESS("Phase 1 verification passed."))
