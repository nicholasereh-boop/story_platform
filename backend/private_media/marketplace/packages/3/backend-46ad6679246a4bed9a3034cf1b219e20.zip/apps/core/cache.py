from django.core.cache import cache
from django.utils import timezone

LIVE_MATCH_IDS_KEY = "football:live:match_ids"
LIVE_MATCH_IDS_TTL = 60


def set_live_match_ids(provider_ids):
    cache.set(LIVE_MATCH_IDS_KEY, sorted(provider_ids), LIVE_MATCH_IDS_TTL)


def get_live_match_ids():
    return cache.get(LIVE_MATCH_IDS_KEY, [])


def record_sync(name):
    cache.set(f"sync:last:{name}", timezone.now().isoformat(), None)


def last_sync(name):
    return cache.get(f"sync:last:{name}")
