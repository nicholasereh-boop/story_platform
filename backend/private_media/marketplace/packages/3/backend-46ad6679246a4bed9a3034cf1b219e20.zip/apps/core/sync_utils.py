from apps.core.apicache import invalidate
from apps.core.locks import single_flight
from integrations.sportmonks.exceptions import SportmonksAuthError, SportmonksError, SportmonksRateLimited


# Which cached API responses go stale when a sync finishes. "live_scores" is absent on purpose: it runs
# every 15 seconds and invalidates only when something really changed (see matches.live.publish_changes).
SYNC_SCOPES = {
    "fixtures": ("matches",),
    "match_details": ("matches",),
    "leagues": ("football",),
    "teams": ("football",),
    "players": ("football",),
    "standings": ("football",),
}


def _changed(result):
    """False for an empty sync, so quiet minutes keep the cache warm."""
    if not isinstance(result, dict):
        return True
    numbers = [value for value in result.values() if isinstance(value, (int, float)) and not isinstance(value, bool)]
    return any(numbers) if numbers else True


def run_sync(task, lock_name, func, lock_timeout=600):
    with single_flight(lock_name, lock_timeout) as acquired:
        if not acquired:
            return {"skipped": True}
        try:
            result = func()
            if lock_name in SYNC_SCOPES and _changed(result):
                invalidate(*SYNC_SCOPES[lock_name])
            return result
        except SportmonksAuthError:
            raise
        except SportmonksRateLimited as exc:
            raise task.retry(exc=exc, countdown=max(exc.retry_after, 5))
        except SportmonksError as exc:
            raise task.retry(exc=exc, countdown=5 * 2 ** task.request.retries)
