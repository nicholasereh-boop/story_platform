"""Security middleware: response headers for the API, and login lockout for the token endpoint and the admin."""
import json
import logging

from django.conf import settings
from django.core.cache import cache
from django.http import JsonResponse
from django.urls import NoReverseMatch, reverse
from django.contrib.auth.signals import user_login_failed
from django.dispatch import receiver
from rest_framework.throttling import BaseThrottle

logger = logging.getLogger(__name__)

TOKEN_PATH = "/api/v1/token/"
# The browsable docs need scripts and styles, so they keep their own policy.
DOC_PATHS = ("/api/docs/", "/api/schema/")
API_CSP = "default-src 'none'; frame-ancestors 'none'"
PERMISSIONS_POLICY = "camera=(), microphone=(), geolocation=(), payment=(), usb=()"


class SecurityHeadersMiddleware:
    """JSON never needs to run scripts or be framed, so say so. Views can still set their own value."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.setdefault("Permissions-Policy", PERMISSIONS_POLICY)
        if request.path.startswith("/api/v1/") or request.path == "/api/v1":
            response.setdefault("Content-Security-Policy", API_CSP)
        return response


# --- login lockout -----------------------------------------------------------------------------------------------
#
# Failures are counted per (address, account) so one attacker cannot lock a victim out from elsewhere, and per
# address overall so one address cannot walk through many accounts. Throttling (10/min) slows guessing; the
# lockout stops it. The cache is shared across workers; if it is down the check fails open rather than
# locking everyone out of the site.


def client_ip(request):
    return BaseThrottle().get_ident(request)


def normalize(identifier):
    return str(identifier or "").strip().lower()[:150]


def _account_key(ip, identifier):
    return f"login-fail:{ip}:{normalize(identifier)}"


def _ip_key(ip):
    return f"login-fail-ip:{ip}"


def record_failure(ip, identifier):
    window = settings.LOGIN_LOCKOUT_SECONDS
    for key in (_account_key(ip, identifier), _ip_key(ip)):
        try:
            if cache.add(key, 1, window):
                continue
            cache.incr(key)
        except Exception:
            logger.warning("Could not record a failed login", exc_info=True)
            return


def clear(ip, identifier):
    try:
        cache.delete(_account_key(ip, identifier))
    except Exception:
        logger.warning("Could not clear failed logins", exc_info=True)


def is_locked(ip, identifier):
    try:
        account = cache.get(_account_key(ip, identifier), 0)
        overall = cache.get(_ip_key(ip), 0)
    except Exception:
        logger.warning("Could not read failed logins", exc_info=True)
        return False
    return account >= settings.LOGIN_LOCKOUT_FAILURES or overall >= settings.LOGIN_LOCKOUT_IP_FAILURES


@receiver(user_login_failed)
def _count_failed_login(sender, credentials=None, request=None, **kwargs):
    """Fires for the token endpoint and the admin login alike."""
    if request is None:
        return
    credentials = credentials or {}
    record_failure(client_ip(request), credentials.get("username") or credentials.get("email"))


def _admin_login_path():
    try:
        return reverse("admin:login")
    except NoReverseMatch:
        return None


def _canonical(identifier):
    """The login form accepts an email too, and failures are recorded under the account's username
    (see LoginSerializer), so an email must be resolved the same way before the lock is checked."""
    identifier = str(identifier or "").strip()
    if "@" in identifier:
        from django.contrib.auth import get_user_model

        match = get_user_model().objects.filter(email__iexact=identifier).order_by("id").first()
        if match:
            return match.get_username()
    return identifier


def _submitted_identifier(request, api):
    if not api:
        return request.POST.get("username", "")
    try:
        body = json.loads(request.body or b"{}")
    except (ValueError, UnicodeDecodeError):
        return ""
    return _canonical(body.get("username", "")) if isinstance(body, dict) else ""


class LoginLockoutMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method != "POST":
            return self.get_response(request)
        api = request.path == TOKEN_PATH
        if not api and request.path != _admin_login_path():
            return self.get_response(request)

        ip = client_ip(request)
        identifier = _submitted_identifier(request, api)
        if is_locked(ip, identifier):
            logger.warning("Login locked out for %s", ip)
            response = JsonResponse(
                {"detail": "Too many failed sign-in attempts. Try again later."}, status=429
            )
            response["Retry-After"] = str(settings.LOGIN_LOCKOUT_SECONDS)
            return response

        response = self.get_response(request)
        if response.status_code == 200 and api or (not api and response.status_code == 302):
            clear(ip, identifier)
        return response
