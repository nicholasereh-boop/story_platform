import json

from django.core.management.base import BaseCommand, CommandError

from apps.football import sync as football_sync
from apps.matches import sync as match_sync
from integrations.sportmonks.exceptions import SportmonksError

ALL_ORDER = ["leagues", "teams", "fixtures", "standings", "players", "details"]


class Command(BaseCommand):
    help = "Run Sportmonks synchronization steps synchronously (bootstrap and backfill)."

    def add_arguments(self, parser):
        parser.add_argument("target", choices=ALL_ORDER + ["live", "all"])
        parser.add_argument("--days-back", type=int, default=1)
        parser.add_argument("--days-ahead", type=int, default=7)

    def handle(self, *args, **options):
        steps = {
            "leagues": football_sync.sync_leagues,
            "teams": football_sync.sync_teams,
            "players": football_sync.sync_players,
            "standings": football_sync.sync_standings,
            "fixtures": lambda: match_sync.sync_fixtures(
                days_back=options["days_back"], days_ahead=options["days_ahead"]
            ),
            "live": match_sync.sync_live_scores,
            "details": match_sync.sync_match_details,
        }
        order = ALL_ORDER if options["target"] == "all" else [options["target"]]
        try:
            for name in order:
                self.stdout.write(f"{name}: {json.dumps(steps[name]())}")
        except SportmonksError as exc:
            raise CommandError(str(exc))
