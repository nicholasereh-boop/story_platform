from contextlib import contextmanager

from django.core.cache import cache


@contextmanager
def single_flight(name, timeout=300):
    key = f"lock:{name}"
    acquired = cache.add(key, "1", timeout)
    try:
        yield acquired
    finally:
        if acquired:
            cache.delete(key)
