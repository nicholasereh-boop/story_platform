import json
import logging

import redis
from django.conf import settings
from django.utils import timezone

logger = logging.getLogger(__name__)

LIVE_CHANNEL = "football:live"
EVENTS_CHANNEL = "football:events"
SNAPSHOT_KEY = "football:live:snapshot"
SNAPSHOT_TTL = 120
SEQ_KEY = "football:live:seq"

PUBLISH_LUA = """
local seq = redis.call('INCR', KEYS[1])
local message = string.gsub(ARGV[2], '^{"v":1,"seq":0', '{"v":1,"seq":' .. seq, 1)
redis.call('PUBLISH', ARGV[1], message)
return seq
"""

_client = None


def get_client():
    global _client
    if _client is None:
        _client = redis.Redis.from_url(settings.REDIS_URL, socket_connect_timeout=2, socket_timeout=2)
    return _client


def _default(value):
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def _dumps(payload):
    return json.dumps(payload, separators=(",", ":"), default=_default)


def publish(channel, payload):
    if not settings.REALTIME_PUBLISH_ENABLED:
        return 0
    try:
        return get_client().publish(channel, _dumps(payload))
    except redis.RedisError:
        logger.warning("Could not publish to %s", channel, exc_info=True)
        return 0


def store_snapshot(payload):
    if not settings.REALTIME_PUBLISH_ENABLED:
        return False
    try:
        get_client().set(SNAPSHOT_KEY, _dumps(payload), ex=SNAPSHOT_TTL)
        return True
    except redis.RedisError:
        logger.warning("Could not store live snapshot", exc_info=True)
        return False


def publish_sequenced(channel, payload):
    if not settings.REALTIME_PUBLISH_ENABLED:
        return False
    envelope = {"v": 1, "seq": 0, "sent_at": timezone.now().isoformat(), **payload}
    try:
        get_client().register_script(PUBLISH_LUA)(keys=[SEQ_KEY], args=[channel, _dumps(envelope)])
        return True
    except redis.RedisError:
        logger.warning("Could not publish %s to %s", payload.get("type"), channel, exc_info=True)
        return False


def current_seq():
    try:
        return int(get_client().get(SEQ_KEY) or 0)
    except redis.RedisError:
        logger.warning("Could not read live sequence", exc_info=True)
        return 0
