"""Response cache for the public, read-only API.

Redis -> Django -> PostgreSQL gets a shared cache in the middle: identical requests inside the cache period
are answered from Redis without touching the database. Three things keep it correct:

* only the rules in RULES are cached, and only public data, so one user's data is never served to another;
* every cached entry is stamped with its scope's version, and a sync or an edit bumps the version
  (`invalidate`), which retires all of that scope's entries at once;
* the cache period is the backstop for anything that changes without a bump.

The same rules set Cache-Control, so browsers and a CDN in front of Django hold responses for the same time.
"""
import hashlib
import logging
import re
import time
from urllib.parse import urlencode

from django.conf import settings
from django.core.cache import cache
from django.http import HttpResponse

logger = logging.getLogger(__name__)

API = r"^/api/v1/"
SECOND, MINUTE, HOUR = 1, 60, 3600

# (path pattern, scope, seconds). The first matching rule wins, so specific rules come first.
RULES = [
    # Live scores: seconds
    (rf"{API}matches/live/$", "matches", 5 * SECOND),
    (rf"{API}matches/\d+/$", "matches", 15 * SECOND),
    (rf"{API}matches/\d+/(events|statistics|lineups)/$", "matches", 30 * SECOND),
    # Today's fixtures and upcoming matches: minutes
    (rf"{API}matches/(today|upcoming)/$", "matches", 1 * MINUTE),
    (rf"{API}matches/$", "matches", 1 * MINUTE),
    # Historical data: finished matches and head-to-head change rarely
    (rf"{API}matches/results/$", "matches", 5 * MINUTE),
    (rf"{API}matches/\d+/h2h/$", "matches", 5 * MINUTE),
    # Standings and statistics: minutes
    (rf"{API}leagues/\d+/standings/$", "football", 5 * MINUTE),
    (rf"{API}standings/$", "football", 5 * MINUTE),
    (rf"{API}(leagues|teams|players)/\d+/statistics/$", "football", 5 * MINUTE),
    # Teams, players, leagues, seasons and squads: hours
    (rf"{API}teams/\d+/squad/$", "football", 1 * HOUR),
    (rf"{API}leagues/\d+/teams/$", "football", 1 * HOUR),
    (rf"{API}(leagues|teams|players|seasons)/(\d+/)?$", "football", 1 * HOUR),
    # News (also retired the moment an article is saved) and search
    (rf"{API}news/", "news", 1 * MINUTE),
    (rf"{API}search/$", "search", 30 * SECOND),
]
COMPILED = [(re.compile(pattern), scope, ttl) for pattern, scope, ttl in RULES]

# Per-user or sensitive: never stored by Redis, a browser or a CDN. The admin prefix follows ADMIN_URL.
PRIVATE_PREFIXES = ("/api/v1/my/", "/api/v1/auth/", "/api/v1/token/", "/api/v1/admin-panel/")


def private_prefixes():
    return PRIVATE_PREFIXES + ("/" + settings.ADMIN_URL,)

MAX_BODY_BYTES = 1_000_000
VERSION_KEY = "apicache:version:{scope}"


def match_rule(path):
    """(scope, seconds) for a cacheable path, else None."""
    for pattern, scope, ttl in COMPILED:
        if pattern.match(path):
            return scope, ttl
    return None


def _version(scope):
    return cache.get(VERSION_KEY.format(scope=scope), 0)


def invalidate(*scopes):
    """Retires every cached response of these scopes. Safe to call anywhere; never raises."""
    for scope in scopes:
        try:
            cache.set(VERSION_KEY.format(scope=scope), time.time_ns(), None)
        except Exception:
            logger.warning("Could not invalidate the %s cache", scope, exc_info=True)


def make_key(scope, request):
    query = urlencode(sorted(request.GET.lists()), doseq=True)
    raw = f"{request.path}?{query}|{request.headers.get('Accept', '')}"
    digest = hashlib.sha1(raw.encode()).hexdigest()
    return f"apicache:{scope}:{_version(scope)}:{digest}"


def _safe_get(key):
    try:
        return cache.get(key)
    except Exception:
        logger.warning("API cache read failed", exc_info=True)
        return None


def _safe_set(key, value, ttl):
    try:
        cache.set(key, value, ttl)
    except Exception:
        logger.warning("API cache write failed", exc_info=True)


def _public(response, ttl):
    response["Cache-Control"] = f"public, max-age={ttl}, s-maxage={ttl}"


class PublicCacheMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith(private_prefixes()):
            response = self.get_response(request)
            response["Cache-Control"] = "private, no-store"
            return response

        rule = match_rule(request.path) if request.method == "GET" else None
        if rule is None or not settings.PUBLIC_CACHE_ENABLED:
            return self.get_response(request)

        scope, ttl = rule
        key = make_key(scope, request)
        entry = _safe_get(key)
        if entry is not None:
            response = HttpResponse(entry["content"], content_type=entry["content_type"])
            response["X-Cache"] = "HIT"
            _public(response, ttl)
            return response

        response = self.get_response(request)
        content_type = response.get("Content-Type", "")
        if (
            response.status_code == 200
            and content_type.startswith("application/json")
            and not response.streaming
            and len(response.content) <= MAX_BODY_BYTES
        ):
            _safe_set(key, {"content": response.content, "content_type": content_type}, ttl)
            response["X-Cache"] = "MISS"
            _public(response, ttl)
        return response
