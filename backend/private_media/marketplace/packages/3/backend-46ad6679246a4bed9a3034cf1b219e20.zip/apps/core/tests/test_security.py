import jwt
import pytest
from django.conf import settings as django_settings
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.exceptions import ImproperlyConfigured
from django.test import RequestFactory
from django.urls import resolve
from rest_framework.test import APIClient

from apps.core import apicache, security
from apps.users.tasks import flush_expired_tokens
from config.settings import security as checks

pytestmark = pytest.mark.django_db
TOKEN = "/api/v1/token/"
ME = "/api/v1/auth/me/"
STRONG = "k9#Vq2$Lx7!pZ4@mT8^wB1&nC6*rD3(eF5)gH0+jY_uI-oA=sQ~"


@pytest.fixture(autouse=True)
def clean_cache():
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def user():
    return get_user_model().objects.create_user("ada", "ada@example.com", "S3cure-passw0rd!")


def login(password, username="ada", ip="10.0.0.1"):
    return APIClient().post(TOKEN, {"username": username, "password": password}, format="json", REMOTE_ADDR=ip)


def good(**kwargs):
    return login("S3cure-passw0rd!", **kwargs)


# --- production configuration checks ---------------------------------------------------------------------------

def config(**overrides):
    base = dict(
        secret_key=STRONG, jwt_signing_key=STRONG, allowed_hosts=["scores.example.com"],
        cors_origins=["https://scores.example.com"], csrf_origins=["https://scores.example.com"],
        db_password="a-long-random-db-password", admin_url="ops-7f3k2/", debug=False,
    )
    return {**base, **overrides}


def test_a_sound_production_configuration_has_no_problems():
    assert checks.production_problems(**config()) == []
    checks.enforce_production(**config())


@pytest.mark.parametrize(
    "override, fragment",
    [
        ({"secret_key": "unsafe-development-key", "jwt_signing_key": "unsafe-development-key"}, "DJANGO_SECRET_KEY"),
        ({"secret_key": "short", "jwt_signing_key": "short"}, "DJANGO_SECRET_KEY"),
        ({"secret_key": "a" * 60, "jwt_signing_key": "a" * 60}, "DJANGO_SECRET_KEY"),
        ({"secret_key": "django-insecure-" + STRONG, "jwt_signing_key": "django-insecure-" + STRONG}, "DJANGO_SECRET_KEY"),
        ({"jwt_signing_key": "weak"}, "JWT_SIGNING_KEY"),
        ({"allowed_hosts": []}, "DJANGO_ALLOWED_HOSTS"),
        ({"allowed_hosts": ["*"]}, "DJANGO_ALLOWED_HOSTS"),
        ({"cors_origins": ["http://scores.example.com"]}, "CORS_ALLOWED_ORIGINS"),
        ({"cors_origins": ["*"]}, "CORS_ALLOWED_ORIGINS"),
        ({"csrf_origins": ["http://scores.example.com"]}, "CSRF_TRUSTED_ORIGINS"),
        ({"db_password": "postgres"}, "POSTGRES_PASSWORD"),
        ({"db_password": ""}, "POSTGRES_PASSWORD"),
        ({"admin_url": "admin/"}, "ADMIN_URL"),
        ({"debug": True}, "DJANGO_DEBUG"),
    ],
)
def test_each_unsafe_setting_is_reported(override, fragment):
    problems = checks.production_problems(**config(**override))
    assert any(fragment in problem for problem in problems), problems
    with pytest.raises(ImproperlyConfigured):
        checks.enforce_production(**config(**override))


def test_a_separate_strong_jwt_key_is_accepted():
    assert checks.production_problems(**config(jwt_signing_key="Zx" + STRONG[::-1])) == []


def test_split_csv():
    assert checks.split_csv(" a, ,b ") == ["a", "b"]
    assert checks.split_csv(None) == []


# --- headers ---------------------------------------------------------------------------------------------------

def test_api_responses_carry_a_locked_down_content_security_policy():
    response = APIClient().get("/api/v1/health/")
    assert response["Content-Security-Policy"] == "default-src 'none'; frame-ancestors 'none'"
    assert "camera=()" in response["Permissions-Policy"]
    assert response["X-Content-Type-Options"] == "nosniff"


def test_the_admin_cannot_be_framed():
    assert APIClient().get("/" + django_settings.ADMIN_URL + "login/")["X-Frame-Options"] == "DENY"


def test_the_docs_are_routed_only_while_enabled():
    assert django_settings.API_DOCS_ENABLED is True  # the testing settings
    assert resolve("/api/docs/").url_name == "swagger-ui"


def test_the_admin_path_follows_the_setting_and_is_never_cached(settings):
    settings.ADMIN_URL = "ops-7f3k2/"
    assert apicache.private_prefixes()[-1] == "/ops-7f3k2/"
    assert "/ops-7f3k2/x".startswith(apicache.private_prefixes())


# --- login lockout ---------------------------------------------------------------------------------------------

def test_repeated_failures_lock_that_address_and_account_even_for_the_right_password(user, settings):
    settings.LOGIN_LOCKOUT_FAILURES = 3
    assert [login("wrong").status_code for _ in range(3)] == [401, 401, 401]
    locked = good()
    assert locked.status_code == 429
    assert locked["Retry-After"] == str(settings.LOGIN_LOCKOUT_SECONDS)


def test_other_accounts_and_other_addresses_are_not_locked(user, settings):
    get_user_model().objects.create_user("bob", "bob@example.com", "S3cure-passw0rd!")
    settings.LOGIN_LOCKOUT_FAILURES = 3
    for _ in range(3):
        login("wrong")
    assert good(username="bob").status_code == 200
    assert good(ip="10.0.0.2").status_code == 200


def test_the_account_name_is_matched_case_insensitively(user, settings):
    settings.LOGIN_LOCKOUT_FAILURES = 3
    for name in ("ada", "ADA", " Ada "):
        login("wrong", username=name)
    assert good().status_code == 429


def test_signing_in_with_the_email_address_is_locked_like_the_username(user, settings):
    settings.LOGIN_LOCKOUT_FAILURES = 3
    for _ in range(2):
        login("wrong", username="Ada@Example.com")
    login("wrong")  # the username form counts against the same account
    assert good(username="ada@example.com").status_code == 429
    assert good().status_code == 429


def test_a_success_before_the_limit_resets_the_count(user, settings):
    settings.LOGIN_LOCKOUT_FAILURES = 3
    login("wrong"), login("wrong")
    assert good().status_code == 200
    login("wrong"), login("wrong")
    assert good().status_code == 200


def test_one_address_cannot_walk_through_many_accounts(user, settings):
    settings.LOGIN_LOCKOUT_IP_FAILURES = 4
    for index in range(4):
        login("wrong", username=f"nobody{index}")
    assert good().status_code == 429


def test_the_lock_expires_with_the_window(user, settings):
    settings.LOGIN_LOCKOUT_FAILURES = 2
    login("wrong"), login("wrong")
    assert good().status_code == 429
    cache.clear()  # what the cache does when the window ends
    assert good().status_code == 200


def test_the_admin_login_is_locked_out_too(settings):
    settings.LOGIN_LOCKOUT_FAILURES = 3
    url = "/" + django_settings.ADMIN_URL + "login/"
    client = APIClient()
    statuses = [client.post(url, {"username": "root", "password": "no"}, REMOTE_ADDR="10.0.0.9").status_code for _ in range(4)]
    assert statuses[:3] == [200, 200, 200]  # the form is shown again
    assert statuses[3] == 429


def test_a_cache_outage_does_not_lock_everyone_out(user, settings, monkeypatch):
    settings.LOGIN_LOCKOUT_FAILURES = 1

    def down(*args, **kwargs):
        raise ConnectionError("redis is down")

    monkeypatch.setattr(cache, "get", down)
    monkeypatch.setattr(cache, "add", down)
    monkeypatch.setattr(cache, "delete", down)
    assert login("wrong").status_code == 401
    assert good().status_code == 200


def test_a_malformed_login_body_is_a_client_error_not_a_crash():
    response = APIClient().post(TOKEN, "{not json", content_type="application/json")
    assert response.status_code == 400


# --- client address behind proxies -----------------------------------------------------------------------------

def test_a_spoofed_forwarded_header_is_ignored_without_a_trusted_proxy(settings):
    settings.REST_FRAMEWORK = {**settings.REST_FRAMEWORK, "NUM_PROXIES": 0}
    request = RequestFactory().get("/", HTTP_X_FORWARDED_FOR="6.6.6.6", REMOTE_ADDR="10.0.0.1")
    assert security.client_ip(request) == "10.0.0.1"


def test_with_one_proxy_the_address_it_appended_is_used(settings):
    settings.REST_FRAMEWORK = {**settings.REST_FRAMEWORK, "NUM_PROXIES": 1}
    request = RequestFactory().get("/", HTTP_X_FORWARDED_FOR="6.6.6.6, 1.2.3.4", REMOTE_ADDR="10.0.0.1")
    assert security.client_ip(request) == "1.2.3.4"


# --- JWT -------------------------------------------------------------------------------------------------------

def test_access_tokens_are_signed_with_the_configured_key_and_algorithm(user):
    access = good().json()["access"]
    key = django_settings.SIMPLE_JWT["SIGNING_KEY"]
    assert jwt.get_unverified_header(access)["alg"] == "HS256"
    assert jwt.decode(access, key, algorithms=["HS256"])["token_type"] == "access"


def test_tampered_and_unsigned_tokens_are_rejected(user):
    access = good().json()["access"]
    payload = jwt.decode(access, options={"verify_signature": False})
    client = APIClient()
    forged = jwt.encode({**payload, "user_id": 999}, "not-the-key", algorithm="HS256")
    unsigned = jwt.encode(payload, None, algorithm="none")
    for token in (forged, unsigned, access[:-3] + "abc"):
        client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
        assert client.get(ME).status_code == 401
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")
    assert client.get(ME).status_code == 200


def test_the_refresh_token_is_single_use_after_rotation(user):
    refresh = good().json()["refresh"]
    client = APIClient()
    assert client.post("/api/v1/token/refresh/", {"refresh": refresh}, format="json").status_code == 200
    assert client.post("/api/v1/token/refresh/", {"refresh": refresh}, format="json").status_code == 401


def test_the_blacklist_cleanup_task_runs(user):
    good()
    flush_expired_tokens()
