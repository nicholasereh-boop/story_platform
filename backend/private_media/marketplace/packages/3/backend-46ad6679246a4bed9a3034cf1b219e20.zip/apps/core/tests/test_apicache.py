import pytest
from django.core.cache import cache
from django.utils import timezone
from rest_framework.test import APIClient

from apps.core import apicache
from apps.core.locks import single_flight
from apps.core.sync_utils import SYNC_SCOPES, run_sync
from apps.football.models import League, Team
from apps.matches import sync
from apps.matches.tests.test_sync import FakeClient, fixture
from apps.news.models import Article

pytestmark = pytest.mark.django_db
LEAGUES = "/api/v1/leagues/"
_ids = iter(range(1, 100000))


@pytest.fixture(autouse=True)
def cache_on(settings):
    settings.PUBLIC_CACHE_ENABLED = True
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def client():
    return APIClient()


def league(name="Premier League", **extra):
    return League.objects.create(provider_id=next(_ids), name=name, **extra)


def names(response):
    return [row["name"] for row in response.json()["results"]]


@pytest.mark.parametrize(
    "path, expected",
    [
        ("/api/v1/matches/live/", ("matches", 5)),
        ("/api/v1/matches/today/", ("matches", 60)),
        ("/api/v1/matches/upcoming/", ("matches", 60)),
        ("/api/v1/matches/", ("matches", 60)),
        ("/api/v1/matches/results/", ("matches", 300)),
        ("/api/v1/matches/12/", ("matches", 15)),
        ("/api/v1/matches/12/events/", ("matches", 30)),
        ("/api/v1/matches/12/h2h/", ("matches", 300)),
        ("/api/v1/leagues/3/standings/", ("football", 300)),
        ("/api/v1/teams/3/statistics/", ("football", 300)),
        ("/api/v1/leagues/", ("football", 3600)),
        ("/api/v1/teams/3/", ("football", 3600)),
        ("/api/v1/teams/3/squad/", ("football", 3600)),
        ("/api/v1/players/9/", ("football", 3600)),
        ("/api/v1/seasons/", ("football", 3600)),
        ("/api/v1/news/", ("news", 60)),
        ("/api/v1/news/some-story/", ("news", 60)),
        ("/api/v1/search/", ("search", 30)),
    ],
)
def test_rules_follow_the_roadmap_periods(path, expected):
    assert apicache.match_rule(path) == expected


@pytest.mark.parametrize(
    "path",
    ["/api/v1/my/favorites/", "/api/v1/auth/me/", "/api/v1/token/", "/api/v1/health/", "/admin/", "/api/v1/unknown/"],
)
def test_private_and_unlisted_paths_are_never_cached(path):
    assert apicache.match_rule(path) is None


def test_second_request_is_a_hit_and_skips_the_database(client, django_assert_num_queries):
    league()
    first = client.get(LEAGUES)
    assert first["X-Cache"] == "MISS" and first["Cache-Control"] == "public, max-age=3600, s-maxage=3600"
    with django_assert_num_queries(0):
        second = client.get(LEAGUES)
    assert second["X-Cache"] == "HIT" and second.json() == first.json()
    assert second["Content-Type"].startswith("application/json")


def test_stale_data_is_served_until_the_scope_is_invalidated(client):
    league("One")
    assert names(client.get(LEAGUES)) == ["One"]
    league("Two")  # changed behind the cache's back
    assert names(client.get(LEAGUES)) == ["One"]
    apicache.invalidate("football")
    assert sorted(names(client.get(LEAGUES))) == ["One", "Two"]


def test_invalidating_one_scope_leaves_the_others(client):
    league()
    client.get(LEAGUES)
    client.get("/api/v1/news/")
    apicache.invalidate("news")
    assert client.get(LEAGUES)["X-Cache"] == "HIT"
    assert client.get("/api/v1/news/")["X-Cache"] == "MISS"


def test_query_parameter_order_does_not_matter_but_values_do(client):
    league(country="England")
    assert client.get(LEAGUES, {"country": "England", "active": "true"})["X-Cache"] == "MISS"
    assert client.get(LEAGUES + "?active=true&country=England")["X-Cache"] == "HIT"
    assert client.get(LEAGUES, {"country": "Spain", "active": "true"})["X-Cache"] == "MISS"


def test_errors_are_not_cached(client):
    assert client.get("/api/v1/teams/9999/").status_code == 404
    Team.objects.create(id=9999, provider_id=1, name="Late arrival")
    response = client.get("/api/v1/teams/9999/")
    assert response.status_code == 200
    assert response["X-Cache"] == "MISS"


def test_private_endpoints_are_marked_no_store(client):
    for path in ("/api/v1/my/favorites/", "/api/v1/auth/me/", "/api/v1/my/notifications/unread-count/"):
        response = client.get(path)
        assert response.status_code == 401
        assert response["Cache-Control"] == "private, no-store" and "X-Cache" not in response


def test_unlisted_public_endpoints_are_left_alone(client):
    response = client.get("/api/v1/health/")
    assert "X-Cache" not in response and "public" not in response.get("Cache-Control", "")


def test_the_cache_can_be_switched_off(client, settings):
    settings.PUBLIC_CACHE_ENABLED = False
    league()
    assert "X-Cache" not in client.get(LEAGUES)
    assert "X-Cache" not in client.get(LEAGUES)


def test_a_cache_outage_never_breaks_the_api(client, monkeypatch):
    league()

    def down(*args, **kwargs):
        raise ConnectionError("redis is down")

    monkeypatch.setattr(cache, "get", down)
    monkeypatch.setattr(cache, "set", down)
    response = client.get(LEAGUES)
    assert response.status_code == 200 and names(response) == ["Premier League"]


def test_etag_gives_a_304_for_unchanged_content(client):
    league()
    first = client.get(LEAGUES)
    assert first["ETag"]
    again = client.get(LEAGUES, HTTP_IF_NONE_MATCH=first["ETag"])
    assert again.status_code == 304


def test_a_goal_retires_the_cached_live_matches(client, fake_redis):
    assert client.get("/api/v1/matches/live/").json() == []
    sync.sync_live_scores(FakeClient(inplay=[fixture()]))  # the match appears
    assert len(client.get("/api/v1/matches/live/").json()) == 1
    assert client.get("/api/v1/matches/live/")["X-Cache"] == "HIT"

    sync.sync_live_scores(FakeClient(inplay=[fixture(home_goals=1)]))  # a goal
    response = client.get("/api/v1/matches/live/")
    assert response["X-Cache"] == "MISS" and response.json()[0]["home_score"] == 1


def test_a_ticking_minute_alone_keeps_the_cache(client, fake_redis):
    sync.sync_live_scores(FakeClient(inplay=[fixture()]))
    client.get("/api/v1/matches/live/")
    ticking = fixture(periods=[{"started": 1792609260, "ended": None, "ticking": True, "minutes": 31}])
    sync.sync_live_scores(FakeClient(inplay=[ticking]))
    assert client.get("/api/v1/matches/live/")["X-Cache"] == "HIT"


def test_saving_an_article_retires_the_cached_news(client):
    assert client.get("/api/v1/news/").json()["results"] == []
    article = Article.objects.create(title="Breaking", body="x", status="published")
    assert [row["title"] for row in client.get("/api/v1/news/").json()["results"]] == ["Breaking"]
    article.teams.add(Team.objects.create(provider_id=1, name="Arsenal"))
    assert client.get("/api/v1/news/")["X-Cache"] == "MISS"
    article.delete()
    assert client.get("/api/v1/news/").json()["results"] == []


def test_a_finished_sync_retires_its_scope_but_an_empty_or_skipped_one_does_not(client):
    league()
    client.get(LEAGUES)
    run_sync(None, "leagues", lambda: {"leagues": 0, "seasons": 0})
    assert client.get(LEAGUES)["X-Cache"] == "HIT"
    with single_flight("leagues"):
        assert run_sync(None, "leagues", lambda: {"leagues": 5}) == {"skipped": True}
    assert client.get(LEAGUES)["X-Cache"] == "HIT"
    league("Another")
    run_sync(None, "leagues", lambda: {"leagues": 1, "seasons": 2})
    response = client.get(LEAGUES)
    assert response["X-Cache"] == "MISS" and len(names(response)) == 2


def test_live_sync_does_not_invalidate_through_run_sync():
    assert "live_scores" not in SYNC_SCOPES
