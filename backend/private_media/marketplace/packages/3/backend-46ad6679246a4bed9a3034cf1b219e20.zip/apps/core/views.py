from django.conf import settings
from django.core.cache import cache
from django.db import connection
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response


def _result(ok, exc=None):
    data = {"ok": ok}
    if exc is not None and settings.DEBUG:
        data["error"] = str(exc)
    return data


def check_database():
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        return _result(True)
    except Exception as exc:
        return _result(False, exc)


def check_redis():
    try:
        cache.set("health:ping", "pong", timeout=5)
        return _result(cache.get("health:ping") == "pong")
    except Exception as exc:
        return _result(False, exc)


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def health(request):
    checks = {"database": check_database(), "redis": check_redis()}
    healthy = all(item["ok"] for item in checks.values())
    return Response(
        {"status": "ok" if healthy else "degraded", "checks": checks},
        status=200 if healthy else 503,
    )
