import logging

from django.db import IntegrityError, transaction

logger = logging.getLogger(__name__)


def _value(row, field):
    return row[field] if field in row else row[f"{field}_id"]


def _lookup(row, unique_fields):
    return {(f if f in row else f"{f}_id"): _value(row, f) for f in unique_fields}


def bulk_upsert(model, rows, unique_fields, update_fields, chunk_size=500):
    unique = {}
    for row in rows:
        unique[tuple(_value(row, f) for f in unique_fields)] = row
    rows = list(unique.values())
    update_fields = list(update_fields) + ["updated_at"]
    done = 0
    for start in range(0, len(rows), chunk_size):
        chunk = rows[start:start + chunk_size]
        try:
            with transaction.atomic():
                model.objects.bulk_create(
                    [model(**row) for row in chunk],
                    update_conflicts=True,
                    unique_fields=list(unique_fields),
                    update_fields=update_fields,
                )
            done += len(chunk)
        except IntegrityError:
            logger.warning("Bulk upsert of %s failed, retrying row by row", model.__name__)
            for row in chunk:
                lookup = _lookup(row, unique_fields)
                defaults = {k: v for k, v in row.items() if k not in lookup}
                try:
                    with transaction.atomic():
                        model.objects.update_or_create(**lookup, defaults=defaults)
                    done += 1
                except IntegrityError:
                    logger.exception("Skipping %s %s", model.__name__, lookup)
    return done
