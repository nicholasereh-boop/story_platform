from django.urls import path

from . import views

urlpatterns = [
    path("overview/", views.OverviewView.as_view()),
    path("endpoints/", views.EndpointsView.as_view()),
    path("errors/", views.ErrorsView.as_view()),
    path("probe/", views.ProbeView.as_view()),
]
