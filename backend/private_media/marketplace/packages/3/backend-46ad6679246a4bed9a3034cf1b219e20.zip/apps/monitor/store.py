"""Where metrics are kept. Redis in production, a dict in tests. Both expose the same four calls."""
import json
import logging
import threading
import time

logger = logging.getLogger(__name__)


class MemoryStore:
    def __init__(self):
        self.hashes = {}
        self.lists = {}
        self.lock = threading.Lock()

    def hincr(self, key, fields, ttl):
        with self.lock:
            target = self.hashes.setdefault(key, {})
            for field, amount in fields.items():
                target[field] = target.get(field, 0) + amount

    def hgetall(self, key):
        with self.lock:
            return dict(self.hashes.get(key, {}))

    def push(self, key, value, max_len, ttl):
        with self.lock:
            items = self.lists.setdefault(key, [])
            items.insert(0, value)
            del items[max_len:]

    def lrange(self, key, count):
        with self.lock:
            return list(self.lists.get(key, []))[:count]


class RedisStore:
    """Short timeouts: monitoring must never slow a request down, so a slow Redis is treated as an unavailable one."""

    def __init__(self, url, timeout=0.25):
        import redis

        self.client = redis.Redis.from_url(url, socket_connect_timeout=timeout, socket_timeout=timeout, decode_responses=True)

    def hincr(self, key, fields, ttl):
        pipe = self.client.pipeline(transaction=False)
        for field, amount in fields.items():
            pipe.hincrby(key, field, amount)
        pipe.expire(key, ttl)
        pipe.execute()

    def hgetall(self, key):
        return self.client.hgetall(key)

    def push(self, key, value, max_len, ttl):
        pipe = self.client.pipeline(transaction=False)
        pipe.lpush(key, value)
        pipe.ltrim(key, 0, max_len - 1)
        pipe.expire(key, ttl)
        pipe.execute()

    def lrange(self, key, count):
        return self.client.lrange(key, 0, count - 1)


_store = None
_failed_until = 0.0


def set_store(store):
    """Tests inject a MemoryStore; passing None restores the Redis default."""
    global _store, _failed_until
    _store, _failed_until = store, 0.0


def get_store():
    global _store
    if _store is None:
        from django.conf import settings

        _store = RedisStore(settings.MONITOR_REDIS_URL)
    return _store


def safely(call, *args):
    """Run a store call; after a failure skip monitoring for 10 s instead of retrying on every request."""
    global _failed_until
    if time.monotonic() < _failed_until:
        return None
    try:
        return call(*args)
    except Exception:
        _failed_until = time.monotonic() + 10
        logger.warning("Monitoring store unavailable; skipping metrics for 10 seconds", exc_info=True)
        return None


def dumps(value):
    return json.dumps(value, separators=(",", ":"))
