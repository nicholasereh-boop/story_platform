"""Records one counter set per request. Never raises, never blocks on a slow Redis, never records itself."""
import time

from django.conf import settings
from django.urls import Resolver404, resolve

from . import metrics, store

MONITOR_PREFIX = "/api/v1/admin-panel/"
PROBE_HEADER = "HTTP_X_MONITOR_PROBE"


class RequestMetricsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not settings.MONITOR_ENABLED or request.path.startswith(MONITOR_PREFIX) or request.META.get(PROBE_HEADER):
            return self.get_response(request)
        started = time.perf_counter()
        response = self.get_response(request)
        try:
            self.record(request, response, (time.perf_counter() - started) * 1000)
        except Exception:  # monitoring must never break a response
            pass
        return response

    def process_exception(self, request, exception):
        request._monitor_exc = type(exception).__name__
        return None

    def record(self, request, response, ms):
        match = getattr(request, "resolver_match", None)
        if match is None:  # answered by the response cache before URL resolution
            try:
                match = resolve(request.path_info)
            except Resolver404:
                match = None
        route = match.route if match else metrics.UNMATCHED
        now = time.time()
        fields = metrics.record_fields(request.method, route, response.status_code, ms, response.headers.get("X-Cache"))
        store.safely(store.get_store().hincr, metrics.hour_key(now), fields, 72 * 3600)
        if response.status_code >= 500:
            entry = store.dumps({
                "t": int(now), "method": request.method, "path": request.path, "status": response.status_code,
                "ms": int(ms), "route": metrics.pretty_route(route), "exc": getattr(request, "_monitor_exc", "")})
            store.safely(store.get_store().push, metrics.ERRORS_KEY, entry, 200, 7 * 86400)
