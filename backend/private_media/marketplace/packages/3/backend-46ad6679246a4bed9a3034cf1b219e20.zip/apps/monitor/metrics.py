"""Request metrics: what is recorded, how it is stored in hourly hashes, and how it is read back.

Pure Python (no Django imports) so the arithmetic is easy to test. Storage lives in store.py.

Layout: one hash per UTC hour, `mon:m:YYYYMMDDHH`. Each field is "<METHOD> <route>\\t<metric>" where the metric is
  n          requests            s2 s3 s4 s5   responses by status class
  ms         total milliseconds  b10 .. b5000 b+  latency histogram (count of requests at most N ms)
  hit miss   answered from / missed the response cache
Counters only ever increase, so concurrent workers can all write without coordination.
"""
import re
import time

BUCKETS_MS = (10, 25, 50, 100, 250, 500, 1000, 2500, 5000)
OVERFLOW = "b+"
UNMATCHED = "(unmatched)"
SEP = "\t"
HASH_PREFIX = "mon:m:"
ERRORS_KEY = "mon:errors"


def hour_key(timestamp):
    return HASH_PREFIX + time.strftime("%Y%m%d%H", time.gmtime(timestamp))


def hour_keys(now, hours):
    """The last `hours` hourly keys, oldest first, ending with the current (partial) hour."""
    return [hour_key(now - 3600 * back) for back in range(hours - 1, -1, -1)]


def bucket_label(ms):
    for limit in BUCKETS_MS:
        if ms <= limit:
            return f"b{limit}"
    return OVERFLOW


def pretty_route(route):
    """Readable form of a Django route: DRF/regex groups become <name>, anchors and escapes disappear."""
    text = re.sub(r"\(\?P<(\w+)>[^)]*\)", r"<\1>", route or "")
    text = text.replace("^", "").replace("$", "").replace("\\Z", "").replace("\\.", ".")
    text = re.sub(r"/\?$", "/", text)
    text = re.sub(r"/{2,}", "/", text)
    return text.strip() or UNMATCHED


def endpoint_name(method, route):
    return f"{method.upper()} {pretty_route(route)}"


def record_fields(method, route, status, ms, cache_state=None):
    """The counters to add for one finished request."""
    name = endpoint_name(method, route)
    fields = {
        f"{name}{SEP}n": 1,
        f"{name}{SEP}s{max(1, min(status // 100, 5))}": 1,
        f"{name}{SEP}ms": int(round(ms)),
        f"{name}{SEP}{bucket_label(ms)}": 1,
    }
    if cache_state in ("HIT", "MISS"):
        fields[f"{name}{SEP}{cache_state.lower()}"] = 1
    return fields


def parse_hash(raw):
    """{field: count} -> {endpoint: {metric: count}}."""
    parsed = {}
    for field, value in (raw or {}).items():
        endpoint, _, metric = str(field).partition(SEP)
        if not metric:
            continue
        parsed.setdefault(endpoint, {})[metric] = int(value)
    return parsed


def merge(parsed_hashes):
    merged = {}
    for parsed in parsed_hashes:
        for endpoint, metrics in parsed.items():
            target = merged.setdefault(endpoint, {})
            for metric, value in metrics.items():
                target[metric] = target.get(metric, 0) + value
    return merged


def percentile(metrics, q):
    """Approximate latency percentile (ms) from the histogram, interpolating inside the bucket."""
    bounds = [0, *BUCKETS_MS, BUCKETS_MS[-1] * 2]
    labels = [f"b{limit}" for limit in BUCKETS_MS] + [OVERFLOW]
    counts = [metrics.get(label, 0) for label in labels]
    total = sum(counts)
    if total == 0:
        return None
    target = q * total
    seen = 0
    for index, count in enumerate(counts):
        if count and seen + count >= target:
            low, high = bounds[index], bounds[index + 1]
            return round(low + (high - low) * ((target - seen) / count), 1)
        seen += count
    return float(bounds[-1])


def summarize(metrics):
    requests = metrics.get("n", 0)
    errors = metrics.get("s5", 0)
    lookups = metrics.get("hit", 0) + metrics.get("miss", 0)
    return {
        "requests": requests,
        "s2": metrics.get("s2", 0),
        "s3": metrics.get("s3", 0),
        "s4": metrics.get("s4", 0),
        "s5": errors,
        "error_rate": round(errors / requests, 4) if requests else 0.0,
        "avg_ms": round(metrics.get("ms", 0) / requests, 1) if requests else None,
        "p50_ms": percentile(metrics, 0.5),
        "p95_ms": percentile(metrics, 0.95),
        "cache_hit_rate": round(metrics.get("hit", 0) / lookups, 4) if lookups else None,
    }


def total_metrics(merged):
    total = {}
    for metrics in merged.values():
        for metric, value in metrics.items():
            total[metric] = total.get(metric, 0) + value
    return total
