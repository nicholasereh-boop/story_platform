from django.apps import AppConfig


class MonitorConfig(AppConfig):
    name = "apps.monitor"
    label = "monitor"
