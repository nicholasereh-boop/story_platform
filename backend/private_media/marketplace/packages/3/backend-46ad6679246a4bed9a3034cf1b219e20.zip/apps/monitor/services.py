"""Everything the staff API reports. Each check is isolated so one broken part never hides the rest."""
import time
from datetime import datetime, timezone as dt_timezone

from django.conf import settings
from django.core.cache import cache
from django.urls import URLPattern, URLResolver, get_resolver
from django.utils import timezone

from apps.core.cache import last_sync
from . import metrics, store

# name -> (expected seconds between runs, "idle" allowed when nothing is live)
SYNC_EXPECTATIONS = {
    "live": (15, True), "details": (60, True), "fixtures": (600, False), "standings": (900, False),
    "leagues": (86400, False), "teams": (86400, False), "players": (86400, False),
}
LATE_FACTOR = 3


def timed(fn):
    started = time.perf_counter()
    try:
        result = fn()
        ok, error = bool(result.get("ok", True)) if isinstance(result, dict) else True, None
    except Exception as exc:
        result, ok, error = {}, False, type(exc).__name__
    ms = round((time.perf_counter() - started) * 1000, 1)
    return {"ok": ok, "ms": ms, **({"error": error} if error else {}), **({k: v for k, v in result.items() if k != "ok"} if isinstance(result, dict) else {})}


def check_celery():
    cached = cache.get("monitor:celery")
    if cached is not None:
        return cached

    def ping():
        from config.celery import app
        replies = app.control.ping(timeout=1.0) or []
        return {"ok": bool(replies), "workers": len(replies)}

    result = timed(ping)
    cache.set("monitor:celery", result, 10)
    return result


def check_realtime():
    def probe():
        import httpx
        response = httpx.get(settings.REALTIME_HEALTH_URL, timeout=1.5)
        data = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
        return {"ok": response.status_code == 200, **{k: data[k] for k in ("connections", "clients") if k in data}}

    return timed(probe)


def check_database():
    from apps.core.views import check_database as check
    return timed(check)


def check_redis():
    from apps.core.views import check_redis as check
    return timed(check)


def parse_ts(value):
    try:
        parsed = datetime.fromisoformat(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt_timezone.utc)
    except (TypeError, ValueError):
        return None


def sync_status(live_count, now=None, reader=last_sync):
    now = now or timezone.now()
    rows = []
    for name, (interval, idle_ok) in SYNC_EXPECTATIONS.items():
        stamp = parse_ts(reader(name))
        if stamp is None:
            status, age = "never", None
        else:
            age = max(0, int((now - stamp).total_seconds()))
            if age <= interval * LATE_FACTOR:
                status = "ok"
            else:
                status = "idle" if idle_ok and live_count == 0 else "late"
        rows.append({"name": name, "last": stamp.isoformat() if stamp else None, "age_seconds": age,
                     "expected_seconds": interval, "status": status})
    return rows


def site_counts():
    cached = cache.get("monitor:counts")
    if cached is not None:
        return cached
    from django.contrib.auth import get_user_model
    from apps.football.models import League, Player, Team
    from apps.matches.models import Match
    from apps.news.models import Article
    from apps.streams.models import MatchStream
    from integrations.sportmonks import constants as const

    counts = {
        "users": get_user_model().objects.count(),
        "staff": get_user_model().objects.filter(is_staff=True).count(),
        "leagues": League.objects.count(), "teams": Team.objects.count(), "players": Player.objects.count(),
        "matches": Match.objects.count(),
        "live_matches": Match.objects.filter(status__in=const.LIVE_STATUSES).count(),
        "news": Article.objects.visible().count(),
        "active_streams": MatchStream.objects.filter(is_active=True).count(),
    }
    cache.set("monitor:counts", counts, 30)
    return counts


def read_hours(hours, now=None):
    now = now or time.time()
    keys = metrics.hour_keys(now, hours)
    series = []
    for key in keys:
        raw = store.safely(store.get_store().hgetall, key) or {}
        series.append((key, metrics.parse_hash(raw)))
    return series


def traffic_summary(hours, now=None):
    series = read_hours(hours, now)
    merged = metrics.merge(parsed for _, parsed in series)
    hourly = []
    for key, parsed in series:
        total = metrics.total_metrics(parsed)
        hourly.append({"hour": key[len(metrics.HASH_PREFIX):], "requests": total.get("n", 0),
                       "s4": total.get("s4", 0), "s5": total.get("s5", 0)})
    return merged, hourly


def overview(now=None):
    services = {
        "database": check_database(), "redis": check_redis(), "celery": check_celery(),
        "realtime": check_realtime(),
    }
    counts = site_counts()
    merged, _ = traffic_summary(1, now)
    last_hour = metrics.summarize(metrics.total_metrics(merged))
    syncs = sync_status(counts["live_matches"], now)
    problems = [name for name, item in services.items() if not item["ok"]]
    problems += [f"sync:{row['name']}" for row in syncs if row["status"] == "late"]
    return {
        "generated_at": timezone.now().isoformat(),
        "status": "ok" if not problems else ("down" if any(not services[n]["ok"] for n in ("database", "redis") if n in problems) else "degraded"),
        "problems": problems,
        "services": services,
        "provider": {"name": "Sportmonks", "configured": bool(settings.SPORTMONKS_API_TOKEN)},
        "syncs": syncs,
        "counts": counts,
        "last_hour": last_hour,
        "monitoring": {"enabled": settings.MONITOR_ENABLED},
    }


def registered_routes():
    """[(method, pretty_route, has_params)] for every API route Django knows, so unused ones show zero traffic."""
    found = {}

    def walk(patterns, prefix):
        for pattern in patterns:
            text = prefix + str(pattern.pattern)
            if isinstance(pattern, URLResolver):
                walk(pattern.url_patterns, text)
            elif isinstance(pattern, URLPattern):
                route = metrics.pretty_route(text)
                if "<format>" in route or not route.startswith("api/"):
                    continue
                for method in view_methods(pattern.callback):
                    found[(method, route)] = "<" in route

    walk(get_resolver().url_patterns, "")
    return sorted(found.items(), key=lambda item: (item[0][1], item[0][0]))


def view_methods(callback):
    actions = getattr(callback, "actions", None)  # viewset routes map method -> action
    if actions:
        return [m.upper() for m in actions]
    cls = getattr(callback, "cls", None) or getattr(callback, "view_class", None)
    if cls is not None:
        names = [m for m in getattr(cls, "http_method_names", []) if m not in ("options", "head", "trace") and hasattr(cls, m)]
        if names:
            return [m.upper() for m in names]
    return ["GET"]


def endpoints(hours, now=None):
    merged, hourly = traffic_summary(hours, now)
    rows = {}
    for (method, route), has_params in registered_routes():
        rows[f"{method} {route}"] = {"method": method, "route": route, "dynamic": has_params, "registered": True}
    for name, values in merged.items():
        method, _, route = name.partition(" ")
        row = rows.setdefault(name, {"method": method, "route": route or name, "dynamic": "<" in name, "registered": False})
        row.update(metrics.summarize(values))
    empty = metrics.summarize({})
    for row in rows.values():
        for key, value in empty.items():
            row.setdefault(key, value)
    total = metrics.summarize(metrics.total_metrics(merged))
    return {"hours": hours, "totals": total, "hourly": hourly,
            "endpoints": sorted(rows.values(), key=lambda r: (-r["requests"], r["route"]))}


def recent_errors(limit=50):
    import json
    items = []
    for raw in store.safely(store.get_store().lrange, metrics.ERRORS_KEY, limit) or []:
        try:
            items.append(json.loads(raw))
        except ValueError:
            continue
    return items


PROBE_SKIP = ("api/v1/my/", "api/v1/auth/", "api/v1/token/", "api/v1/admin-panel/")


def probe_targets():
    return [route for (method, route), dynamic in registered_routes()
            if method == "GET" and not dynamic and route.startswith("api/v1/") and not route.startswith(PROBE_SKIP)]


def run_probes(fresh=False):
    from django.test import Client

    hosts = [h for h in settings.ALLOWED_HOSTS if h and h != "*" and not h.startswith(".")]
    client = Client(HTTP_HOST=hosts[0] if hosts else "localhost", REMOTE_ADDR="127.255.255.254",
                    HTTP_X_MONITOR_PROBE="1")
    results = []
    for route in probe_targets():
        url = "/" + route
        params = {"_probe": int(time.time() * 1000)} if fresh else {}
        started = time.perf_counter()
        try:
            response = client.get(url, params, secure=True)
            status, cache_state = response.status_code, response.headers.get("X-Cache", "")
        except Exception as exc:
            status, cache_state = 599, type(exc).__name__
        results.append({"route": route, "status": status, "ms": round((time.perf_counter() - started) * 1000, 1),
                        "cache": cache_state, "ok": 200 <= status < 400})
    return results
