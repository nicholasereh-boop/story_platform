from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services


class StaffView(APIView):
    permission_classes = [IsAdminUser]
    throttle_classes = []  # the dashboard polls; staff are authenticated and few


def hours_param(request, default=24):
    try:
        return max(1, min(int(request.query_params.get("hours", default)), 72))
    except (TypeError, ValueError):
        return default


class OverviewView(StaffView):
    def get(self, request):
        return Response(services.overview())


class EndpointsView(StaffView):
    def get(self, request):
        return Response(services.endpoints(hours_param(request)))


class ErrorsView(StaffView):
    def get(self, request):
        return Response({"results": services.recent_errors()})


class ProbeView(StaffView):
    def post(self, request):
        results = services.run_probes(fresh=bool(request.data.get("fresh")))
        return Response({"results": results, "failed": sum(1 for r in results if not r["ok"])})
