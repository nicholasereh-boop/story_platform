import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from apps.monitor import metrics, services, store

pytestmark = pytest.mark.django_db


@pytest.fixture
def memory(settings):
    settings.MONITOR_ENABLED = True
    mem = store.MemoryStore()
    store.set_store(mem)
    yield mem
    store.set_store(None)


def staff_client():
    user = get_user_model().objects.create_user("boss", "boss@example.com", "pw-12345-xyz", is_staff=True)
    client = APIClient()
    client.force_authenticate(user)
    return client


def test_pretty_route_removes_regex_noise():
    assert metrics.pretty_route("api/v1/^matches/(?P<pk>[^/.]+)/$") == "api/v1/matches/<pk>/"
    assert metrics.pretty_route("") == metrics.UNMATCHED


def test_summary_reports_rates_and_percentiles():
    total = {}
    for ms, status, cache_state in [(5, 200, "HIT"), (30, 200, "MISS"), (700, 500, None), (3000, 404, None)]:
        for key, value in metrics.record_fields("GET", "r", status, ms, cache_state).items():
            metric = key.split(metrics.SEP)[1]
            total[metric] = total.get(metric, 0) + value
    summary = metrics.summarize(total)
    assert summary["requests"] == 4 and summary["s5"] == 1 and summary["s4"] == 1
    assert summary["error_rate"] == 0.25 and summary["cache_hit_rate"] == 0.5
    assert summary["p95_ms"] > summary["p50_ms"]


def test_requests_are_counted_by_route(client, memory):
    client.get("/api/v1/health/")
    client.get("/api/v1/health/")
    merged, _ = services.traffic_summary(1)
    names = {name: values["n"] for name, values in merged.items()}
    assert any(name.startswith("GET api/v1/") and count == 2 for name, count in names.items())


def test_the_monitor_does_not_count_itself(memory):
    staff_client().get("/api/v1/admin-panel/overview/")
    assert memory.hashes == {}


def test_a_dead_store_never_breaks_a_request(client, settings):
    settings.MONITOR_ENABLED = True

    class Broken:
        def hincr(self, *a):
            raise RuntimeError("down")

    store.set_store(Broken())
    try:
        assert client.get("/api/v1/health/").status_code in (200, 503)
    finally:
        store.set_store(None)


def test_5xx_responses_are_listed(memory):
    memory.push(metrics.ERRORS_KEY, store.dumps({"t": 1, "method": "GET", "path": "/x", "status": 500, "ms": 5, "route": "x", "exc": "Boom"}), 10, 10)
    body = staff_client().get("/api/v1/admin-panel/errors/").json()
    assert body["results"][0]["exc"] == "Boom"


@pytest.mark.parametrize("path", ["overview", "endpoints", "errors"])
def test_only_staff_can_read_the_dashboard_data(path):
    url = f"/api/v1/admin-panel/{path}/"
    assert APIClient().get(url).status_code in (401, 403)
    user = get_user_model().objects.create_user("fan", "fan@example.com", "pw-12345-xyz")
    client = APIClient()
    client.force_authenticate(user)
    assert client.get(url).status_code == 403


def test_probe_is_staff_only_and_post_only():
    assert APIClient().post("/api/v1/admin-panel/probe/").status_code in (401, 403)
    assert staff_client().get("/api/v1/admin-panel/probe/").status_code == 405


def test_endpoints_lists_unused_routes_with_zero_traffic(memory):
    body = staff_client().get("/api/v1/admin-panel/endpoints/?hours=6").json()
    assert body["hours"] == 6 and len(body["hourly"]) == 6
    unused = [row for row in body["endpoints"] if row["requests"] == 0]
    assert unused and all("p95_ms" in row for row in unused)
    assert not any("<format>" in row["route"] for row in body["endpoints"])


def test_overview_has_every_section(memory, monkeypatch):
    monkeypatch.setattr(services, "check_celery", lambda: {"ok": True, "ms": 1, "workers": 1})
    monkeypatch.setattr(services, "check_realtime", lambda: {"ok": True, "ms": 1})
    body = staff_client().get("/api/v1/admin-panel/overview/").json()
    assert set(body["services"]) == {"database", "redis", "celery", "realtime"}
    assert {"users", "live_matches", "active_streams"} <= set(body["counts"])
    assert [row["name"] for row in body["syncs"]][0] == "live"
    assert body["status"] in ("ok", "degraded", "down")


def test_sync_freshness_states():
    from datetime import datetime, timedelta, timezone

    now = datetime(2026, 10, 25, 12, 0, tzinfo=timezone.utc)
    stamps = {"live": (now - timedelta(seconds=20)).isoformat(), "fixtures": (now - timedelta(hours=2)).isoformat(),
              "details": (now - timedelta(hours=2)).isoformat()}
    rows = {r["name"]: r["status"] for r in services.sync_status(0, now, reader=stamps.get)}
    assert rows["live"] == "ok" and rows["fixtures"] == "late" and rows["details"] == "idle" and rows["teams"] == "never"
    rows = {r["name"]: r["status"] for r in services.sync_status(3, now, reader=stamps.get)}
    assert rows["details"] == "late"


def test_a_down_service_changes_overall_status(memory, monkeypatch):
    monkeypatch.setattr(services, "check_celery", lambda: {"ok": False, "ms": 1})
    monkeypatch.setattr(services, "check_realtime", lambda: {"ok": True, "ms": 1})
    body = staff_client().get("/api/v1/admin-panel/overview/").json()
    assert body["status"] == "degraded" and "celery" in body["problems"]


def test_probe_visits_public_list_endpoints_only(memory):
    targets = services.probe_targets()
    assert targets and not any("my/" in t or "auth/" in t or "<" in t or "admin-panel" in t for t in targets)
    body = staff_client().post("/api/v1/admin-panel/probe/", {"fresh": True}, format="json").json()
    assert len(body["results"]) == len(targets)
    assert memory.hashes == {}  # probes are not counted as traffic


def test_private_api_responses_are_never_cached():
    response = staff_client().get("/api/v1/admin-panel/errors/")
    assert "no-store" in response.headers.get("Cache-Control", "") or "private" in response.headers.get("Cache-Control", "")
