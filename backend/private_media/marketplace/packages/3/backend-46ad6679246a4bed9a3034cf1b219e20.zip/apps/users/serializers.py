from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .models import Profile

User = get_user_model()


def _email_taken(email, exclude_pk=None):
    queryset = User.objects.filter(email__iexact=email)
    if exclude_pk is not None:
        queryset = queryset.exclude(pk=exclude_pk)
    return queryset.exists()


class RegisterSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8, style={"input_type": "password"})

    class Meta:
        model = User
        fields = ("id", "username", "email", "password")
        read_only_fields = ("id",)

    def validate_email(self, value):
        value = value.strip().lower()
        if _email_taken(value):
            raise serializers.ValidationError("A user with this email already exists.")
        return value

    def validate(self, attrs):
        candidate = User(username=attrs.get("username", ""), email=attrs.get("email", ""))
        try:
            validate_password(attrs["password"], user=candidate)
        except DjangoValidationError as exc:
            raise serializers.ValidationError({"password": list(exc.messages)})
        return attrs

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


def get_profile(user):
    return Profile.objects.get_or_create(user=user)[0]


class ProfileSerializer(serializers.ModelSerializer):
    timezone = serializers.CharField(max_length=64, allow_blank=True, required=False)

    class Meta:
        model = Profile
        fields = ("timezone", "theme")

    def validate_timezone(self, value):
        value = value.strip()
        if value:
            try:
                ZoneInfo(value)
            except (ZoneInfoNotFoundError, ValueError, OSError):
                raise serializers.ValidationError("Unknown time zone.")
        return value


class UserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()
    profile = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ("id", "username", "email", "date_joined", "is_staff", "profile")
        read_only_fields = ("id", "date_joined", "is_staff")

    def get_profile(self, user):
        return ProfileSerializer(get_profile(user)).data

    def validate_email(self, value):
        value = value.strip().lower()
        if _email_taken(value, exclude_pk=self.instance.pk if self.instance else None):
            raise serializers.ValidationError("A user with this email already exists.")
        return value


class LogoutSerializer(serializers.Serializer):
    refresh = serializers.CharField()


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True, style={"input_type": "password"})
    new_password = serializers.CharField(write_only=True, min_length=8, style={"input_type": "password"})

    def validate_current_password(self, value):
        if not self.context["request"].user.check_password(value):
            raise serializers.ValidationError("Current password is incorrect.")
        return value

    def validate(self, attrs):
        user = self.context["request"].user
        if attrs["new_password"] == attrs["current_password"]:
            raise serializers.ValidationError({"new_password": ["Choose a password you have not used just now."]})
        try:
            validate_password(attrs["new_password"], user=user)
        except DjangoValidationError as exc:
            raise serializers.ValidationError({"new_password": list(exc.messages)})
        return attrs


class LoginSerializer(TokenObtainPairSerializer):
    """The "username" field also accepts the account's email address."""

    def validate(self, attrs):
        identifier = (attrs.get(self.username_field) or "").strip()
        if "@" in identifier:
            match = User.objects.filter(email__iexact=identifier).order_by("id").first()
            if match:
                attrs[self.username_field] = match.get_username()
        return super().validate(attrs)
