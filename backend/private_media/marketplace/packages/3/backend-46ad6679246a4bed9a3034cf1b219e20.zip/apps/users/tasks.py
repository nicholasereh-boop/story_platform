from celery import shared_task
from django.core.management import call_command


@shared_task
def flush_expired_tokens():
    """The JWT blacklist grows with every login and refresh; expired rows can never matter again."""
    call_command("flushexpiredtokens")
