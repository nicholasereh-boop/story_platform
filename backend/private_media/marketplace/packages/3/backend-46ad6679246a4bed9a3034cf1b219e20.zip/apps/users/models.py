from django.conf import settings
from django.db import models


class Profile(models.Model):
    """Per-user settings that follow the account across devices."""

    THEME_CHOICES = [("system", "System"), ("light", "Light"), ("dark", "Dark")]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    timezone = models.CharField(max_length=64, blank=True, help_text="IANA name, empty = use the browser's.")
    theme = models.CharField(max_length=10, choices=THEME_CHOICES, default="system")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Profile<{self.user_id}>"
