from django.urls import path

from .views import ChangePasswordView, LogoutView, MeView, RegisterView, SettingsView

urlpatterns = [
    path("register/", RegisterView.as_view(), name="register"),
    path("me/", MeView.as_view(), name="me"),
    path("me/settings/", SettingsView.as_view(), name="me-settings"),
    path("me/password/", ChangePasswordView.as_view(), name="me-password"),
    path("logout/", LogoutView.as_view(), name="logout"),
]
