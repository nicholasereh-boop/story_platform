from django.contrib import admin

from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "timezone", "theme", "updated_at")
    search_fields = ("user__username", "user__email")
    raw_id_fields = ("user",)
