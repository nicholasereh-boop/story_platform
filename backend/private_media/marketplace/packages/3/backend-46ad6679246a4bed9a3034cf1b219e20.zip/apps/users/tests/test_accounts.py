import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from apps.users.models import Profile

User = get_user_model()
pytestmark = pytest.mark.django_db

TOKEN = "/api/v1/token/"
REFRESH = "/api/v1/token/refresh/"
ME = "/api/v1/auth/me/"
SETTINGS = "/api/v1/auth/me/settings/"
PASSWORD_URL = "/api/v1/auth/me/password/"
PASSWORD = "Sup3r-secret-pass"
NEW_PASSWORD = "An0ther-secret-pass"


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def user():
    return User.objects.create_user("ada", "ada@example.com", PASSWORD)


def login(client, username="ada", password=PASSWORD):
    response = client.post(TOKEN, {"username": username, "password": password}, format="json")
    assert response.status_code == 200, response.data
    return response.data


def signed_in(client):
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {login(client)['access']}")
    return client


def test_login_accepts_email_in_any_case(client, user):
    assert "access" in login(client, "Ada@Example.COM")
    assert client.post(TOKEN, {"username": "nobody@example.com", "password": PASSWORD}, format="json").status_code == 401
    assert client.post(TOKEN, {"username": "ada@example.com", "password": "wrong-pass-123"}, format="json").status_code == 401


def test_me_includes_default_settings_and_creates_the_profile_once(client, user):
    signed_in(client)
    data = client.get(ME).json()
    assert data["profile"] == {"timezone": "", "theme": "system"}
    client.get(ME)
    assert Profile.objects.filter(user=user).count() == 1


def test_me_ignores_profile_values_sent_to_it(client, user):
    signed_in(client)
    client.patch(ME, {"profile": {"theme": "dark"}}, format="json")
    assert client.get(ME).json()["profile"]["theme"] == "system"


def test_username_can_be_changed_but_not_taken(client, user):
    User.objects.create_user("bob", "bob@example.com", PASSWORD)
    signed_in(client)
    assert client.patch(ME, {"username": "bob"}, format="json").status_code == 400
    assert client.patch(ME, {"username": "ada2"}, format="json").status_code == 200
    user.refresh_from_db()
    assert user.username == "ada2"


def test_settings_require_authentication(client):
    assert client.get(SETTINGS).status_code == 401
    assert client.patch(SETTINGS, {"theme": "dark"}, format="json").status_code == 401


def test_settings_can_be_updated_partially(client, user):
    signed_in(client)
    response = client.patch(SETTINGS, {"timezone": "Africa/Lagos"}, format="json")
    assert response.status_code == 200 and response.json() == {"timezone": "Africa/Lagos", "theme": "system"}
    response = client.patch(SETTINGS, {"theme": "dark"}, format="json")
    assert response.json() == {"timezone": "Africa/Lagos", "theme": "dark"}
    assert client.get(ME).json()["profile"] == {"timezone": "Africa/Lagos", "theme": "dark"}
    assert client.patch(SETTINGS, {"timezone": ""}, format="json").json()["timezone"] == ""


@pytest.mark.parametrize("payload", [{"timezone": "Mars/Base"}, {"timezone": "../etc/passwd"}, {"theme": "neon"}])
def test_settings_reject_bad_values(client, user, payload):
    signed_in(client)
    assert client.patch(SETTINGS, payload, format="json").status_code == 400


def test_settings_belong_to_the_signed_in_user(client, user):
    other = User.objects.create_user("bob", "bob@example.com", PASSWORD)
    Profile.objects.create(user=other, theme="dark")
    signed_in(client)
    assert client.get(SETTINGS).json()["theme"] == "system"


def test_change_password_requires_the_current_one(client, user):
    signed_in(client)
    response = client.post(PASSWORD_URL, {"current_password": "wrong-pass-123", "new_password": NEW_PASSWORD}, format="json")
    assert response.status_code == 400 and "current_password" in response.json()


def test_change_password_applies_the_password_rules(client, user):
    signed_in(client)
    for weak in ["short", "12345678", "ada@example.com", PASSWORD]:
        response = client.post(PASSWORD_URL, {"current_password": PASSWORD, "new_password": weak}, format="json")
        assert response.status_code == 400, weak
    user.refresh_from_db()
    assert user.check_password(PASSWORD)


def test_change_password_signs_out_other_sessions_and_returns_fresh_tokens(client, user):
    other_device = login(APIClient())
    signed_in(client)
    response = client.post(PASSWORD_URL, {"current_password": PASSWORD, "new_password": NEW_PASSWORD}, format="json")
    assert response.status_code == 200
    tokens = response.json()
    assert set(tokens) == {"access", "refresh"}

    user.refresh_from_db()
    assert user.check_password(NEW_PASSWORD)
    assert APIClient().post(REFRESH, {"refresh": other_device["refresh"]}, format="json").status_code == 401
    assert APIClient().post(REFRESH, {"refresh": tokens["refresh"]}, format="json").status_code == 200
    assert APIClient().post(TOKEN, {"username": "ada", "password": PASSWORD}, format="json").status_code == 401
    assert login(APIClient(), password=NEW_PASSWORD)


def test_change_password_requires_authentication(client):
    assert client.post(PASSWORD_URL, {"current_password": "x", "new_password": NEW_PASSWORD}, format="json").status_code == 401
