import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

User = get_user_model()
pytestmark = pytest.mark.django_db

REGISTER = "/api/v1/auth/register/"
TOKEN = "/api/v1/token/"
REFRESH = "/api/v1/token/refresh/"
ME = "/api/v1/auth/me/"
LOGOUT = "/api/v1/auth/logout/"
PASSWORD = "Sup3r-secret-pass"


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def user():
    return User.objects.create_user("ada", "ada@example.com", PASSWORD)


def login(client, username="ada", password=PASSWORD):
    response = client.post(TOKEN, {"username": username, "password": password}, format="json")
    assert response.status_code == 200
    return response.data


def test_register_creates_a_user_without_leaking_the_password(client):
    response = client.post(REGISTER, {"username": "bob", "email": "Bob@Example.com", "password": PASSWORD}, format="json")
    assert response.status_code == 201
    assert response.data["email"] == "bob@example.com"
    assert "password" not in response.data
    assert User.objects.get(username="bob").check_password(PASSWORD)


def test_register_rejects_duplicate_email_case_insensitively(client, user):
    response = client.post(REGISTER, {"username": "other", "email": "ADA@example.com", "password": PASSWORD}, format="json")
    assert response.status_code == 400
    assert "email" in response.data


def test_register_rejects_weak_passwords(client):
    for weak in ("12345678", "password", "short"):
        response = client.post(REGISTER, {"username": "bob", "email": "bob@example.com", "password": weak}, format="json")
        assert response.status_code == 400, weak
    assert not User.objects.filter(username="bob").exists()


def test_token_login_and_refresh(client, user):
    tokens = login(client)
    assert set(tokens) == {"access", "refresh"}
    refreshed = client.post(REFRESH, {"refresh": tokens["refresh"]}, format="json")
    assert refreshed.status_code == 200 and refreshed.data["access"]


def test_wrong_password_is_rejected(client, user):
    assert client.post(TOKEN, {"username": "ada", "password": "nope"}, format="json").status_code == 401


def test_me_requires_authentication(client):
    assert client.get(ME).status_code == 401


def test_me_returns_and_updates_the_profile(client, user):
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {login(client)['access']}")
    assert client.get(ME).data["username"] == "ada"
    response = client.patch(ME, {"email": "New@Example.com"}, format="json")
    assert response.status_code == 200 and response.data["email"] == "new@example.com"
    user.refresh_from_db()
    assert user.email == "new@example.com"


def test_me_cannot_take_another_users_email(client, user):
    User.objects.create_user("bob", "bob@example.com", PASSWORD)
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {login(client)['access']}")
    assert client.patch(ME, {"email": "bob@example.com"}, format="json").status_code == 400


def test_logout_blacklists_the_refresh_token(client, user):
    tokens = login(client)
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
    assert client.post(LOGOUT, {"refresh": tokens["refresh"]}, format="json").status_code == 204
    assert client.post(REFRESH, {"refresh": tokens["refresh"]}, format="json").status_code == 401


def test_logout_rejects_garbage_and_missing_tokens(client, user):
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {login(client)['access']}")
    assert client.post(LOGOUT, {"refresh": "garbage"}, format="json").status_code == 400
    assert client.post(LOGOUT, {}, format="json").status_code == 400


def test_logout_cannot_revoke_someone_elses_token(client, user):
    User.objects.create_user("bob", "bob@example.com", PASSWORD)
    bobs = login(APIClient(), "bob")
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {login(client)['access']}")
    assert client.post(LOGOUT, {"refresh": bobs["refresh"]}, format="json").status_code == 400


def test_logout_requires_authentication(client):
    assert client.post(LOGOUT, {"refresh": "x"}, format="json").status_code == 401
