from celery import shared_task

from . import services


@shared_task
def deliver_notification(spec):
    return services.deliver(spec)


@shared_task
def purge_old_notifications():
    return services.purge_old()
