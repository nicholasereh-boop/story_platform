from django.contrib import admin

from .models import Notification, NotificationPreference


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "kind", "source", "title", "read_at", "created_at")
    list_filter = ("kind", "source")
    raw_id_fields = ("user", "match")
    search_fields = ("user__username", "title")


@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = ("user", "enabled", "goals", "match_start", "half_time", "full_time", "red_cards")
    raw_id_fields = ("user",)
