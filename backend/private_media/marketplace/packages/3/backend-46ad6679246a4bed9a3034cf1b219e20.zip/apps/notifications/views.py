from django.shortcuts import get_object_or_404
from django.utils import timezone
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Notification, NotificationPreference
from .serializers import MarkReadSerializer, NotificationSerializer, PreferenceSerializer


class NotificationListView(generics.ListAPIView):
    """GET /my/notifications/ - newest first. ?unread=1 shows only unread ones."""

    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(parameters=[OpenApiParameter("unread", bool, description="Only unread notifications.")])
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        queryset = Notification.objects.filter(user=self.request.user)
        if self.request.query_params.get("unread", "").lower() in {"1", "true", "yes"}:
            queryset = queryset.filter(read_at__isnull=True)
        return queryset


class UnreadCountView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(responses={200: dict})
    def get(self, request):
        return Response({"count": Notification.objects.filter(user=request.user, read_at__isnull=True).count()})


class MarkReadView(APIView):
    """POST /my/notifications/read/ with {"ids": [..]} or {"all": true}."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MarkReadSerializer

    @extend_schema(request=MarkReadSerializer, responses={200: dict})
    def post(self, request):
        serializer = MarkReadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        unread = Notification.objects.filter(user=request.user, read_at__isnull=True)
        if not serializer.validated_data["all"]:
            unread = unread.filter(pk__in=serializer.validated_data["ids"])
        return Response({"updated": unread.update(read_at=timezone.now())})


class NotificationDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(responses={204: None})
    def delete(self, request, pk):
        get_object_or_404(Notification, pk=pk, user=request.user).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class PreferenceView(generics.RetrieveUpdateAPIView):
    serializer_class = PreferenceSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ["get", "patch", "head", "options"]

    def get_object(self):
        return NotificationPreference.objects.get_or_create(user=self.request.user)[0]
