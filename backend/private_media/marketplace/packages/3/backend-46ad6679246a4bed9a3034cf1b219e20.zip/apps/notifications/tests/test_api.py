import pytest
from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import Team
from apps.matches.models import Match
from apps.notifications.models import Kind, Notification, NotificationPreference, Source

User = get_user_model()
pytestmark = pytest.mark.django_db
BASE = "/api/v1/my/notifications/"


@pytest.fixture
def ada():
    return User.objects.create_user("ada", "ada@example.com", "Sup3r-secret-pass")


@pytest.fixture
def client(ada):
    api = APIClient()
    api.force_authenticate(ada)
    return api


def note(user, key, read=False, **extra):
    return Notification.objects.create(
        user=user, kind=Kind.GOAL, source=Source.TEAM, title=f"Goal {key}", dedupe_key=key,
        read_at=timezone.now() if read else None, **extra,
    )


@pytest.mark.parametrize("url", [BASE, BASE + "unread-count/", BASE + "preferences/"])
def test_everything_requires_authentication(url):
    assert APIClient().get(url).status_code == 401
    assert APIClient().post(BASE + "read/", {"all": True}, format="json").status_code == 401
    assert APIClient().delete(BASE + "1/").status_code == 401


def test_list_is_paginated_newest_first_and_private(client, ada):
    other = User.objects.create_user("bob", "bob@example.com", "Sup3r-secret-pass")
    note(ada, "a")
    note(ada, "b", read=True)
    note(other, "c")
    data = client.get(BASE).json()
    assert data["count"] == 2
    assert [row["title"] for row in data["results"]] == ["Goal b", "Goal a"]
    assert [row["read"] for row in data["results"]] == [True, False]
    assert set(data["results"][0]) == {"id", "kind", "source", "match", "title", "body", "read", "created_at"}


def test_unread_filter_and_count(client, ada):
    note(ada, "a")
    note(ada, "b", read=True)
    assert client.get(BASE + "?unread=1").json()["count"] == 1
    assert client.get(BASE + "unread-count/").json() == {"count": 1}


def test_mark_some_as_read(client, ada):
    first, second = note(ada, "a"), note(ada, "b")
    assert client.post(BASE + "read/", {"ids": [first.id]}, format="json").json() == {"updated": 1}
    first.refresh_from_db(), second.refresh_from_db()
    assert first.read_at is not None and second.read_at is None
    assert client.post(BASE + "read/", {"ids": [first.id]}, format="json").json() == {"updated": 0}


def test_mark_all_as_read_touches_only_my_notifications(client, ada):
    other = User.objects.create_user("bob", "bob@example.com", "Sup3r-secret-pass")
    mine, theirs = note(ada, "a"), note(other, "b")
    assert client.post(BASE + "read/", {"all": True}, format="json").json() == {"updated": 1}
    theirs.refresh_from_db()
    assert theirs.read_at is None
    assert client.post(BASE + "read/", {"ids": [theirs.id]}, format="json").json() == {"updated": 0}


@pytest.mark.parametrize("payload", [{}, {"ids": []}, {"ids": ["x"]}, {"ids": [0]}, {"all": False}])
def test_mark_read_needs_ids_or_all(client, payload):
    assert client.post(BASE + "read/", payload, format="json").status_code == 400


def test_dismiss_one_notification(client, ada):
    other = User.objects.create_user("bob", "bob@example.com", "Sup3r-secret-pass")
    mine, theirs = note(ada, "a"), note(other, "b")
    assert client.delete(f"{BASE}{theirs.id}/").status_code == 404
    assert client.delete(f"{BASE}{mine.id}/").status_code == 204
    assert client.delete(f"{BASE}{mine.id}/").status_code == 404
    assert Notification.objects.filter(pk=theirs.pk).exists()


def test_preferences_default_to_everything_on_and_update_partially(client, ada):
    data = client.get(BASE + "preferences/").json()
    assert all(data.values()) and len(data) == 8
    response = client.patch(BASE + "preferences/", {"goals": False, "favorite_leagues": False}, format="json")
    assert response.status_code == 200
    prefs = NotificationPreference.objects.get(user=ada)
    assert (prefs.goals, prefs.favorite_leagues, prefs.match_start) == (False, False, True)
    assert client.patch(BASE + "preferences/", {"goals": "maybe"}, format="json").status_code == 400


def test_notifications_keep_working_after_the_match_is_deleted(client, ada):
    home, away = Team.objects.create(provider_id=1, name="A"), Team.objects.create(provider_id=2, name="B")
    match = Match.objects.create(provider_id=9, home_team=home, away_team=away, scheduled_at=timezone.now())
    note(ada, "a", match=match)
    match.delete()
    (row,) = client.get(BASE).json()["results"]
    assert row["match"] is None and row["title"] == "Goal a"
