from rest_framework import serializers

from .models import Notification, NotificationPreference


class NotificationSerializer(serializers.ModelSerializer):
    read = serializers.SerializerMethodField()

    class Meta:
        model = Notification
        fields = ("id", "kind", "source", "match", "title", "body", "read", "created_at")
        read_only_fields = fields

    def get_read(self, notification):
        return notification.read_at is not None


class PreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationPreference
        fields = (
            "enabled", "goals", "match_start", "half_time", "full_time", "red_cards",
            "favorite_teams", "favorite_leagues",
        )


class MarkReadSerializer(serializers.Serializer):
    ids = serializers.ListField(child=serializers.IntegerField(min_value=1), required=False, max_length=200)
    all = serializers.BooleanField(required=False, default=False)

    def validate(self, attrs):
        if not attrs.get("all") and not attrs.get("ids"):
            raise serializers.ValidationError("Send either ids or all=true.")
        return attrs
