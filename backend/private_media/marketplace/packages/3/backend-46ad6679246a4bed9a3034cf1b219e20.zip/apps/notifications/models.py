from django.conf import settings
from django.db import models


class Kind(models.TextChoices):
    GOAL = "goal", "Goal"
    MATCH_START = "match_start", "Match start"
    HALF_TIME = "half_time", "Half time"
    FULL_TIME = "full_time", "Full time"
    RED_CARD = "red_card", "Red card"


class Source(models.TextChoices):
    MATCH = "match", "Followed match"
    TEAM = "team", "Followed team"
    LEAGUE = "league", "Followed league"


class NotificationPreference(models.Model):
    """What a user wants to hear about. A user without a row gets the defaults below."""

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notification_preferences")
    enabled = models.BooleanField(default=True)
    goals = models.BooleanField(default=True)
    match_start = models.BooleanField(default=True)
    half_time = models.BooleanField(default=True)
    full_time = models.BooleanField(default=True)
    red_cards = models.BooleanField(default=True)
    favorite_teams = models.BooleanField(default=True, help_text="Events in matches of followed teams.")
    favorite_leagues = models.BooleanField(default=True, help_text="Events in matches of followed leagues.")
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"NotificationPreference<{self.user_id}>"


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    kind = models.CharField(max_length=20, choices=Kind.choices)
    source = models.CharField(max_length=10, choices=Source.choices)
    match = models.ForeignKey("matches.Match", null=True, blank=True, on_delete=models.SET_NULL, related_name="notifications")
    title = models.CharField(max_length=200)
    body = models.CharField(max_length=300, blank=True)
    # Identifies the real-world occurrence ("goal:123"), so repeated syncs can never notify twice.
    dedupe_key = models.CharField(max_length=60)
    read_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [models.UniqueConstraint(fields=["user", "dedupe_key"], name="notification_unique_per_user")]
        indexes = [
            models.Index(fields=["user", "-created_at"], name="notif_user_recent_idx"),
            models.Index(fields=["user", "read_at"], name="notif_user_read_idx"),
        ]

    def __str__(self):
        return f"Notification<{self.user_id} {self.dedupe_key}>"
