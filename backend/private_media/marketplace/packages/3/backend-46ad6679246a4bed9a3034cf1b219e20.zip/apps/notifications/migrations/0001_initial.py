import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("matches", "0002_database_foundation"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="NotificationPreference",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("enabled", models.BooleanField(default=True)),
                ("goals", models.BooleanField(default=True)),
                ("match_start", models.BooleanField(default=True)),
                ("half_time", models.BooleanField(default=True)),
                ("full_time", models.BooleanField(default=True)),
                ("red_cards", models.BooleanField(default=True)),
                ("favorite_teams", models.BooleanField(default=True, help_text="Events in matches of followed teams.")),
                ("favorite_leagues", models.BooleanField(default=True, help_text="Events in matches of followed leagues.")),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="notification_preferences", to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.CreateModel(
            name="Notification",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "kind",
                    models.CharField(
                        choices=[
                            ("goal", "Goal"), ("match_start", "Match start"), ("half_time", "Half time"),
                            ("full_time", "Full time"), ("red_card", "Red card"),
                        ],
                        max_length=20,
                    ),
                ),
                (
                    "source",
                    models.CharField(
                        choices=[("match", "Followed match"), ("team", "Followed team"), ("league", "Followed league")],
                        max_length=10,
                    ),
                ),
                ("title", models.CharField(max_length=200)),
                ("body", models.CharField(blank=True, max_length=300)),
                ("dedupe_key", models.CharField(max_length=60)),
                ("read_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "match",
                    models.ForeignKey(
                        blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                        related_name="notifications", to="matches.match",
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="notifications", to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={"ordering": ["-created_at", "-id"]},
        ),
        migrations.AddIndex(
            model_name="notification",
            index=models.Index(fields=["user", "-created_at"], name="notif_user_recent_idx"),
        ),
        migrations.AddIndex(
            model_name="notification",
            index=models.Index(fields=["user", "read_at"], name="notif_user_read_idx"),
        ),
        migrations.AddConstraint(
            model_name="notification",
            constraint=models.UniqueConstraint(fields=("user", "dedupe_key"), name="notification_unique_per_user"),
        ),
    ]
