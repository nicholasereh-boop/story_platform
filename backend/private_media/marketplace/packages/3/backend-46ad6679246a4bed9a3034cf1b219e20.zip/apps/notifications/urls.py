from django.urls import path

from .views import MarkReadView, NotificationDetailView, NotificationListView, PreferenceView, UnreadCountView

urlpatterns = [
    path("", NotificationListView.as_view(), name="notifications"),
    path("unread-count/", UnreadCountView.as_view(), name="notifications-unread-count"),
    path("read/", MarkReadView.as_view(), name="notifications-read"),
    path("preferences/", PreferenceView.as_view(), name="notifications-preferences"),
    path("<int:pk>/", NotificationDetailView.as_view(), name="notification-detail"),
]
