from datetime import timedelta
from types import SimpleNamespace

import pytest
from django.contrib.auth import get_user_model
from django.utils import timezone

from apps.favorites.models import Favorite
from apps.football.models import League, Team
from apps.matches import sync
from apps.matches.models import Match
from apps.matches.tests.test_sync import FakeClient, fixture
from apps.notifications import services, tasks
from apps.notifications.models import Kind, Notification, NotificationPreference, Source

User = get_user_model()
pytestmark = pytest.mark.django_db

GOAL = {
    "id": 1, "type": {"developer_name": "GOAL"}, "player_id": 9, "player_name": "Saka",
    "related_player_id": 10, "related_player_name": "Odegaard", "participant_id": 1, "minute": 12,
}
RED = {"id": 5, "type": {"developer_name": "REDCARD"}, "player_id": 11, "player_name": "Cucurella", "participant_id": 2, "minute": 60}


@pytest.fixture
def ada():
    return User.objects.create_user("ada", "ada@example.com", "Sup3r-secret-pass")


@pytest.fixture
def bob():
    return User.objects.create_user("bob", "bob@example.com", "Sup3r-secret-pass")


@pytest.fixture
def league():
    return League.objects.create(provider_id=8, name="Premier League")


def cycle(*raws):
    sync.sync_live_scores(FakeClient(inplay=list(raws)))


def start_match(state="INPLAY_1ST_HALF"):
    """The first sighting of a match never notifies, so tests start it here and follow it afterwards."""
    cycle(fixture(state=state))


def follow(user, **target):
    return Favorite.objects.create(user=user, **target)


def arsenal():
    return Team.objects.get(name="Arsenal")


def chelsea():
    return Team.objects.get(name="Chelsea")


def test_a_goal_notifies_followers_of_the_scoring_teams_match(ada, bob, league):
    start_match()
    follow(ada, team=arsenal())
    cycle(fixture(home_goals=1, events=[GOAL]))

    (note,) = Notification.objects.all()
    assert note.user == ada and note.kind == Kind.GOAL and note.source == Source.TEAM
    assert note.title == "Goal! Arsenal 1-0 Chelsea"
    assert note.body == "Saka 12' - assist Odegaard"
    assert note.match is not None and note.read_at is None


def test_repeated_syncs_and_corrections_never_notify_twice(ada, league):
    start_match()
    follow(ada, team=arsenal())
    cycle(fixture(home_goals=1, events=[GOAL]))
    cycle(fixture(home_goals=1, events=[GOAL]))
    cycle(fixture(home_goals=1, events=[{**GOAL, "minute": 13}]))
    assert Notification.objects.count() == 1


def test_a_match_seen_for_the_first_time_does_not_notify(ada, league):
    # The follower has to exist before the match does, so use a followed league.
    follow(ada, league=league)
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert Notification.objects.count() == 0


def test_kickoff_half_time_and_full_time(ada, league):
    start_match(state="NS")
    follow(ada, match=Match.objects.get())
    cycle(fixture())
    cycle(fixture(state="HT"))
    cycle(fixture(state="INPLAY_2ND_HALF"))
    cycle(fixture(state="FT", home_goals=2))
    kinds = list(Notification.objects.order_by("id").values_list("kind", flat=True))
    assert kinds == [Kind.MATCH_START, Kind.HALF_TIME, Kind.FULL_TIME]
    titles = list(Notification.objects.order_by("id").values_list("title", flat=True))
    assert titles == ["Kick-off: Arsenal vs Chelsea", "Half-time: Arsenal 0-0 Chelsea", "Full-time: Arsenal 2-0 Chelsea"]


def test_second_half_restart_is_not_a_second_kickoff(ada, league):
    start_match()
    follow(ada, league=league)
    cycle(fixture(state="HT"))
    cycle(fixture(state="INPLAY_2ND_HALF"))
    assert list(Notification.objects.values_list("kind", flat=True)) == [Kind.HALF_TIME]


def test_red_card_notifies_followers_of_the_league(ada, league):
    start_match()
    follow(ada, league=league)
    cycle(fixture(events=[RED]))
    (note,) = Notification.objects.all()
    assert note.kind == Kind.RED_CARD and note.source == Source.LEAGUE
    assert note.title == "Red card for Chelsea" and note.body.startswith("Cucurella 60'")


def test_yellow_cards_and_substitutions_do_not_notify(ada, league):
    start_match()
    follow(ada, league=league)
    cycle(fixture(events=[{"id": 2, "type": {"developer_name": "YELLOWCARD"}, "player_id": 11, "participant_id": 2, "minute": 20}]))
    assert Notification.objects.count() == 0


def test_people_who_follow_nothing_relevant_get_nothing(ada, bob, league):
    start_match()
    follow(ada, team=arsenal())
    other = Team.objects.create(provider_id=777, name="Spurs")
    follow(bob, team=other)
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert list(Notification.objects.values_list("user_id", flat=True)) == [ada.id]


def test_the_most_specific_follow_is_recorded_as_the_source(ada, league):
    start_match()
    follow(ada, league=league)
    follow(ada, team=arsenal())
    follow(ada, match=Match.objects.get())
    cycle(fixture(home_goals=1, events=[GOAL]))
    (note,) = Notification.objects.all()
    assert note.source == Source.MATCH


def test_preferences_filter_kinds_and_sources(ada, bob, league):
    start_match()
    follow(ada, team=arsenal())
    NotificationPreference.objects.create(user=ada, goals=False)
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert Notification.objects.count() == 0
    cycle(fixture(state="FT", home_goals=1, events=[GOAL]))
    assert list(Notification.objects.values_list("kind", flat=True)) == [Kind.FULL_TIME]

    NotificationPreference.objects.filter(user=ada).update(enabled=False)
    Notification.objects.all().delete()
    spec = {"match_id": Match.objects.get().id, "kind": "goal", "dedupe_key": "goal:99", "title": "t", "body": ""}
    assert services.deliver(spec) == 0


def test_following_teams_can_be_switched_off_without_losing_match_follows(ada, league):
    start_match()
    NotificationPreference.objects.create(user=ada, favorite_teams=False)
    follow(ada, team=arsenal())
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert Notification.objects.count() == 0
    follow(ada, match=Match.objects.get())
    cycle(fixture(home_goals=1, events=[{**GOAL, "id": 2}]))
    assert Notification.objects.count() == 1


def test_wants_defaults_to_everything_on():
    assert services.wants(None, Kind.GOAL, Source.TEAM) is True
    prefs = SimpleNamespace(enabled=True, goals=True, match_start=True, half_time=True, full_time=True,
                            red_cards=True, favorite_teams=True, favorite_leagues=False)
    assert services.wants(prefs, Kind.RED_CARD, Source.TEAM) is True
    assert services.wants(prefs, Kind.RED_CARD, Source.LEAGUE) is False
    assert services.wants(prefs, Kind.RED_CARD, Source.MATCH) is True
    prefs.enabled = False
    assert services.wants(prefs, Kind.GOAL, Source.MATCH) is False


def test_a_notification_failure_never_breaks_the_sync(ada, league, monkeypatch):
    start_match()
    follow(ada, team=arsenal())

    def boom(records):
        raise RuntimeError("notifications are down")

    monkeypatch.setattr(services, "queue_for_changes", boom)
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert Match.objects.get().home_score == 1


def test_a_broker_outage_falls_back_to_inline_delivery(ada, league, monkeypatch):
    start_match()
    follow(ada, team=arsenal())

    def no_broker(spec):
        raise ConnectionError("broker down")

    monkeypatch.setattr(tasks.deliver_notification, "delay", no_broker)
    cycle(fixture(home_goals=1, events=[GOAL]))
    assert Notification.objects.count() == 1


def test_purge_removes_old_read_and_very_old_notifications(ada, league):
    start_match()
    match = Match.objects.get()
    now = timezone.now()

    def make(key, age_days, read):
        note = Notification.objects.create(
            user=ada, kind=Kind.GOAL, source=Source.MATCH, match=match, title=key, dedupe_key=key,
            read_at=now if read else None,
        )
        Notification.objects.filter(pk=note.pk).update(created_at=now - timedelta(days=age_days))

    make("old-read", 40, True)
    make("old-unread", 40, False)
    make("ancient-unread", 100, False)
    make("fresh-read", 2, True)
    assert services.purge_old(now) == {"read": 1, "old": 1}
    assert sorted(Notification.objects.values_list("title", flat=True)) == ["fresh-read", "old-unread"]
