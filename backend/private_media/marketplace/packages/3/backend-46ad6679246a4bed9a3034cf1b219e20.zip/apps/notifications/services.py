import logging
from datetime import timedelta

from django.db.models import Q
from django.utils import timezone

from apps.favorites.models import Favorite
from apps.matches.models import Match
from integrations.sportmonks.constants import LIVE_STATUSES

from .models import Kind, Notification, NotificationPreference, Source

logger = logging.getLogger(__name__)

READ_RETENTION = timedelta(days=30)
MAX_RETENTION = timedelta(days=90)

# notification kind -> NotificationPreference field
KIND_FIELD = {
    Kind.GOAL: "goals",
    Kind.MATCH_START: "match_start",
    Kind.HALF_TIME: "half_time",
    Kind.FULL_TIME: "full_time",
    Kind.RED_CARD: "red_cards",
}
SOURCE_FIELD = {Source.TEAM: "favorite_teams", Source.LEAGUE: "favorite_leagues"}
SOURCE_ORDER = (Source.MATCH, Source.TEAM, Source.LEAGUE)  # the most specific reason wins


def wants(prefs, kind, source):
    """Whether a user's preferences allow this kind of notification from this kind of follow.

    `prefs` is a NotificationPreference or None (a user who never opened the settings: everything on).
    """
    if prefs is None:
        return True
    if not prefs.enabled or not getattr(prefs, KIND_FIELD[kind]):
        return False
    field = SOURCE_FIELD.get(source)
    return getattr(prefs, field) if field else True


def _clock(event):
    if event.minute is None:
        return ""
    extra = f"+{event.extra_minute}" if event.extra_minute else ""
    return f"{event.minute}{extra}'"


def _scoreline(match):
    return f"{match.home_team.name} {match.home_score}-{match.away_score} {match.away_team.name}"


def _spec(match, kind, key, title, body=""):
    return {
        "match_id": match.id,
        "kind": kind.value,
        "dedupe_key": f"{kind.value}:{key}",
        "title": title[:200],
        "body": body[:300],
    }


def occurrences(records):
    """Turns detected match changes into notification specs (plain dicts, safe to send to Celery).

    Matches seen for the first time are skipped on purpose: their goals may be hours old.
    """
    specs = []
    for record in records:
        if record["old"] is None:
            continue
        match = record["match"]
        league = match.league.name if match.league_id else ""
        status = record["changes"].get("status")
        if status:
            before, after = status["from"], status["to"]
            if after == "LIVE" and before not in LIVE_STATUSES and before != "FT":
                specs.append(_spec(match, Kind.MATCH_START, match.id, f"Kick-off: {match.home_team.name} vs {match.away_team.name}", league))
            elif after == "HT" and before in LIVE_STATUSES:
                specs.append(_spec(match, Kind.HALF_TIME, match.id, f"Half-time: {_scoreline(match)}", league))
            elif after == "FT" and before in LIVE_STATUSES:
                specs.append(_spec(match, Kind.FULL_TIME, match.id, f"Full-time: {_scoreline(match)}", league))
        for event in record["new"]:
            who = event.player.display_name if event.player_id else "Unknown player"
            if event.type in ("GOAL", "OWN_GOAL"):
                detail = f"{who} {_clock(event)}".strip()
                if event.type == "OWN_GOAL":
                    detail += " (own goal)"
                elif event.assist_player_id:
                    detail += f" - assist {event.assist_player.display_name}"
                specs.append(_spec(match, Kind.GOAL, event.provider_id, f"Goal! {_scoreline(match)}", detail))
            elif event.type == "RED_CARD":
                team = event.team.name if event.team_id else "a team"
                specs.append(
                    _spec(match, Kind.RED_CARD, event.provider_id, f"Red card for {team}", f"{who} {_clock(event)} - {_scoreline(match)}".strip())
                )
    return specs


def recipients(match):
    """{user_id: source} for everyone following this match, its teams or its league."""
    query = Q(match_id=match.id) | Q(team_id__in=[match.home_team_id, match.away_team_id])
    if match.league_id:
        query |= Q(league_id=match.league_id)
    reasons = {}
    for user_id, match_id, team_id in Favorite.objects.filter(query).values_list("user_id", "match_id", "team_id"):
        source = Source.MATCH if match_id else Source.TEAM if team_id else Source.LEAGUE
        reasons.setdefault(user_id, set()).add(source)
    return {user_id: next(s for s in SOURCE_ORDER if s in found) for user_id, found in reasons.items()}


def deliver(spec):
    """Creates the notification for every follower who wants it. Safe to run twice. Returns how many were created."""
    match = Match.objects.filter(pk=spec["match_id"]).only("id", "league_id", "home_team_id", "away_team_id").first()
    if match is None:
        return 0
    kind = Kind(spec["kind"])
    found = recipients(match)
    if not found:
        return 0
    prefs = {p.user_id: p for p in NotificationPreference.objects.filter(user_id__in=found)}
    already = set(Notification.objects.filter(dedupe_key=spec["dedupe_key"], user_id__in=found).values_list("user_id", flat=True))
    rows = [
        Notification(
            user_id=user_id, kind=kind, source=source, match_id=match.id,
            title=spec["title"], body=spec["body"], dedupe_key=spec["dedupe_key"],
        )
        for user_id, source in found.items()
        if user_id not in already and wants(prefs.get(user_id), kind, source)
    ]
    # ignore_conflicts covers two syncs racing past the `already` check
    Notification.objects.bulk_create(rows, ignore_conflicts=True)
    return len(rows)


def queue_for_changes(records):
    from .tasks import deliver_notification

    for spec in occurrences(records):
        try:
            deliver_notification.delay(spec)
        except Exception:
            # Broker down: deliver here rather than lose the notification.
            logger.warning("Could not queue %s, delivering inline", spec["dedupe_key"], exc_info=True)
            deliver(spec)


def purge_old(now=None):
    now = now or timezone.now()
    read = Notification.objects.filter(read_at__isnull=False, created_at__lt=now - READ_RETENTION).delete()[0]
    old = Notification.objects.filter(created_at__lt=now - MAX_RETENTION).delete()[0]
    return {"read": read, "old": old}
