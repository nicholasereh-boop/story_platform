import pytest
from rest_framework.test import APIClient

from apps.football.models import League, Player, Season, Standing, Team, TeamPlayer

pytestmark = pytest.mark.django_db
API = "/api/v1/"


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def league():
    return League.objects.create(provider_id=8, name="Premier League", country="England")


def team(provider_id, name, **extra):
    return Team.objects.create(provider_id=provider_id, name=name, **extra)


def names(response):
    return [row["name"] for row in response.data["results"]]


def test_leagues_list_search_and_filter(client, league):
    League.objects.create(provider_id=9, name="La Liga", country="Spain")
    assert set(names(client.get(API + "leagues/"))) == {"Premier League", "La Liga"}
    assert names(client.get(API + "leagues/", {"search": "liga"})) == ["La Liga"]
    assert names(client.get(API + "leagues/", {"country": "england"})) == ["Premier League"]
    detail = client.get(f"{API}leagues/{league.id}/").data
    assert detail["name"] == "Premier League" and "provider_id" not in detail


def test_league_standings_default_to_the_current_season(client, league):
    old = Season.objects.create(provider_id=1, league=league, name="2024/2025", is_current=False)
    current = Season.objects.create(provider_id=2, league=league, name="2025/2026", is_current=True)
    arsenal, chelsea = team(1, "Arsenal"), team(2, "Chelsea")
    Standing.objects.create(season=current, league=league, team=chelsea, position=2, points=20)
    Standing.objects.create(season=current, league=league, team=arsenal, position=1, points=25)
    Standing.objects.create(season=old, league=league, team=arsenal, position=1, points=90)

    data = client.get(f"{API}leagues/{league.id}/standings/").data
    assert data["season"]["name"] == "2025/2026"
    assert [row["team"]["name"] for row in data["table"]] == ["Arsenal", "Chelsea"]
    older = client.get(f"{API}leagues/{league.id}/standings/", {"season": old.id}).data
    assert older["table"][0]["points"] == 90


def test_league_standings_errors(client, league):
    assert client.get(f"{API}leagues/{league.id}/standings/").status_code == 404
    Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)
    assert client.get(f"{API}leagues/{league.id}/standings/", {"season": "abc"}).status_code == 400


def test_standings_endpoint_filters(client, league):
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)
    arsenal = team(1, "Arsenal")
    Standing.objects.create(season=season, league=league, team=arsenal, position=1, points=3)
    response = client.get(API + "standings/", {"league": league.id, "season": season.id})
    assert response.data["count"] == 1 and response.data["results"][0]["team"]["name"] == "Arsenal"


def test_teams_search_and_league_filter(client, league):
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)
    arsenal, chelsea = team(1, "Arsenal", country="England"), team(2, "Chelsea")
    team(3, "Real Madrid")
    for position, t in enumerate((arsenal, chelsea), 1):
        Standing.objects.create(season=season, league=league, team=t, position=position)
    assert names(client.get(API + "teams/", {"search": "madrid"})) == ["Real Madrid"]
    assert set(names(client.get(API + "teams/", {"league": league.id}))) == {"Arsenal", "Chelsea"}
    assert client.get(f"{API}teams/{arsenal.id}/").data["country"] == "England"


def test_team_squad_lists_active_players_by_shirt_number(client):
    arsenal = team(1, "Arsenal")
    saka = Player.objects.create(provider_id=1, display_name="Saka")
    raya = Player.objects.create(provider_id=2, display_name="Raya")
    gone = Player.objects.create(provider_id=3, display_name="Former")
    TeamPlayer.objects.create(team=arsenal, player=saka, shirt_number=7)
    TeamPlayer.objects.create(team=arsenal, player=raya, shirt_number=1)
    TeamPlayer.objects.create(team=arsenal, player=gone, shirt_number=2, active=False)
    squad = client.get(f"{API}teams/{arsenal.id}/squad/").data
    assert [m["player"]["name"] for m in squad] == ["Raya", "Saka"]
    assert client.get(f"{API}teams/99999/squad/").status_code == 404


def test_players_search_filter_and_current_team(client):
    arsenal, chelsea = team(1, "Arsenal"), team(2, "Chelsea")
    saka = Player.objects.create(provider_id=1, display_name="Bukayo Saka", position="Forward", nationality="England")
    james = Player.objects.create(provider_id=2, display_name="Reece James", position="Defender", nationality="England")
    TeamPlayer.objects.create(team=arsenal, player=saka)
    TeamPlayer.objects.create(team=chelsea, player=james)
    assert names_by_display(client.get(API + "players/", {"search": "saka"})) == ["Bukayo Saka"]
    assert names_by_display(client.get(API + "players/", {"team": chelsea.id})) == ["Reece James"]
    assert names_by_display(client.get(API + "players/", {"position": "defender"})) == ["Reece James"]
    detail = client.get(f"{API}players/{saka.id}/").data
    assert detail["current_team"]["name"] == "Arsenal"


def test_player_without_a_team_has_no_current_team(client):
    free = Player.objects.create(provider_id=1, display_name="Free Agent")
    assert client.get(f"{API}players/{free.id}/").data["current_team"] is None


def test_player_list_does_not_query_per_row(client, django_assert_max_num_queries):
    arsenal = team(1, "Arsenal")
    for i in range(8):
        TeamPlayer.objects.create(team=arsenal, player=Player.objects.create(provider_id=i, display_name=f"P{i}"))
    with django_assert_max_num_queries(4):
        assert client.get(API + "players/").status_code == 200


def names_by_display(response):
    return [row["display_name"] for row in response.data["results"]]
