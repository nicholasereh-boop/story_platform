from django.contrib.postgres.indexes import GinIndex, OpClass
from django.contrib.postgres.operations import TrigramExtension
from django.db import migrations
from django.db.models.functions import Upper

# (model, column, index name, table). Django compiles icontains to UPPER(col) LIKE UPPER(...), so the index has
# to be on UPPER(col). The SQL is written out because Django's own rendering of an expression plus an operator
# class produces ((UPPER("col") gin_trgm_ops)), which PostgreSQL rejects.
INDEXES = [
    ("team", "name", "football_team_name_trgm", "football_team"),
    ("team", "short_name", "football_team_short_trgm", "football_team"),
    ("player", "display_name", "football_player_name_trgm", "football_player"),
    ("player", "first_name", "football_player_first_trgm", "football_player"),
    ("player", "last_name", "football_player_last_trgm", "football_player"),
]


def create_sql(column, name, table):
    return f'CREATE INDEX "{name}" ON "{table}" USING gin ((UPPER("{column}")) gin_trgm_ops);'


def drop_sql(name):
    return f'DROP INDEX IF EXISTS "{name}";'


class Migration(migrations.Migration):
    dependencies = [("football", "0002_database_foundation")]

    operations = [
        TrigramExtension(),
        *[
            migrations.SeparateDatabaseAndState(
                database_operations=[
                    migrations.RunSQL(create_sql(column, name, table), reverse_sql=drop_sql(name)),
                ],
                # The model state still lists the index, so `makemigrations` stays quiet.
                state_operations=[
                    migrations.AddIndex(
                        model_name=model,
                        index=GinIndex(OpClass(Upper(column), name="gin_trgm_ops"), name=name),
                    ),
                ],
            )
            for model, column, name, table in INDEXES
        ],
    ]
