from celery import chain, shared_task

from apps.core.sync_utils import run_sync

from . import sync


@shared_task(bind=True, max_retries=5)
def sync_leagues(self):
    return run_sync(self, "leagues", sync.sync_leagues)


@shared_task(bind=True, max_retries=5)
def sync_teams(self):
    return run_sync(self, "teams", sync.sync_teams)


@shared_task(bind=True, max_retries=5)
def sync_players(self):
    return run_sync(self, "players", sync.sync_players, lock_timeout=3600)


@shared_task(bind=True, max_retries=5)
def sync_standings(self):
    return run_sync(self, "standings", sync.sync_standings)


@shared_task
def sync_reference_data():
    chain(sync_leagues.si(), sync_teams.si(), sync_standings.si()).apply_async()
