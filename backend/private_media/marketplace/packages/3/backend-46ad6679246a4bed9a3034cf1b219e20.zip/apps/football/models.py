from django.core.exceptions import ValidationError
from django.contrib.postgres.indexes import GinIndex, OpClass
from django.db import models
from django.db.models import Q
from django.db.models.functions import Upper


class TimeStamped(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class League(TimeStamped):
    provider_id = models.PositiveBigIntegerField(unique=True)
    name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    logo = models.URLField(blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        indexes = [
            models.Index(fields=["name"], name="football_league_name_idx"),
            models.Index(fields=["country", "active"], name="football_league_ctry_act_idx"),
        ]

    def __str__(self):
        return self.name


class Season(TimeStamped):
    provider_id = models.PositiveBigIntegerField(unique=True)
    league = models.ForeignKey(League, on_delete=models.CASCADE, related_name="seasons")
    name = models.CharField(max_length=100)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    is_current = models.BooleanField(default=False)

    class Meta:
        ordering = ["-start_date", "name"]
        indexes = [
            models.Index(fields=["league", "is_current"], name="football_season_lg_cur_idx"),
        ]
        constraints = [
            models.UniqueConstraint(fields=["league", "name"], name="unique_league_season_name"),
            models.UniqueConstraint(
                fields=["league"],
                condition=Q(is_current=True),
                name="unique_current_season_per_league",
            ),
            models.CheckConstraint(
                condition=Q(start_date__isnull=True) | Q(end_date__isnull=True) | Q(end_date__gte=models.F("start_date")),
                name="season_end_after_start",
            ),
        ]

    def __str__(self):
        return f"{self.league} {self.name}"


class Team(TimeStamped):
    provider_id = models.PositiveBigIntegerField(unique=True)
    name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=100, blank=True)
    code = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=100, blank=True)
    logo = models.URLField(blank=True)
    stadium = models.CharField(max_length=200, blank=True)
    founded = models.PositiveIntegerField(null=True, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        indexes = [
            models.Index(fields=["name"], name="football_team_name_idx"),
            models.Index(fields=["country"], name="football_team_country_idx"),
            GinIndex(OpClass(Upper("name"), name="gin_trgm_ops"), name="football_team_name_trgm"),
            GinIndex(OpClass(Upper("short_name"), name="gin_trgm_ops"), name="football_team_short_trgm"),
        ]

    def __str__(self):
        return self.name


class Player(TimeStamped):
    provider_id = models.PositiveBigIntegerField(unique=True)
    first_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=100, blank=True)
    display_name = models.CharField(max_length=200)
    date_of_birth = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, blank=True)
    position = models.CharField(max_length=50, blank=True)
    image = models.URLField(blank=True)

    class Meta:
        ordering = ["display_name"]
        indexes = [
            models.Index(fields=["display_name"], name="football_player_name_idx"),
            models.Index(fields=["last_name"], name="football_player_lname_idx"),
            GinIndex(OpClass(Upper("display_name"), name="gin_trgm_ops"), name="football_player_name_trgm"),
            GinIndex(OpClass(Upper("first_name"), name="gin_trgm_ops"), name="football_player_first_trgm"),
            GinIndex(OpClass(Upper("last_name"), name="gin_trgm_ops"), name="football_player_last_trgm"),
        ]

    def __str__(self):
        return self.display_name


class TeamPlayer(TimeStamped):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="squad")
    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name="team_memberships")
    shirt_number = models.PositiveIntegerField(null=True, blank=True)
    position = models.CharField(max_length=50, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        indexes = [
            models.Index(fields=["team", "active"], name="football_tp_team_active_idx"),
        ]
        constraints = [
            models.UniqueConstraint(fields=["team", "player"], name="unique_team_player"),
        ]

    def __str__(self):
        return f"{self.player} @ {self.team}"


class Standing(TimeStamped):
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="standings")
    league = models.ForeignKey(League, on_delete=models.CASCADE, related_name="standings")
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="standings")
    position = models.PositiveIntegerField()
    played = models.PositiveIntegerField(default=0)
    won = models.PositiveIntegerField(default=0)
    drawn = models.PositiveIntegerField(default=0)
    lost = models.PositiveIntegerField(default=0)
    goals_for = models.IntegerField(default=0)
    goals_against = models.IntegerField(default=0)
    goal_difference = models.IntegerField(default=0)
    points = models.IntegerField(default=0)
    form = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ["position"]
        indexes = [
            models.Index(fields=["league", "season", "position"], name="football_standing_tbl_idx"),
        ]
        constraints = [
            models.UniqueConstraint(fields=["season", "team"], name="unique_season_team_standing"),
            models.CheckConstraint(condition=Q(position__gte=1), name="standing_position_gte_1"),
        ]

    def clean(self):
        if self.season_id and self.league_id and self.season.league_id != self.league_id:
            raise ValidationError("Standing league must match the season's league.")

    def __str__(self):
        return f"{self.season} #{self.position} {self.team}"
