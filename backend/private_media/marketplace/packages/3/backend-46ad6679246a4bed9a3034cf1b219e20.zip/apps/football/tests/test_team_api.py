from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Season, Standing, Team
from apps.matches.models import Match

pytestmark = pytest.mark.django_db
API = "/api/v1/teams/"
_ids = iter(range(7000, 90000))


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def world():
    league = League.objects.create(provider_id=8, name="Premier League")
    cup = League.objects.create(provider_id=9, name="FA Cup")
    current = Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)
    old = Season.objects.create(provider_id=2, league=league, name="2024/2025")
    cup_season = Season.objects.create(provider_id=3, league=cup, name="2025/2026", is_current=True)
    teams = {n: Team.objects.create(provider_id=i, name=n, stadium="Emirates" if n == "Arsenal" else "")
             for i, n in enumerate(["Arsenal", "Chelsea", "Spurs"], 1)}
    return {"league": league, "cup": cup, "current": current, "old": old, "cup_season": cup_season, **teams}


def game(world, home, away, hs, as_, season="current", league="league", status="FT", days=1):
    return Match.objects.create(
        provider_id=next(_ids), league=world[league], season=world[season], home_team=world[home], away_team=world[away],
        home_score=hs, away_score=as_, status=status, scheduled_at=timezone.now() - timedelta(days=days),
    )


def test_detail_includes_league_positions_for_current_seasons_only(client, world):
    a = world["Arsenal"]
    Standing.objects.create(season=world["current"], league=world["league"], team=a, position=2, played=10, points=22, form="WWDLW")
    Standing.objects.create(season=world["old"], league=world["league"], team=a, position=9, played=38, points=50)
    data = client.get(f"{API}{a.id}/").data
    assert data["stadium"] == "Emirates"
    assert len(data["positions"]) == 1
    position = data["positions"][0]
    assert position["position"] == 2 and position["league"]["name"] == "Premier League" and position["season_name"] == "2025/2026"


def test_detail_without_standings_has_no_positions_and_list_is_unchanged(client, world):
    a = world["Arsenal"]
    assert client.get(f"{API}{a.id}/").data["positions"] == []
    assert "positions" not in client.get(API).data["results"][0]


def test_detail_query_count_is_fixed(client, world, django_assert_max_num_queries):
    a = world["Arsenal"]
    for i, season in enumerate(("current", "old")):
        Standing.objects.create(season=world[season], league=world["league"], team=a, position=i + 1)
    with django_assert_max_num_queries(4):
        assert client.get(f"{API}{a.id}/").status_code == 200


def test_statistics_count_home_and_away_from_the_teams_point_of_view(client, world):
    a = world["Arsenal"]
    game(world, "Arsenal", "Chelsea", 2, 0, days=5)   # home win
    game(world, "Spurs", "Arsenal", 1, 1, days=4)     # away draw
    game(world, "Chelsea", "Arsenal", 3, 1, days=3)   # away loss
    game(world, "Arsenal", "Spurs", 0, 0, days=2)     # home draw, no goals
    game(world, "Arsenal", "Spurs", 9, 9, status="LIVE")  # ignored
    game(world, "Chelsea", "Spurs", 5, 5)             # not theirs

    data = client.get(f"{API}{a.id}/statistics/").data
    overall = data["overall"]
    assert (overall["played"], overall["won"], overall["drawn"], overall["lost"]) == (4, 1, 2, 1)
    assert (overall["goals_for"], overall["goals_against"], overall["goal_difference"]) == (4, 4, 0)
    assert overall["points"] == 5 and overall["clean_sheets"] == 2 and overall["failed_to_score"] == 1
    assert overall["goals_per_match"] == 1.0
    assert (data["home"]["played"], data["home"]["won"], data["home"]["drawn"]) == (2, 1, 1)
    assert (data["away"]["played"], data["away"]["drawn"], data["away"]["lost"]) == (2, 1, 1)
    assert data["form"] == ["D", "L", "D", "W"]


def test_form_is_the_last_five_newest_first(client, world):
    a = world["Arsenal"]
    for days, (hs, as_) in zip(range(7, 0, -1), [(1, 0), (1, 0), (1, 0), (0, 1), (0, 0), (2, 0), (0, 3)]):
        game(world, "Arsenal", "Chelsea", hs, as_, days=days)
    assert client.get(f"{API}{a.id}/statistics/").data["form"] == ["L", "W", "D", "L", "W"]


def test_statistics_default_to_current_seasons_and_can_widen_or_narrow(client, world):
    a = world["Arsenal"]
    game(world, "Arsenal", "Chelsea", 1, 0)
    game(world, "Arsenal", "Chelsea", 4, 0, season="old", days=300)
    game(world, "Arsenal", "Spurs", 2, 0, season="cup_season", league="cup")

    assert client.get(f"{API}{a.id}/statistics/").data["overall"]["played"] == 2
    assert client.get(f"{API}{a.id}/statistics/").data["scope"] == {"type": "current", "season": None}
    assert client.get(f"{API}{a.id}/statistics/", {"scope": "all"}).data["overall"]["played"] == 3
    narrow = client.get(f"{API}{a.id}/statistics/", {"season": world["old"].id}).data
    assert narrow["overall"]["played"] == 1 and narrow["scope"]["season"]["name"] == "2024/2025"


def test_statistics_fall_back_to_all_matches_when_nothing_is_in_a_current_season(client, world):
    a = world["Arsenal"]
    game(world, "Arsenal", "Chelsea", 1, 0, season="old", days=300)
    data = client.get(f"{API}{a.id}/statistics/").data
    assert data["scope"]["type"] == "all" and data["overall"]["played"] == 1


def test_statistics_for_a_team_without_matches_are_zeroes(client, world):
    data = client.get(f"{API}{world['Spurs'].id}/statistics/").data
    assert data["overall"]["played"] == 0 and data["overall"]["goals_per_match"] == 0 and data["form"] == []


def test_statistics_parameter_validation(client, world):
    a = world["Arsenal"]
    assert client.get(f"{API}{a.id}/statistics/", {"scope": "forever"}).status_code == 400
    assert client.get(f"{API}{a.id}/statistics/", {"season": "abc"}).status_code == 400
    assert client.get(f"{API}{a.id}/statistics/", {"season": 99999}).status_code == 404
    assert client.get(f"{API}99999/statistics/").status_code == 404
