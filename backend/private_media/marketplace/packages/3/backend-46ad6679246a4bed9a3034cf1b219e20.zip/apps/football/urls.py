from rest_framework.routers import DefaultRouter
from .views import LeagueViewSet, SeasonViewSet, TeamViewSet, PlayerViewSet, StandingViewSet
router = DefaultRouter()
router.register("leagues", LeagueViewSet)
router.register("seasons", SeasonViewSet)
router.register("teams", TeamViewSet)
router.register("players", PlayerViewSet, basename="player")
router.register("standings", StandingViewSet)
urlpatterns = router.urls
