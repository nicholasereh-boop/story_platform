import pytest

from apps.football import sync
from apps.football.models import League, Player, Season, Standing, Team, TeamPlayer

pytestmark = pytest.mark.django_db


class FakeClient:
    def __init__(self, leagues=(), teams=None, squads=None, standings=None):
        self._leagues = list(leagues)
        self._teams = teams or {}
        self._squads = squads or {}
        self._standings = standings or {}

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def leagues(self):
        return iter(self._leagues)

    def teams_by_season(self, season_id):
        return iter(self._teams.get(season_id, []))

    def squad(self, team_id):
        return iter(self._squads.get(team_id, []))

    def standings_by_season(self, season_id):
        return iter(self._standings.get(season_id, []))


def league_payload(current_season_id=100):
    return {
        "id": 8, "name": "Premier League", "short_code": "UK PL", "active": True,
        "country": {"name": "England"},
        "seasons": [
            {"id": 100, "league_id": 8, "name": "2025/2026", "is_current": current_season_id == 100,
             "starting_at": "2025-08-01", "ending_at": "2026-05-30"},
            {"id": 101, "league_id": 8, "name": "2026/2027", "is_current": current_season_id == 101,
             "starting_at": "2026-08-01", "ending_at": "2027-05-30"},
        ],
    }


def test_sync_leagues_is_idempotent_and_keeps_one_current_season():
    first = sync.sync_leagues(FakeClient([league_payload(100)]))
    assert first == {"leagues": 1, "seasons": 2}
    sync.sync_leagues(FakeClient([league_payload(100)]))
    assert League.objects.count() == 1 and Season.objects.count() == 2
    assert Season.objects.get(is_current=True).provider_id == 100


def test_sync_leagues_moves_the_current_flag_without_constraint_errors():
    sync.sync_leagues(FakeClient([league_payload(100)]))
    sync.sync_leagues(FakeClient([league_payload(101)]))
    assert list(Season.objects.filter(is_current=True).values_list("provider_id", flat=True)) == [101]


def test_sync_leagues_respects_the_league_allow_list(settings):
    settings.SPORTMONKS_LEAGUE_IDS = {564}
    assert sync.sync_leagues(FakeClient([league_payload()])) == {"leagues": 0, "seasons": 0}


def test_sync_teams_only_for_current_seasons():
    sync.sync_leagues(FakeClient([league_payload(100)]))
    client = FakeClient(teams={
        100: [{"id": 1, "name": "Arsenal", "short_code": "ARS", "venue": {"name": "Emirates"}},
              {"id": 2, "name": "Chelsea"}],
        101: [{"id": 3, "name": "Not Current FC"}],
    })
    assert sync.sync_teams(client) == {"teams": 2}
    assert set(Team.objects.values_list("name", flat=True)) == {"Arsenal", "Chelsea"}


def test_sync_standings_creates_rows_and_missing_teams():
    sync.sync_leagues(FakeClient([league_payload(100)]))
    client = FakeClient(standings={100: [{
        "participant_id": 1, "position": 1, "points": 25,
        "participant": {"name": "Arsenal", "image_path": "a.png"},
        "details": [{"type_id": 129, "value": 10}, {"type_id": 133, "value": 20}, {"type_id": 134, "value": 8}],
        "form": [{"form": "W", "sort_order": 1}],
    }]})
    assert sync.sync_standings(client) == {"standings": 1}
    standing = Standing.objects.get()
    assert standing.team.name == "Arsenal" and standing.points == 25
    assert standing.goal_difference == 12 and standing.form == "W"
    assert standing.league_id == standing.season.league_id


def test_sync_players_builds_squad_and_deactivates_departures():
    team = Team.objects.create(provider_id=1, name="Arsenal")
    saka = {"jersey_number": 7, "position_id": 27, "player": {"id": 9, "display_name": "Bukayo Saka"}}
    odegaard = {"jersey_number": 8, "position_id": 26, "player": {"id": 10, "display_name": "Martin Odegaard"}}

    sync.sync_players(FakeClient(squads={1: [saka, odegaard]}), team_ids=[team.id])
    assert TeamPlayer.objects.filter(team=team, active=True).count() == 2

    sync.sync_players(FakeClient(squads={1: [saka]}), team_ids=[team.id])
    assert TeamPlayer.objects.get(team=team, player__provider_id=10).active is False
    assert TeamPlayer.objects.get(team=team, player__provider_id=9).shirt_number == 7
    assert Player.objects.count() == 2
