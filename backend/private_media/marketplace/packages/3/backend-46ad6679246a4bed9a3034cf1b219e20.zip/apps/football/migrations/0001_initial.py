from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="League",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("provider_id", models.PositiveBigIntegerField(unique=True)),
                ("name", models.CharField(max_length=200)),
                ("short_name", models.CharField(blank=True, max_length=100)),
                ("country", models.CharField(blank=True, max_length=100)),
                ("logo", models.URLField(blank=True)),
                ("active", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="Player",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("provider_id", models.PositiveBigIntegerField(unique=True)),
                ("first_name", models.CharField(blank=True, max_length=100)),
                ("last_name", models.CharField(blank=True, max_length=100)),
                ("display_name", models.CharField(max_length=200)),
                ("date_of_birth", models.DateField(blank=True, null=True)),
                ("nationality", models.CharField(blank=True, max_length=100)),
                ("position", models.CharField(blank=True, max_length=50)),
                ("image", models.URLField(blank=True)),
            ],
        ),
        migrations.CreateModel(
            name="Team",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("provider_id", models.PositiveBigIntegerField(unique=True)),
                ("name", models.CharField(max_length=200)),
                ("short_name", models.CharField(blank=True, max_length=100)),
                ("code", models.CharField(blank=True, max_length=20)),
                ("country", models.CharField(blank=True, max_length=100)),
                ("logo", models.URLField(blank=True)),
                ("stadium", models.CharField(blank=True, max_length=200)),
                ("founded", models.PositiveIntegerField(blank=True, null=True)),
                ("active", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="Season",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("provider_id", models.PositiveBigIntegerField(unique=True)),
                ("name", models.CharField(max_length=100)),
                ("start_date", models.DateField(blank=True, null=True)),
                ("end_date", models.DateField(blank=True, null=True)),
                ("is_current", models.BooleanField(default=False)),
                ("league", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="seasons", to="football.league")),
            ],
        ),
        migrations.CreateModel(
            name="Standing",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("position", models.PositiveIntegerField()),
                ("played", models.PositiveIntegerField(default=0)),
                ("won", models.PositiveIntegerField(default=0)),
                ("drawn", models.PositiveIntegerField(default=0)),
                ("lost", models.PositiveIntegerField(default=0)),
                ("goals_for", models.IntegerField(default=0)),
                ("goals_against", models.IntegerField(default=0)),
                ("goal_difference", models.IntegerField(default=0)),
                ("points", models.IntegerField(default=0)),
                ("form", models.CharField(blank=True, max_length=20)),
                ("league", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="standings", to="football.league")),
                ("season", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="standings", to="football.season")),
                ("team", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="standings", to="football.team")),
            ],
            options={"ordering": ["position"]},
        ),
        migrations.CreateModel(
            name="TeamPlayer",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("shirt_number", models.PositiveIntegerField(blank=True, null=True)),
                ("position", models.CharField(blank=True, max_length=50)),
                ("active", models.BooleanField(default=True)),
                ("player", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="team_memberships", to="football.player")),
                ("team", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="squad", to="football.team")),
            ],
            options={"constraints":[models.UniqueConstraint(fields=("team","player"), name="unique_team_player")]},
        ),
        migrations.AddConstraint(
            model_name="standing",
            constraint=models.UniqueConstraint(fields=("season","team"), name="unique_season_team_standing"),
        ),
    ]
