from django.db.models import Count, F, Q, Sum
from rest_framework.exceptions import NotFound, ValidationError

from apps.matches.models import Match, MatchEvent

from .models import Season, Standing, Team

LEADERS_DEFAULT = 10
LEADERS_MAX = 25


def resolve_season(league, raw):
    """The requested season of this league, else its current one, else its newest."""
    seasons = Season.objects.filter(league=league)
    if raw:
        if not str(raw).isdigit():
            raise ValidationError({"season": "Must be a season id."})
        season = seasons.filter(pk=raw).first()
    else:
        season = seasons.filter(is_current=True).first() or seasons.first()
    if season is None:
        raise NotFound("This league has no season." if not raw else "This league has no such season.")
    return season


def parse_limit(raw):
    if raw is None:
        return LEADERS_DEFAULT
    if not str(raw).isdigit() or not 1 <= int(raw) <= LEADERS_MAX:
        raise ValidationError({"limit": f"Must be a whole number between 1 and {LEADERS_MAX}."})
    return int(raw)


def league_teams(league, season):
    ids = set(Standing.objects.filter(season=season).values_list("team_id", flat=True))
    matches = Match.objects.filter(league=league, season=season)
    ids.update(matches.values_list("home_team_id", flat=True))
    ids.update(matches.values_list("away_team_id", flat=True))
    return Team.objects.filter(id__in=ids).order_by("name")


def season_summary(league, season):
    finished = Match.objects.filter(league=league, season=season, status="FT")
    totals = finished.aggregate(
        played=Count("id"),
        goals=Sum(F("home_score") + F("away_score")),
        home_wins=Count("id", filter=Q(home_score__gt=F("away_score"))),
        away_wins=Count("id", filter=Q(away_score__gt=F("home_score"))),
        draws=Count("id", filter=Q(home_score=F("away_score"))),
    )
    played = totals["played"] or 0
    goals = totals["goals"] or 0
    events = MatchEvent.objects.filter(match__league=league, match__season=season)
    cards = events.aggregate(
        yellow_cards=Count("id", filter=Q(type="YELLOW_CARD")),
        red_cards=Count("id", filter=Q(type="RED_CARD")),
    )
    return {
        "played": played,
        "goals": goals,
        "goals_per_match": round(goals / played, 2) if played else 0,
        "home_wins": totals["home_wins"] or 0,
        "draws": totals["draws"] or 0,
        "away_wins": totals["away_wins"] or 0,
        **cards,
    }


def leaders(league, season, player_field, limit):
    """Top goal scorers (player_field='player') or assisters (player_field='assist_player')."""
    events = MatchEvent.objects.filter(
        match__league=league, match__season=season, type="GOAL", **{f"{player_field}__isnull": False}
    )
    rows = (
        events.values(f"{player_field}_id", f"{player_field}__display_name", "team_id", "team__name")
        .annotate(total=Count("id"))
        .order_by("-total", f"{player_field}__display_name")[:limit]
    )
    return [
        {
            "player": {"id": row[f"{player_field}_id"], "name": row[f"{player_field}__display_name"]},
            "team": {"id": row["team_id"], "name": row["team__name"]} if row["team_id"] else None,
            "total": row["total"],
        }
        for row in rows
    ]


def coverage(league, season):
    finished = Match.objects.filter(league=league, season=season, status="FT")
    return {
        "finished_matches": finished.count(),
        "with_events": finished.filter(events__isnull=False).distinct().count(),
    }
