from django.db.models import Q
from rest_framework.exceptions import NotFound, ValidationError

from apps.matches.models import Match

from .models import Season

FORM_LENGTH = 5
SCOPES = ("current", "all")


def _empty():
    return {"played": 0, "won": 0, "drawn": 0, "lost": 0, "goals_for": 0, "goals_against": 0}


def _add(record, scored, conceded):
    record["played"] += 1
    record["goals_for"] += scored
    record["goals_against"] += conceded
    if scored > conceded:
        record["won"] += 1
    elif scored == conceded:
        record["drawn"] += 1
    else:
        record["lost"] += 1


def _finished(team):
    return Match.objects.filter(Q(home_team=team) | Q(away_team=team), status="FT")


def resolve_scope(team, season_param, scope_param):
    """Returns (queryset of finished matches, description of what was counted)."""
    finished = _finished(team)
    if season_param:
        if not str(season_param).isdigit():
            raise ValidationError({"season": "Must be a season id."})
        season = Season.objects.filter(pk=season_param).first()
        if season is None:
            raise NotFound("No such season.")
        return finished.filter(season=season), {"type": "season", "season": {"id": season.id, "name": season.name}}
    scope = scope_param or "current"
    if scope not in SCOPES:
        raise ValidationError({"scope": f"Must be one of: {', '.join(SCOPES)}."})
    if scope == "current":
        current = finished.filter(season__is_current=True)
        if current.exists():
            return current, {"type": "current", "season": None}
    return finished, {"type": "all", "season": None}


def team_statistics(team, matches):
    rows = list(matches.order_by("scheduled_at").values_list("home_team_id", "home_score", "away_score"))
    overall, home, away = _empty(), _empty(), _empty()
    clean_sheets = failed_to_score = 0
    results = []
    for home_team_id, home_score, away_score in rows:
        at_home = home_team_id == team.id
        scored, conceded = (home_score, away_score) if at_home else (away_score, home_score)
        _add(overall, scored, conceded)
        _add(home if at_home else away, scored, conceded)
        clean_sheets += conceded == 0
        failed_to_score += scored == 0
        results.append("W" if scored > conceded else "D" if scored == conceded else "L")

    played = overall["played"]
    overall.update(
        goal_difference=overall["goals_for"] - overall["goals_against"],
        points=3 * overall["won"] + overall["drawn"],
        clean_sheets=clean_sheets,
        failed_to_score=failed_to_score,
        goals_per_match=round(overall["goals_for"] / played, 2) if played else 0,
        conceded_per_match=round(overall["goals_against"] / played, 2) if played else 0,
    )
    return {"overall": overall, "home": home, "away": away, "form": results[-FORM_LENGTH:][::-1]}
