from django.db.models import Prefetch
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from . import league_stats, player_stats, team_stats
from .filters import LeagueFilter, PlayerFilter, SeasonFilter, StandingFilter, TeamFilter
from .models import League, Player, Season, Standing, Team, TeamPlayer
from .serializers import (
    LeagueSerializer, PlayerSerializer, SeasonSerializer, SquadMemberSerializer,
    StandingSerializer, TeamDetailSerializer, TeamSerializer,
)

BACKENDS = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]


class LeagueViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = League.objects.all()
    serializer_class = LeagueSerializer
    filter_backends = BACKENDS
    filterset_class = LeagueFilter
    search_fields = ["name", "short_name", "country"]
    ordering_fields = ["name", "country"]

    @action(detail=True, methods=["get"])
    def standings(self, request, pk=None):
        league = self.get_object()
        season = league_stats.resolve_season(league, request.query_params.get("season"))
        rows = Standing.objects.filter(season=season, league=league).select_related("team").order_by("position")
        return Response({"season": SeasonSerializer(season).data, "table": StandingSerializer(rows, many=True).data})

    @action(detail=True, methods=["get"])
    def teams(self, request, pk=None):
        league = self.get_object()
        season = league_stats.resolve_season(league, request.query_params.get("season"))
        teams = league_stats.league_teams(league, season)
        return Response({"season": SeasonSerializer(season).data, "teams": TeamSerializer(teams, many=True).data})

    @action(detail=True, methods=["get"])
    def statistics(self, request, pk=None):
        """Season totals and top scorers/assisters, computed from the matches and events stored so far."""
        league = self.get_object()
        season = league_stats.resolve_season(league, request.query_params.get("season"))
        limit = league_stats.parse_limit(request.query_params.get("limit"))
        return Response(
            {
                "season": SeasonSerializer(season).data,
                "summary": league_stats.season_summary(league, season),
                "top_scorers": league_stats.leaders(league, season, "player", limit),
                "top_assists": league_stats.leaders(league, season, "assist_player", limit),
                "coverage": league_stats.coverage(league, season),
            }
        )


class SeasonViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Season.objects.select_related("league")
    serializer_class = SeasonSerializer
    filter_backends = BACKENDS
    filterset_class = SeasonFilter
    ordering_fields = ["start_date", "name"]


class TeamViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    filter_backends = BACKENDS
    filterset_class = TeamFilter
    search_fields = ["name", "short_name", "country"]
    ordering_fields = ["name", "founded"]

    def get_queryset(self):
        queryset = super().get_queryset()
        if self.action == "retrieve":
            current = Prefetch(
                "standings",
                queryset=Standing.objects.filter(season__is_current=True)
                .select_related("league", "season")
                .order_by("league__name"),
                to_attr="current_standings",
            )
            queryset = queryset.prefetch_related(current)
        return queryset

    def get_serializer_class(self):
        return TeamDetailSerializer if self.action == "retrieve" else TeamSerializer

    @action(detail=True, methods=["get"])
    def squad(self, request, pk=None):
        team = self.get_object()
        members = (
            TeamPlayer.objects.filter(team=team, active=True)
            .select_related("player")
            .order_by("shirt_number", "player__display_name")
        )
        return Response(SquadMemberSerializer(members, many=True).data)

    @action(detail=True, methods=["get"])
    def statistics(self, request, pk=None):
        """Record, goals, clean sheets and form from finished matches. ?scope=current|all or ?season=ID."""
        team = self.get_object()
        matches, scope = team_stats.resolve_scope(team, request.query_params.get("season"), request.query_params.get("scope"))
        return Response({"scope": scope, **team_stats.team_statistics(team, matches)})


class PlayerViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = PlayerSerializer
    filter_backends = BACKENDS
    filterset_class = PlayerFilter
    search_fields = ["display_name", "first_name", "last_name"]
    ordering_fields = ["display_name"]

    def get_queryset(self):
        memberships = Prefetch(
            "team_memberships",
            queryset=TeamPlayer.objects.filter(active=True).select_related("team"),
            to_attr="active_memberships",
        )
        return Player.objects.prefetch_related(memberships)

    @action(detail=True, methods=["get"])
    def statistics(self, request, pk=None):
        """Appearances, goals, assists and cards from the lineups and events stored so far.
        ?scope=current|all or ?season=ID."""
        player = self.get_object()
        scope = player_stats.resolve_scope(player, request.query_params.get("season"), request.query_params.get("scope"))
        return Response(player_stats.player_statistics(player, scope))


class StandingViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Standing.objects.select_related("team")
    serializer_class = StandingSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_class = StandingFilter
    ordering_fields = ["position", "points"]
    ordering = ["season", "position"]
