import logging

from django.conf import settings
from django.db import transaction
from django.db.models import Q

from apps.core.cache import record_sync
from apps.core.upsert import bulk_upsert
from integrations.sportmonks import normalizers as norm
from integrations.sportmonks.client import client_scope

from .models import League, Player, Season, Standing, Team, TeamPlayer

logger = logging.getLogger(__name__)

LEAGUE_UPDATE_FIELDS = ["name", "short_name", "country", "logo", "active"]
SEASON_UPDATE_FIELDS = ["league", "name", "start_date", "end_date", "is_current"]
TEAM_UPDATE_FIELDS = ["name", "short_name", "code", "country", "logo", "stadium", "founded"]
PLAYER_UPDATE_FIELDS = [
    "first_name", "last_name", "display_name", "date_of_birth", "nationality", "position", "image",
]
STANDING_UPDATE_FIELDS = [
    "league", "position", "played", "won", "drawn", "lost",
    "goals_for", "goals_against", "goal_difference", "points", "form",
]


def ensure_teams(teams):
    unique = {t["provider_id"]: t for t in teams}
    if unique:
        Team.objects.bulk_create(
            [Team(provider_id=pid, name=t["name"], logo=t.get("logo", "")) for pid, t in unique.items()],
            ignore_conflicts=True,
        )
    return dict(Team.objects.filter(provider_id__in=list(unique)).values_list("provider_id", "id"))


def ensure_players(players):
    unique = {p["provider_id"]: p for p in players if p.get("provider_id") is not None}
    if unique:
        Player.objects.bulk_create(
            [
                Player(provider_id=pid, display_name=(p.get("display_name") or "Unknown player")[:200])
                for pid, p in unique.items()
            ],
            ignore_conflicts=True,
        )
    return dict(Player.objects.filter(provider_id__in=list(unique)).values_list("provider_id", "id"))


def sync_leagues(client=None):
    allowed = settings.SPORTMONKS_LEAGUE_IDS
    leagues, seasons = [], []
    with client_scope(client) as api:
        for raw in api.leagues():
            league = norm.normalize_league(raw)
            if league is None or (allowed and league["provider_id"] not in allowed):
                continue
            leagues.append(league)
            for raw_season in raw.get("seasons") or []:
                season = norm.normalize_season(raw_season, league["provider_id"])
                if season:
                    seasons.append(season)
    league_count = bulk_upsert(League, leagues, ["provider_id"], LEAGUE_UPDATE_FIELDS)
    season_count = _sync_seasons(seasons)
    record_sync("leagues")
    return {"leagues": league_count, "seasons": season_count}


def _sync_seasons(seasons):
    league_map = dict(
        League.objects.filter(provider_id__in={s["league_provider_id"] for s in seasons})
        .values_list("provider_id", "id")
    )
    current_by_league, seen_names, rows = {}, set(), []
    for season in seasons:
        league_id = league_map.get(season["league_provider_id"])
        key = (league_id, season["name"])
        if league_id is None or key in seen_names:
            continue
        seen_names.add(key)
        is_current = season["is_current"] and league_id not in current_by_league
        if is_current:
            current_by_league[league_id] = season["provider_id"]
        rows.append(
            {
                "provider_id": season["provider_id"],
                "league_id": league_id,
                "name": season["name"],
                "start_date": season["start_date"],
                "end_date": season["end_date"],
                "is_current": is_current,
            }
        )
    with transaction.atomic():
        for league_id, provider_id in current_by_league.items():
            Season.objects.filter(league_id=league_id, is_current=True).exclude(
                provider_id=provider_id
            ).update(is_current=False)
        return bulk_upsert(Season, rows, ["provider_id"], SEASON_UPDATE_FIELDS)


def current_seasons():
    return Season.objects.filter(is_current=True, league__active=True).select_related("league")


def current_season_teams():
    return Team.objects.filter(
        Q(standings__season__is_current=True)
        | Q(home_matches__season__is_current=True)
        | Q(away_matches__season__is_current=True)
    ).distinct()


def sync_teams(client=None):
    total = 0
    with client_scope(client) as api:
        for season in current_seasons():
            rows = [t for t in (norm.normalize_team(r) for r in api.teams_by_season(season.provider_id)) if t]
            total += bulk_upsert(Team, rows, ["provider_id"], TEAM_UPDATE_FIELDS)
    record_sync("teams")
    return {"teams": total}


def sync_players(client=None, team_ids=None):
    teams = Team.objects.filter(id__in=team_ids) if team_ids else current_season_teams()
    players_total = squad_total = 0
    with client_scope(client) as api:
        for team in teams.only("id", "provider_id"):
            members = [m for m in (norm.normalize_squad_member(r) for r in api.squad(team.provider_id)) if m]
            if not members:
                continue
            players_total += bulk_upsert(
                Player, [m["player"] for m in members], ["provider_id"], PLAYER_UPDATE_FIELDS
            )
            player_map = dict(
                Player.objects.filter(provider_id__in=[m["player"]["provider_id"] for m in members])
                .values_list("provider_id", "id")
            )
            rows = [
                {
                    "team_id": team.id,
                    "player_id": player_map[m["player"]["provider_id"]],
                    "shirt_number": m["shirt_number"],
                    "position": m["position"],
                    "active": True,
                }
                for m in members
                if m["player"]["provider_id"] in player_map
            ]
            squad_total += bulk_upsert(
                TeamPlayer, rows, ["team", "player"], ["shirt_number", "position", "active"]
            )
            TeamPlayer.objects.filter(team_id=team.id).exclude(
                player_id__in=[r["player_id"] for r in rows]
            ).update(active=False)
    record_sync("players")
    return {"players": players_total, "squad_members": squad_total}


def sync_standings(client=None):
    total = 0
    with client_scope(client) as api:
        for season in current_seasons():
            standings = [s for s in (norm.normalize_standing(r) for r in api.standings_by_season(season.provider_id)) if s]
            team_map = ensure_teams(
                {"provider_id": s["team_provider_id"], "name": s["team_name"] or f"Team {s['team_provider_id']}",
                 "logo": s["team_logo"]}
                for s in standings
            )
            rows = [
                {
                    "season_id": season.id,
                    "league_id": season.league_id,
                    "team_id": team_map[s["team_provider_id"]],
                    **{k: s[k] for k in STANDING_UPDATE_FIELDS if k != "league"},
                }
                for s in standings
                if s["team_provider_id"] in team_map
            ]
            total += bulk_upsert(Standing, rows, ["season", "team"], STANDING_UPDATE_FIELDS)
    record_sync("standings")
    return {"standings": total}
