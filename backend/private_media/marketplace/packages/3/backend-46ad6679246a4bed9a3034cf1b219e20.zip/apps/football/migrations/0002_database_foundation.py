from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("football", "0001_initial")]

    operations = [
        migrations.AlterModelOptions(name="league", options={"ordering": ["name"]}),
        migrations.AlterModelOptions(name="player", options={"ordering": ["display_name"]}),
        migrations.AlterModelOptions(name="season", options={"ordering": ["-start_date", "name"]}),
        migrations.AlterModelOptions(name="team", options={"ordering": ["name"]}),
        migrations.AddIndex(
            model_name="league",
            index=models.Index(fields=["name"], name="football_league_name_idx"),
        ),
        migrations.AddIndex(
            model_name="league",
            index=models.Index(fields=["country", "active"], name="football_league_ctry_act_idx"),
        ),
        migrations.AddIndex(
            model_name="season",
            index=models.Index(fields=["league", "is_current"], name="football_season_lg_cur_idx"),
        ),
        migrations.AddIndex(
            model_name="team",
            index=models.Index(fields=["name"], name="football_team_name_idx"),
        ),
        migrations.AddIndex(
            model_name="team",
            index=models.Index(fields=["country"], name="football_team_country_idx"),
        ),
        migrations.AddIndex(
            model_name="player",
            index=models.Index(fields=["display_name"], name="football_player_name_idx"),
        ),
        migrations.AddIndex(
            model_name="player",
            index=models.Index(fields=["last_name"], name="football_player_lname_idx"),
        ),
        migrations.AddIndex(
            model_name="teamplayer",
            index=models.Index(fields=["team", "active"], name="football_tp_team_active_idx"),
        ),
        migrations.AddIndex(
            model_name="standing",
            index=models.Index(fields=["league", "season", "position"], name="football_standing_tbl_idx"),
        ),
        migrations.AddConstraint(
            model_name="season",
            constraint=models.UniqueConstraint(fields=("league", "name"), name="unique_league_season_name"),
        ),
        migrations.AddConstraint(
            model_name="season",
            constraint=models.UniqueConstraint(
                fields=("league",),
                condition=models.Q(is_current=True),
                name="unique_current_season_per_league",
            ),
        ),
        migrations.AddConstraint(
            model_name="season",
            constraint=models.CheckConstraint(
                condition=models.Q(start_date__isnull=True)
                | models.Q(end_date__isnull=True)
                | models.Q(end_date__gte=models.F("start_date")),
                name="season_end_after_start",
            ),
        ),
        migrations.AddConstraint(
            model_name="standing",
            constraint=models.CheckConstraint(condition=models.Q(position__gte=1), name="standing_position_gte_1"),
        ),
    ]
