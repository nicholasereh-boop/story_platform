from django.db.models import Count, Q, Sum
from rest_framework.exceptions import NotFound, ValidationError

from apps.matches.models import Lineup, MatchEvent

from .models import League, Season

SCOPES = ("current", "all")


def _match_filter(prefix, scope):
    if scope["type"] == "season":
        return Q(**{f"{prefix}__season_id": scope["season"]["id"]})
    if scope["type"] == "current":
        return Q(**{f"{prefix}__season__is_current": True})
    return Q()


def resolve_scope(player, season_param, scope_param):
    """Which matches to count: one season, the current seasons (falling back to everything), or everything."""
    if season_param:
        if not str(season_param).isdigit():
            raise ValidationError({"season": "Must be a season id."})
        season = Season.objects.filter(pk=season_param).first()
        if season is None:
            raise NotFound("No such season.")
        return {"type": "season", "season": {"id": season.id, "name": season.name}}
    scope = scope_param or "current"
    if scope not in SCOPES:
        raise ValidationError({"scope": f"Must be one of: {', '.join(SCOPES)}."})
    if scope == "current":
        has_current = (
            Lineup.objects.filter(player=player, match__season__is_current=True).exists()
            or MatchEvent.objects.filter(Q(player=player) | Q(assist_player=player), match__season__is_current=True).exists()
        )
        if has_current:
            return {"type": "current", "season": None}
    return {"type": "all", "season": None}


def _zero():
    return {"matches": 0, "starts": 0, "minutes": None, "goals": 0, "assists": 0, "own_goals": 0, "yellow_cards": 0, "red_cards": 0}


def player_statistics(player, scope):
    rows = {}

    lineups = (
        Lineup.objects.filter(_match_filter("match", scope), player=player)
        .values("match__league_id")
        .annotate(matches=Count("id"), starts=Count("id", filter=Q(starter=True)), minutes=Sum("minutes_played"))
    )
    for row in lineups:
        entry = rows.setdefault(row["match__league_id"], _zero())
        entry.update(matches=row["matches"], starts=row["starts"], minutes=row["minutes"])

    events = (
        MatchEvent.objects.filter(_match_filter("match", scope))
        .filter(Q(player=player) | Q(assist_player=player))
        .values("match__league_id")
        .annotate(
            goals=Count("id", filter=Q(type="GOAL", player=player)),
            own_goals=Count("id", filter=Q(type="OWN_GOAL", player=player)),
            assists=Count("id", filter=Q(type="GOAL", assist_player=player)),
            yellow_cards=Count("id", filter=Q(type="YELLOW_CARD", player=player)),
            red_cards=Count("id", filter=Q(type="RED_CARD", player=player)),
        )
    )
    for row in events:
        entry = rows.setdefault(row["match__league_id"], _zero())
        for field in ("goals", "own_goals", "assists", "yellow_cards", "red_cards"):
            entry[field] = row[field]

    leagues = {l.id: l for l in League.objects.filter(id__in=[k for k in rows if k is not None])}
    competitions = []
    for league_id, entry in rows.items():
        league = leagues.get(league_id)
        competitions.append(
            {"league": {"id": league.id, "name": league.name, "logo": league.logo} if league else None, **entry}
        )
    competitions.sort(key=lambda c: (-c["matches"], -c["goals"], (c["league"] or {}).get("name", "")))

    totals = _zero()
    for entry in rows.values():
        for field in ("matches", "starts", "goals", "assists", "own_goals", "yellow_cards", "red_cards"):
            totals[field] += entry[field]
        if entry["minutes"] is not None:
            totals["minutes"] = (totals["minutes"] or 0) + entry["minutes"]
    return {"scope": scope, "totals": totals, "competitions": competitions}
