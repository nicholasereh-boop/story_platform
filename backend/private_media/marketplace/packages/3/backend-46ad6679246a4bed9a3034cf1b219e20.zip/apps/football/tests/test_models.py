from datetime import date

import pytest
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from apps.football.models import League, Player, Season, Standing, Team, TeamPlayer

pytestmark = pytest.mark.django_db


def make_league(pid=1, name="Premier League"):
    return League.objects.create(provider_id=pid, name=name)


def make_team(pid=1, name="Arsenal"):
    return Team.objects.create(provider_id=pid, name=name)


def test_provider_id_is_unique():
    make_league(pid=10)
    with pytest.raises(IntegrityError), transaction.atomic():
        make_league(pid=10, name="Other")


def test_season_name_unique_per_league():
    league = make_league()
    Season.objects.create(provider_id=1, league=league, name="2025/2026")
    with pytest.raises(IntegrityError), transaction.atomic():
        Season.objects.create(provider_id=2, league=league, name="2025/2026")


def test_only_one_current_season_per_league():
    league = make_league()
    Season.objects.create(provider_id=1, league=league, name="2024/2025", is_current=True)
    with pytest.raises(IntegrityError), transaction.atomic():
        Season.objects.create(provider_id=2, league=league, name="2025/2026", is_current=True)


def test_season_end_cannot_precede_start():
    league = make_league()
    with pytest.raises(IntegrityError), transaction.atomic():
        Season.objects.create(
            provider_id=1, league=league, name="Bad",
            start_date=date(2026, 5, 1), end_date=date(2025, 8, 1),
        )


def test_team_player_unique():
    team, player = make_team(), Player.objects.create(provider_id=1, display_name="Player One")
    TeamPlayer.objects.create(team=team, player=player)
    with pytest.raises(IntegrityError), transaction.atomic():
        TeamPlayer.objects.create(team=team, player=player)


def test_standing_unique_per_season_team_and_position_positive():
    league, team = make_league(), make_team()
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026")
    Standing.objects.create(season=season, league=league, team=team, position=1)
    with pytest.raises(IntegrityError), transaction.atomic():
        Standing.objects.create(season=season, league=league, team=team, position=2)
    other = make_team(pid=2, name="Chelsea")
    with pytest.raises(IntegrityError), transaction.atomic():
        Standing.objects.create(season=season, league=league, team=other, position=0)


def test_standing_league_must_match_season_league():
    league, other_league, team = make_league(), make_league(pid=2, name="La Liga"), make_team()
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026")
    standing = Standing(season=season, league=other_league, team=team, position=1)
    with pytest.raises(ValidationError):
        standing.clean()


def test_deleting_league_cascades_to_seasons():
    league = make_league()
    Season.objects.create(provider_id=1, league=league, name="2025/2026")
    league.delete()
    assert Season.objects.count() == 0
