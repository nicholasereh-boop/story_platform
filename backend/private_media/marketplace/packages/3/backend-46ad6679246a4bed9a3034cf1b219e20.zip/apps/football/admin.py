from django.contrib import admin
from .models import League, Season, Team, Player, TeamPlayer, Standing


@admin.register(League)
class LeagueAdmin(admin.ModelAdmin):
    list_display = ("name", "country", "provider_id", "active")
    list_filter = ("active", "country")
    search_fields = ("name", "short_name", "country")


@admin.register(Season)
class SeasonAdmin(admin.ModelAdmin):
    list_display = ("league", "name", "start_date", "end_date", "is_current")
    list_filter = ("is_current", "league")
    search_fields = ("name", "league__name")
    autocomplete_fields = ("league",)


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ("name", "country", "stadium", "provider_id", "active")
    list_filter = ("active", "country")
    search_fields = ("name", "short_name", "code")


@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ("display_name", "position", "nationality", "provider_id")
    list_filter = ("position", "nationality")
    search_fields = ("display_name", "first_name", "last_name")


@admin.register(TeamPlayer)
class TeamPlayerAdmin(admin.ModelAdmin):
    list_display = ("team", "player", "shirt_number", "position", "active")
    list_filter = ("active",)
    search_fields = ("team__name", "player__display_name")
    autocomplete_fields = ("team", "player")


@admin.register(Standing)
class StandingAdmin(admin.ModelAdmin):
    list_display = ("season", "position", "team", "played", "points")
    list_filter = ("league", "season")
    search_fields = ("team__name",)
    autocomplete_fields = ("season", "league", "team")
