from django.utils import timezone
from rest_framework import serializers

from .models import League, Player, Season, Standing, Team, TeamPlayer


class LeagueMiniSerializer(serializers.ModelSerializer):
    class Meta:
        model = League
        fields = ("id", "name", "short_name", "country", "logo")


class TeamMiniSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = ("id", "name", "short_name", "logo")


class PlayerMiniSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source="display_name", read_only=True)

    class Meta:
        model = Player
        fields = ("id", "name", "image")


class LeagueSerializer(serializers.ModelSerializer):
    class Meta:
        model = League
        fields = ("id", "name", "short_name", "country", "logo", "active")


class SeasonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Season
        fields = ("id", "league", "name", "start_date", "end_date", "is_current")


class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = ("id", "name", "short_name", "code", "country", "logo", "stadium", "founded", "active")


class TeamPositionSerializer(serializers.ModelSerializer):
    league = LeagueMiniSerializer(read_only=True)
    season_name = serializers.CharField(source="season.name", read_only=True)

    class Meta:
        model = Standing
        fields = ("league", "season", "season_name", "position", "played", "points", "form")


class TeamDetailSerializer(TeamSerializer):
    """Needs the queryset prefetched with `current_standings` (see TeamViewSet)."""

    positions = TeamPositionSerializer(many=True, source="current_standings", read_only=True)

    class Meta(TeamSerializer.Meta):
        fields = (*TeamSerializer.Meta.fields, "positions")


def _membership(player):
    memberships = getattr(player, "active_memberships", None)
    if memberships is None:
        return player.team_memberships.filter(active=True).select_related("team").first()
    return memberships[0] if memberships else None


class PlayerSerializer(serializers.ModelSerializer):
    current_team = serializers.SerializerMethodField()
    shirt_number = serializers.SerializerMethodField()
    age = serializers.SerializerMethodField()

    class Meta:
        model = Player
        fields = (
            "id", "first_name", "last_name", "display_name", "date_of_birth", "age",
            "nationality", "position", "image", "current_team", "shirt_number",
        )

    def get_current_team(self, player):
        membership = _membership(player)
        return TeamMiniSerializer(membership.team).data if membership else None

    def get_shirt_number(self, player):
        membership = _membership(player)
        return membership.shirt_number if membership else None

    def get_age(self, player):
        born = player.date_of_birth
        if not born:
            return None
        today = timezone.localdate()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))


class SquadMemberSerializer(serializers.ModelSerializer):
    player = PlayerMiniSerializer(read_only=True)

    class Meta:
        model = TeamPlayer
        fields = ("player", "shirt_number", "position")


class StandingSerializer(serializers.ModelSerializer):
    team = TeamMiniSerializer(read_only=True)

    class Meta:
        model = Standing
        fields = (
            "id", "season", "league", "team", "position", "played", "won", "drawn", "lost",
            "goals_for", "goals_against", "goal_difference", "points", "form",
        )
