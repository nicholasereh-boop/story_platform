from datetime import date, timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Player, Season, Team, TeamPlayer
from apps.matches.models import Lineup, Match, MatchEvent

pytestmark = pytest.mark.django_db
API = "/api/v1/players/"
_ids = iter(range(9000, 99000))


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def world():
    pl = League.objects.create(provider_id=8, name="Premier League")
    cup = League.objects.create(provider_id=9, name="FA Cup")
    return {
        "pl": pl,
        "cup": cup,
        "current": Season.objects.create(provider_id=1, league=pl, name="2025/2026", is_current=True),
        "old": Season.objects.create(provider_id=2, league=pl, name="2024/2025"),
        "cup_season": Season.objects.create(provider_id=3, league=cup, name="2025/2026", is_current=True),
        "arsenal": Team.objects.create(provider_id=1, name="Arsenal"),
        "chelsea": Team.objects.create(provider_id=2, name="Chelsea"),
        "saka": Player.objects.create(provider_id=1, display_name="Saka", date_of_birth=date(2001, 9, 5)),
        "odegaard": Player.objects.create(provider_id=2, display_name="Odegaard"),
    }


def game(world, league="pl", season="current"):
    return Match.objects.create(
        provider_id=next(_ids), league=world[league], season=world[season], home_team=world["arsenal"],
        away_team=world["chelsea"], status="FT", scheduled_at=timezone.now() - timedelta(days=1),
    )


def event(m, type, player, assist=None, team="arsenal", world=None):
    return MatchEvent.objects.create(match=m, provider_id=next(_ids), type=type, minute=10, player=player, assist_player=assist)


def lineup(world, m, player, starter=True, minutes=None):
    return Lineup.objects.create(match=m, team=world["arsenal"], player=player, starter=starter, minutes_played=minutes)


def test_detail_has_age_shirt_number_and_current_team(client, world):
    TeamPlayer.objects.create(team=world["arsenal"], player=world["saka"], shirt_number=7)
    data = client.get(f"{API}{world['saka'].id}/").data
    today = timezone.localdate()
    assert data["age"] == today.year - 2001 - ((today.month, today.day) < (9, 5))
    assert data["shirt_number"] == 7 and data["current_team"]["name"] == "Arsenal"
    assert client.get(f"{API}{world['odegaard'].id}/").data["age"] is None


def test_statistics_count_goals_assists_cards_and_starts(client, world):
    saka, odegaard = world["saka"], world["odegaard"]
    m1, m2 = game(world), game(world)
    lineup(world, m1, saka)
    lineup(world, m2, saka, starter=False)
    event(m1, "GOAL", saka, odegaard)
    event(m1, "GOAL", saka)
    event(m1, "GOAL", odegaard, saka)
    event(m1, "YELLOW_CARD", saka)
    event(m2, "RED_CARD", saka)
    event(m2, "OWN_GOAL", saka)
    event(m2, "YELLOW_CARD", odegaard)

    totals = client.get(f"{API}{saka.id}/statistics/").data["totals"]
    assert (totals["matches"], totals["starts"]) == (2, 1)
    assert (totals["goals"], totals["assists"], totals["own_goals"]) == (2, 1, 1)
    assert (totals["yellow_cards"], totals["red_cards"]) == (1, 1)


def test_minutes_are_null_until_lineups_carry_them(client, world):
    saka = world["saka"]
    lineup(world, game(world), saka)
    assert client.get(f"{API}{saka.id}/statistics/").data["totals"]["minutes"] is None
    lineup(world, game(world), saka, minutes=90)
    lineup(world, game(world), saka, starter=False, minutes=15)
    assert client.get(f"{API}{saka.id}/statistics/").data["totals"]["minutes"] == 105


def test_competitions_break_the_totals_down_by_league(client, world):
    saka = world["saka"]
    league_game, other_league_game = game(world), game(world)
    cup_game = game(world, league="cup", season="cup_season")
    for m in (league_game, other_league_game, cup_game):
        lineup(world, m, saka)
    event(league_game, "GOAL", saka)
    event(cup_game, "GOAL", saka)
    event(cup_game, "GOAL", saka)

    data = client.get(f"{API}{saka.id}/statistics/").data
    by_name = {c["league"]["name"]: c for c in data["competitions"]}
    assert (by_name["Premier League"]["matches"], by_name["Premier League"]["goals"]) == (2, 1)
    assert (by_name["FA Cup"]["matches"], by_name["FA Cup"]["goals"]) == (1, 2)
    assert [c["league"]["name"] for c in data["competitions"]] == ["Premier League", "FA Cup"]
    assert data["totals"]["matches"] == 3 and data["totals"]["goals"] == 3


def test_scope_defaults_to_current_seasons_and_can_widen_or_narrow(client, world):
    saka = world["saka"]
    now_game, old_game = game(world), game(world, season="old")
    lineup(world, now_game, saka)
    lineup(world, old_game, saka)
    event(old_game, "GOAL", saka)

    default = client.get(f"{API}{saka.id}/statistics/").data
    assert default["scope"] == {"type": "current", "season": None}
    assert default["totals"]["matches"] == 1 and default["totals"]["goals"] == 0
    assert client.get(f"{API}{saka.id}/statistics/", {"scope": "all"}).data["totals"]["matches"] == 2
    narrow = client.get(f"{API}{saka.id}/statistics/", {"season": world["old"].id}).data
    assert narrow["scope"]["season"]["name"] == "2024/2025" and narrow["totals"]["goals"] == 1


def test_scope_falls_back_to_all_when_nothing_is_in_a_current_season(client, world):
    saka = world["saka"]
    old_game = game(world, season="old")
    lineup(world, old_game, saka)
    data = client.get(f"{API}{saka.id}/statistics/").data
    assert data["scope"]["type"] == "all" and data["totals"]["matches"] == 1


def test_a_player_with_no_data_gets_zeroes(client, world):
    data = client.get(f"{API}{world['odegaard'].id}/statistics/").data
    assert data["competitions"] == []
    assert data["totals"] == {"matches": 0, "starts": 0, "minutes": None, "goals": 0, "assists": 0,
                              "own_goals": 0, "yellow_cards": 0, "red_cards": 0}


def test_other_players_events_are_not_counted(client, world):
    m = game(world)
    event(m, "GOAL", world["odegaard"])
    event(m, "YELLOW_CARD", world["odegaard"])
    assert client.get(f"{API}{world['saka'].id}/statistics/").data["totals"]["goals"] == 0


def test_parameter_validation(client, world):
    saka = world["saka"]
    assert client.get(f"{API}{saka.id}/statistics/", {"scope": "forever"}).status_code == 400
    assert client.get(f"{API}{saka.id}/statistics/", {"season": "abc"}).status_code == 400
    assert client.get(f"{API}{saka.id}/statistics/", {"season": 99999}).status_code == 404
    assert client.get(f"{API}99999/statistics/").status_code == 404


def test_statistics_query_count_is_fixed(client, world, django_assert_max_num_queries):
    saka = world["saka"]
    for _ in range(8):
        m = game(world)
        lineup(world, m, saka)
        event(m, "GOAL", saka)
    with django_assert_max_num_queries(9):
        assert client.get(f"{API}{saka.id}/statistics/").status_code == 200
