import django_filters as filters

from .models import League, Player, Season, Standing, Team


class LeagueFilter(filters.FilterSet):
    country = filters.CharFilter(field_name="country", lookup_expr="iexact")

    class Meta:
        model = League
        fields = ["country", "active"]


class SeasonFilter(filters.FilterSet):
    class Meta:
        model = Season
        fields = ["league", "is_current"]


class TeamFilter(filters.FilterSet):
    country = filters.CharFilter(field_name="country", lookup_expr="iexact")
    league = filters.NumberFilter(method="filter_league")

    class Meta:
        model = Team
        fields = ["country", "active", "league"]

    def filter_league(self, queryset, name, value):
        return queryset.filter(standings__league_id=value).distinct()


class PlayerFilter(filters.FilterSet):
    nationality = filters.CharFilter(field_name="nationality", lookup_expr="iexact")
    position = filters.CharFilter(field_name="position", lookup_expr="iexact")
    team = filters.NumberFilter(method="filter_team")

    class Meta:
        model = Player
        fields = ["nationality", "position", "team"]

    def filter_team(self, queryset, name, value):
        return queryset.filter(team_memberships__team_id=value, team_memberships__active=True).distinct()


class StandingFilter(filters.FilterSet):
    class Meta:
        model = Standing
        fields = ["league", "season", "team"]
