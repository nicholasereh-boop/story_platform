from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Player, Season, Standing, Team
from apps.matches.models import Match, MatchEvent

pytestmark = pytest.mark.django_db
API = "/api/v1/leagues/"
_ids = iter(range(5000, 90000))


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def league():
    return League.objects.create(provider_id=8, name="Premier League", country="England")


@pytest.fixture
def season(league):
    return Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)


@pytest.fixture
def teams():
    return {n: Team.objects.create(provider_id=i, name=n) for i, n in enumerate(["Arsenal", "Chelsea", "Spurs"], 1)}


def match(league, season, home, away, hs=0, as_=0, status="FT"):
    return Match.objects.create(
        provider_id=next(_ids), league=league, season=season, home_team=home, away_team=away,
        status=status, home_score=hs, away_score=as_, scheduled_at=timezone.now() - timedelta(days=1),
    )


def goal(m, team, player, assist=None, type="GOAL"):
    return MatchEvent.objects.create(
        match=m, provider_id=next(_ids), type=type, minute=10, team=team, player=player, assist_player=assist
    )


def test_teams_come_from_the_standings_and_the_matches_of_the_season(client, league, season, teams):
    Standing.objects.create(season=season, league=league, team=teams["Arsenal"], position=1)
    match(league, season, teams["Chelsea"], teams["Spurs"], status="SCHEDULED")
    other = Season.objects.create(provider_id=2, league=league, name="2024/2025")
    extra = Team.objects.create(provider_id=99, name="Old Team")
    match(league, other, extra, teams["Spurs"])

    data = client.get(f"{API}{league.id}/teams/").data
    assert data["season"]["name"] == "2025/2026"
    assert [t["name"] for t in data["teams"]] == ["Arsenal", "Chelsea", "Spurs"]
    old = client.get(f"{API}{league.id}/teams/", {"season": other.id}).data
    assert {t["name"] for t in old["teams"]} == {"Old Team", "Spurs"}


def test_season_errors_are_consistent_across_the_season_endpoints(client, league, teams):
    for name in ("standings", "teams", "statistics"):
        assert client.get(f"{API}{league.id}/{name}/").status_code == 404
    season = Season.objects.create(provider_id=1, league=league, name="2025/2026", is_current=True)
    foreign = Season.objects.create(provider_id=2, league=League.objects.create(provider_id=9, name="La Liga"), name="x")
    for name in ("standings", "teams", "statistics"):
        assert client.get(f"{API}{league.id}/{name}/", {"season": "abc"}).status_code == 400
        assert client.get(f"{API}{league.id}/{name}/", {"season": foreign.id}).status_code == 404
        assert client.get(f"{API}{league.id}/{name}/", {"season": season.id}).status_code == 200


def test_statistics_summarise_finished_matches_only(client, league, season, teams):
    a, c, s = teams["Arsenal"], teams["Chelsea"], teams["Spurs"]
    match(league, season, a, c, 2, 0)
    match(league, season, c, s, 1, 1)
    match(league, season, s, a, 0, 3)
    match(league, season, a, s, 5, 5, status="LIVE")

    summary = client.get(f"{API}{league.id}/statistics/").data["summary"]
    assert summary["played"] == 3 and summary["goals"] == 7
    assert summary["goals_per_match"] == 2.33
    assert (summary["home_wins"], summary["draws"], summary["away_wins"]) == (1, 1, 1)


def test_statistics_for_a_season_without_matches_are_zeroes(client, league, season):
    data = client.get(f"{API}{league.id}/statistics/").data
    assert data["summary"]["played"] == 0 and data["summary"]["goals_per_match"] == 0
    assert data["top_scorers"] == [] and data["coverage"] == {"finished_matches": 0, "with_events": 0}


def test_top_scorers_and_assisters(client, league, season, teams):
    a, c = teams["Arsenal"], teams["Chelsea"]
    saka = Player.objects.create(provider_id=1, display_name="Saka")
    odegaard = Player.objects.create(provider_id=2, display_name="Odegaard")
    palmer = Player.objects.create(provider_id=3, display_name="Palmer")
    m1, m2 = match(league, season, a, c, 3, 1), match(league, season, c, a, 1, 1)
    goal(m1, a, saka, odegaard)
    goal(m1, a, saka, odegaard)
    goal(m1, a, odegaard, saka)
    goal(m1, c, palmer)
    goal(m2, a, saka)
    goal(m2, c, saka, type="OWN_GOAL")

    data = client.get(f"{API}{league.id}/statistics/").data
    assert [(r["player"]["name"], r["total"]) for r in data["top_scorers"]] == [("Saka", 3), ("Odegaard", 1), ("Palmer", 1)]
    assert data["top_scorers"][0]["team"]["name"] == "Arsenal"
    assert [(r["player"]["name"], r["total"]) for r in data["top_assists"]] == [("Odegaard", 2), ("Saka", 1)]


def test_leaders_are_limited_and_the_limit_validated(client, league, season, teams):
    a, c = teams["Arsenal"], teams["Chelsea"]
    m = match(league, season, a, c, 3, 0)
    for i in range(3):
        goal(m, a, Player.objects.create(provider_id=10 + i, display_name=f"P{i}"))
    assert len(client.get(f"{API}{league.id}/statistics/", {"limit": 2}).data["top_scorers"]) == 2
    for bad in ("0", "26", "x"):
        assert client.get(f"{API}{league.id}/statistics/", {"limit": bad}).status_code == 400


def test_coverage_counts_finished_matches_that_have_events(client, league, season, teams):
    a, c = teams["Arsenal"], teams["Chelsea"]
    with_events = match(league, season, a, c, 1, 0)
    match(league, season, c, a, 0, 0)
    goal(with_events, a, Player.objects.create(provider_id=1, display_name="Saka"))
    assert client.get(f"{API}{league.id}/statistics/").data["coverage"] == {"finished_matches": 2, "with_events": 1}


def test_statistics_do_not_mix_seasons_or_leagues(client, league, season, teams):
    a, c = teams["Arsenal"], teams["Chelsea"]
    other_league = League.objects.create(provider_id=9, name="La Liga")
    other_season = Season.objects.create(provider_id=5, league=other_league, name="2025/2026", is_current=True)
    match(other_league, other_season, a, c, 9, 9)
    assert client.get(f"{API}{league.id}/statistics/").data["summary"]["played"] == 0


def test_statistics_query_count_does_not_grow_with_the_data(client, league, season, teams, django_assert_max_num_queries):
    a, c = teams["Arsenal"], teams["Chelsea"]
    saka = Player.objects.create(provider_id=1, display_name="Saka")
    for _ in range(10):
        goal(match(league, season, a, c, 1, 0), a, saka)
    with django_assert_max_num_queries(12):
        assert client.get(f"{API}{league.id}/statistics/").status_code == 200
