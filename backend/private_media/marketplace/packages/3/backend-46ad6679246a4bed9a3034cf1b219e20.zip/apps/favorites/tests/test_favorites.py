from datetime import timedelta

import pytest
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework.test import APIClient

from apps.favorites import views
from apps.favorites.models import Favorite
from apps.football.models import League, Team
from apps.matches.models import Match

User = get_user_model()
pytestmark = pytest.mark.django_db
BASE = "/api/v1/my/favorites/"
_ids = iter(range(1, 10000))


@pytest.fixture
def user():
    return User.objects.create_user("ada", "ada@example.com", "Sup3r-secret-pass")


@pytest.fixture
def client(user):
    api = APIClient()
    api.force_authenticate(user)
    return api


@pytest.fixture
def team():
    return Team.objects.create(provider_id=next(_ids), name="Arsenal")


@pytest.fixture
def league():
    return League.objects.create(provider_id=next(_ids), name="Premier League", country="England")


@pytest.fixture
def match(team, league):
    rival = Team.objects.create(provider_id=next(_ids), name="Chelsea")
    return Match.objects.create(
        provider_id=next(_ids), league=league, home_team=team, away_team=rival, scheduled_at=timezone.now() + timedelta(days=1)
    )


@pytest.mark.parametrize("url", [BASE, BASE + "ids/", BASE + "teams/1/"])
def test_everything_requires_authentication(url):
    anonymous = APIClient()
    assert anonymous.get(url).status_code == 401
    assert anonymous.put(BASE + "teams/1/").status_code == 401
    assert anonymous.delete(BASE + "teams/1/").status_code == 401


def test_follow_and_unfollow_each_kind(client, team, league, match):
    for kind, obj in (("teams", team), ("leagues", league), ("matches", match)):
        assert client.put(f"{BASE}{kind}/{obj.id}/").status_code == 201
    assert Favorite.objects.count() == 3
    for kind, obj in (("teams", team), ("leagues", league), ("matches", match)):
        assert client.delete(f"{BASE}{kind}/{obj.id}/").status_code == 204
    assert Favorite.objects.count() == 0


def test_follow_and_unfollow_are_idempotent(client, team):
    assert client.put(f"{BASE}teams/{team.id}/").status_code == 201
    response = client.put(f"{BASE}teams/{team.id}/")
    assert response.status_code == 200 and response.json() == {"favorite": True}
    assert Favorite.objects.count() == 1
    assert client.delete(f"{BASE}teams/{team.id}/").status_code == 204
    assert client.delete(f"{BASE}teams/{team.id}/").status_code == 204


def test_unknown_kind_or_target_is_404(client):
    assert client.put(f"{BASE}cats/1/").status_code == 404
    assert client.delete(f"{BASE}cats/1/").status_code == 404
    assert client.put(f"{BASE}teams/99999/").status_code == 404
    assert client.put(f"{BASE}players/1/").status_code == 404


def test_list_returns_each_kind_newest_first(client, team, league, match):
    other = Team.objects.create(provider_id=next(_ids), name="Spurs")
    client.put(f"{BASE}teams/{team.id}/")
    client.put(f"{BASE}teams/{other.id}/")
    client.put(f"{BASE}leagues/{league.id}/")
    client.put(f"{BASE}matches/{match.id}/")
    data = client.get(BASE).json()
    assert [t["name"] for t in data["teams"]] == ["Spurs", "Arsenal"]
    assert [l["name"] for l in data["leagues"]] == ["Premier League"]
    (row,) = data["matches"]
    assert row["id"] == match.id and row["home_team"]["name"] == "Arsenal" and row["league"]["name"] == "Premier League"


def test_ids_endpoint(client, team, league, match):
    assert client.get(BASE + "ids/").json() == {"teams": [], "leagues": [], "matches": []}
    client.put(f"{BASE}teams/{team.id}/")
    client.put(f"{BASE}matches/{match.id}/")
    assert client.get(BASE + "ids/").json() == {"teams": [team.id], "leagues": [], "matches": [match.id]}


def test_favorites_are_private_to_each_user(client, team):
    stranger = User.objects.create_user("bob", "bob@example.com", "Sup3r-secret-pass")
    Favorite.objects.create(user=stranger, team=team)
    assert client.get(BASE + "ids/").json()["teams"] == []
    assert client.get(BASE).json()["teams"] == []
    client.delete(f"{BASE}teams/{team.id}/")
    assert Favorite.objects.filter(user=stranger).count() == 1


def test_a_cap_stops_runaway_following(client, user, monkeypatch):
    monkeypatch.setattr(views, "MAX_FAVORITES", 2)
    teams = [Team.objects.create(provider_id=next(_ids), name=f"T{i}") for i in range(3)]
    assert client.put(f"{BASE}teams/{teams[0].id}/").status_code == 201
    assert client.put(f"{BASE}teams/{teams[1].id}/").status_code == 201
    assert client.put(f"{BASE}teams/{teams[2].id}/").status_code == 400
    assert client.put(f"{BASE}teams/{teams[0].id}/").status_code == 200  # already followed: still fine


def test_database_refuses_bad_rows(user, team, league):
    with pytest.raises(IntegrityError), transaction.atomic():
        Favorite.objects.create(user=user)
    with pytest.raises(IntegrityError), transaction.atomic():
        Favorite.objects.create(user=user, team=team, league=league)
    Favorite.objects.create(user=user, team=team)
    with pytest.raises(IntegrityError), transaction.atomic():
        Favorite.objects.create(user=user, team=team)


def test_deleting_a_team_removes_its_favorites(client, team):
    client.put(f"{BASE}teams/{team.id}/")
    team.delete()
    assert Favorite.objects.count() == 0


def test_list_query_count_is_constant(client, django_assert_max_num_queries, league):
    for index in range(6):
        home = Team.objects.create(provider_id=next(_ids), name=f"H{index}")
        away = Team.objects.create(provider_id=next(_ids), name=f"A{index}")
        fixture = Match.objects.create(
            provider_id=next(_ids), league=league, home_team=home, away_team=away, scheduled_at=timezone.now()
        )
        client.put(f"{BASE}matches/{fixture.id}/")
        client.put(f"{BASE}teams/{home.id}/")
    with django_assert_max_num_queries(5):
        assert client.get(BASE).status_code == 200
