import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("football", "0003_search_indexes"),
        ("matches", "0002_database_foundation"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Favorite",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "league",
                    models.ForeignKey(
                        blank=True, null=True, on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorited_by", to="football.league",
                    ),
                ),
                (
                    "match",
                    models.ForeignKey(
                        blank=True, null=True, on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorited_by", to="matches.match",
                    ),
                ),
                (
                    "team",
                    models.ForeignKey(
                        blank=True, null=True, on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorited_by", to="football.team",
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="favorites", to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={"ordering": ["-created_at", "-id"]},
        ),
        migrations.AddIndex(
            model_name="favorite",
            index=models.Index(fields=["user", "-created_at"], name="favorite_user_recent_idx"),
        ),
        migrations.AddConstraint(
            model_name="favorite",
            constraint=models.CheckConstraint(
                # Written exactly like the model's Q objects so the migration state compares equal to the model.
                condition=(
                    models.Q(team__isnull=False, league__isnull=True, match__isnull=True)
                    | models.Q(team__isnull=True, league__isnull=False, match__isnull=True)
                    | models.Q(team__isnull=True, league__isnull=True, match__isnull=False)
                ),
                name="favorite_exactly_one_target",
            ),
        ),
        migrations.AddConstraint(
            model_name="favorite",
            constraint=models.UniqueConstraint(fields=("user", "team"), name="favorite_unique_team"),
        ),
        migrations.AddConstraint(
            model_name="favorite",
            constraint=models.UniqueConstraint(fields=("user", "league"), name="favorite_unique_league"),
        ),
        migrations.AddConstraint(
            model_name="favorite",
            constraint=models.UniqueConstraint(fields=("user", "match"), name="favorite_unique_match"),
        ),
    ]
