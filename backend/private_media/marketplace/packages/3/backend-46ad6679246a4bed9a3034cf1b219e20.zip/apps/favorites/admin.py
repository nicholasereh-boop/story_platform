from django.contrib import admin

from .models import Favorite


@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ("user", "team", "league", "match", "created_at")
    raw_id_fields = ("user", "team", "league", "match")
    search_fields = ("user__username", "team__name", "league__name")
