from django.http import Http404
from django.shortcuts import get_object_or_404
from drf_spectacular.utils import extend_schema
from rest_framework import permissions, status
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.football.models import League, Team
from apps.football.serializers import LeagueMiniSerializer, TeamMiniSerializer
from apps.matches.models import Match
from apps.matches.serializers import MatchListSerializer

from .models import Favorite

MAX_FAVORITES = 500
LIST_LIMIT = 100
# URL segment -> (Favorite field, target model)
KINDS = {"teams": ("team", Team), "leagues": ("league", League), "matches": ("match", Match)}


class FavoriteListView(APIView):
    """GET /my/favorites/ - everything the user follows, newest first (up to 100 of each kind)."""

    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(responses={200: dict})
    def get(self, request):
        mine = Favorite.objects.filter(user=request.user)

        def recent(field, *related):
            return mine.filter(**{f"{field}__isnull": False}).select_related(*related)[:LIST_LIMIT]

        context = {"request": request}
        return Response(
            {
                "teams": TeamMiniSerializer([f.team for f in recent("team", "team")], many=True, context=context).data,
                "leagues": LeagueMiniSerializer(
                    [f.league for f in recent("league", "league")], many=True, context=context
                ).data,
                "matches": MatchListSerializer(
                    [f.match for f in recent("match", "match__league", "match__home_team", "match__away_team")],
                    many=True,
                    context=context,
                ).data,
            }
        )


class FavoriteIdsView(APIView):
    """GET /my/favorites/ids/ - just the ids, for drawing star buttons."""

    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(responses={200: dict})
    def get(self, request):
        result = {kind: [] for kind in KINDS}
        rows = Favorite.objects.filter(user=request.user).values_list("team_id", "league_id", "match_id")
        for team_id, league_id, match_id in rows:
            if team_id:
                result["teams"].append(team_id)
            elif league_id:
                result["leagues"].append(league_id)
            else:
                result["matches"].append(match_id)
        return Response(result)


class FavoriteDetailView(APIView):
    """PUT /my/favorites/<teams|leagues|matches>/<id>/ follows; DELETE unfollows. Both are idempotent."""

    permission_classes = [permissions.IsAuthenticated]

    def _kind(self, kind):
        if kind not in KINDS:
            raise Http404
        return KINDS[kind]

    @extend_schema(request=None, responses={200: dict, 201: dict})
    def put(self, request, kind, pk):
        field, model = self._kind(kind)
        target = get_object_or_404(model, pk=pk)
        favorites = Favorite.objects.filter(user=request.user)
        if not favorites.filter(**{field: target}).exists() and favorites.count() >= MAX_FAVORITES:
            raise ValidationError({"detail": f"You can follow up to {MAX_FAVORITES} items."})
        _, created = Favorite.objects.get_or_create(user=request.user, **{field: target})
        return Response({"favorite": True}, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)

    @extend_schema(responses={204: None})
    def delete(self, request, kind, pk):
        field, _ = self._kind(kind)
        Favorite.objects.filter(user=request.user, **{f"{field}_id": pk}).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
