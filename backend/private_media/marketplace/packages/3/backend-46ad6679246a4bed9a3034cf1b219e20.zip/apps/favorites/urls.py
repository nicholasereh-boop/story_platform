from django.urls import path

from .views import FavoriteDetailView, FavoriteIdsView, FavoriteListView

urlpatterns = [
    path("", FavoriteListView.as_view(), name="favorites"),
    path("ids/", FavoriteIdsView.as_view(), name="favorite-ids"),
    path("<str:kind>/<int:pk>/", FavoriteDetailView.as_view(), name="favorite-detail"),
]
