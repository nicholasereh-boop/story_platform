from django.conf import settings
from django.db import models
from django.db.models import Q


class Favorite(models.Model):
    """One followed team, league or match. Exactly one of the three targets is set."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="favorites")
    team = models.ForeignKey("football.Team", null=True, blank=True, on_delete=models.CASCADE, related_name="favorited_by")
    league = models.ForeignKey("football.League", null=True, blank=True, on_delete=models.CASCADE, related_name="favorited_by")
    match = models.ForeignKey("matches.Match", null=True, blank=True, on_delete=models.CASCADE, related_name="favorited_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=(
                    Q(team__isnull=False, league__isnull=True, match__isnull=True)
                    | Q(team__isnull=True, league__isnull=False, match__isnull=True)
                    | Q(team__isnull=True, league__isnull=True, match__isnull=False)
                ),
                name="favorite_exactly_one_target",
            ),
            # NULLs never collide in PostgreSQL, so each constraint only bites for its own kind.
            models.UniqueConstraint(fields=["user", "team"], name="favorite_unique_team"),
            models.UniqueConstraint(fields=["user", "league"], name="favorite_unique_league"),
            models.UniqueConstraint(fields=["user", "match"], name="favorite_unique_match"),
        ]
        indexes = [models.Index(fields=["user", "-created_at"], name="favorite_user_recent_idx")]

    def __str__(self):
        return f"Favorite<user={self.user_id} team={self.team_id} league={self.league_id} match={self.match_id}>"
