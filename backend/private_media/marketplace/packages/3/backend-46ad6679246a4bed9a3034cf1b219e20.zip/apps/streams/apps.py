from django.apps import AppConfig


class StreamsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.streams"
    label = "streams"

    def ready(self):
        from . import signals

        signals.connect()
