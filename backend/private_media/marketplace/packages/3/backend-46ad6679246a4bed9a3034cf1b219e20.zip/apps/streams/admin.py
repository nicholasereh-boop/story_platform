from django.contrib import admin
from django.utils import timezone

from .models import MatchStream


@admin.register(MatchStream)
class MatchStreamAdmin(admin.ModelAdmin):
    list_display = ("title", "match", "kind", "is_active", "starts_at", "ends_at", "shown_now", "priority")
    list_filter = ("kind", "is_active", "match__status")
    search_fields = ("title", "match__home_team__name", "match__away_team__name", "source_credit")
    raw_id_fields = ("match",)
    list_select_related = ("match", "match__home_team", "match__away_team")
    readonly_fields = ("created_at", "updated_at")
    list_editable = ("is_active", "priority")
    actions = ["deactivate"]
    fieldsets = (
        (None, {"fields": ("match", "kind", "title", "url", "language", "source_credit")}),
        ("When it is shown", {"fields": ("is_active", "starts_at", "ends_at", "priority")}),
        ("Record", {"fields": ("created_at", "updated_at")}),
    )

    @admin.display(boolean=True, description="Showing now")
    def shown_now(self, obj):
        from integrations.sportmonks.constants import LIVE_STATUSES

        return obj.is_active and obj.match.status in LIVE_STATUSES and obj.in_window(timezone.now()) and obj.is_valid_source()

    @admin.action(description="Hide selected streams")
    def deactivate(self, request, queryset):
        for stream in queryset:  # save() so the API cache is retired for each
            stream.is_active = False
            stream.save(update_fields=["is_active", "updated_at"])
