"""Rules for stream links. Pure Python (no Django imports) so it is easy to test and to reason about.

Two kinds of source are supported, and both must be https:

* hls    a .m3u8 playlist from a provider you are licensed to use, played by hls.js
* embed  an official player page (YouTube and similar) shown in a sandboxed iframe, on a host allowlist
"""
import re
from urllib.parse import parse_qs, urlparse

HLS = "hls"
EMBED = "embed"

YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com"}
YOUTUBE_EMBED_BASE = "https://www.youtube-nocookie.com/embed/"
VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
CHANNEL_ID = re.compile(r"^UC[A-Za-z0-9_-]{22}$")


class InvalidStream(ValueError):
    """The link cannot be used; the message is written for the admin who typed it."""


def parse_hosts(value):
    return {item.strip().lower() for item in (value or "").split(",") if item.strip()}


def _parse_https(url):
    url = (url or "").strip()
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise InvalidStream("The link must start with https://")
    if not parsed.hostname:
        raise InvalidStream("The link has no host name.")
    if parsed.username or parsed.password:
        raise InvalidStream("The link must not contain a user name or password.")
    return parsed


def host_of(url):
    try:
        return (urlparse(url).hostname or "").lower()
    except ValueError:
        return ""


def _youtube_target(parsed):
    """The video id (or live channel) a YouTube link points at, or None."""
    host = parsed.hostname.lower()
    parts = [part for part in parsed.path.split("/") if part]
    query = parse_qs(parsed.query)
    if host == "youtu.be":
        return ("video", parts[0]) if parts else None
    if parts[:1] == ["watch"]:
        return ("video", (query.get("v") or [""])[0])
    if parts[:1] in (["live"], ["embed"], ["v"]) and len(parts) >= 2:
        if parts[1] == "live_stream":
            return ("channel", (query.get("channel") or [""])[0])
        return ("video", parts[1])
    if parts[:2] == ["embed", "live_stream"]:
        return ("channel", (query.get("channel") or [""])[0])
    return None


def normalize_embed_url(url):
    """YouTube watch / share / live links become the privacy-friendly embed address. Other links pass through."""
    parsed = _parse_https(url)
    if parsed.hostname.lower() in YOUTUBE_HOSTS:
        target = _youtube_target(parsed)
        if target is None:
            raise InvalidStream("Could not find a YouTube video in this link. Use the video's watch, share or embed link.")
        kind, value = target
        if kind == "video" and VIDEO_ID.match(value):
            return f"{YOUTUBE_EMBED_BASE}{value}"
        if kind == "channel" and CHANNEL_ID.match(value):
            return f"{YOUTUBE_EMBED_BASE}live_stream?channel={value}"
        raise InvalidStream("That does not look like a valid YouTube video or channel id.")
    return parsed._replace(fragment="").geturl()


def validate_hls_url(url):
    parsed = _parse_https(url)
    if not parsed.path.lower().endswith(".m3u8"):
        raise InvalidStream("An HLS link must point to a .m3u8 playlist.")
    return parsed._replace(fragment="").geturl()


def host_allowed(url, allowed):
    """Exact host match against the allowlist. An empty allowlist allows nothing."""
    return host_of(url) in {host.lower() for host in allowed}


def clean_stream(kind, url, embed_hosts, hls_hosts=()):
    """Normalized url for a stream, or InvalidStream. Embed hosts are always enforced; HLS hosts only when set."""
    if kind == EMBED:
        cleaned = normalize_embed_url(url)
        if not host_allowed(cleaned, embed_hosts):
            allowed = ", ".join(sorted(embed_hosts)) or "none configured"
            raise InvalidStream(f"{host_of(cleaned)} is not an approved embed host. Approved: {allowed}.")
        return cleaned
    if kind == HLS:
        cleaned = validate_hls_url(url)
        if hls_hosts and not host_allowed(cleaned, hls_hosts):
            raise InvalidStream(f"{host_of(cleaned)} is not an approved HLS host. Approved: {', '.join(sorted(hls_hosts))}.")
        return cleaned
    raise InvalidStream("Unknown stream type.")
