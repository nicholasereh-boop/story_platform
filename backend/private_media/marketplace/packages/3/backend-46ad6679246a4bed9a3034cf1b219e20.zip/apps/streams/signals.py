from django.db.models.signals import post_delete, post_save

from apps.core.apicache import invalidate

from .models import MatchStream


def _retire_match_cache(**kwargs):
    invalidate("matches")


def connect():
    post_save.connect(_retire_match_cache, sender=MatchStream, dispatch_uid="stream_saved")
    post_delete.connect(_retire_match_cache, sender=MatchStream, dispatch_uid="stream_deleted")
