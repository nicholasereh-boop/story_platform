from django.urls import path

from . import views

urlpatterns = [
    path("matches/<int:match_id>/streams/", views.match_streams, name="match-streams"),
]
