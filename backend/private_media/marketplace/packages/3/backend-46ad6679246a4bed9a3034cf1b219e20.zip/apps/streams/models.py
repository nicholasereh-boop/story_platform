from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from . import sources


def embed_hosts():
    return sources.parse_hosts(settings.STREAM_EMBED_ALLOWED_HOSTS)


def hls_hosts():
    return sources.parse_hosts(settings.STREAM_HLS_ALLOWED_HOSTS)


class MatchStream(models.Model):
    """A video source for one match. Only streams you have the right to show belong here."""

    HLS = sources.HLS
    EMBED = sources.EMBED
    KIND_CHOICES = [(HLS, "HLS playlist (.m3u8)"), (EMBED, "Official embed (YouTube etc.)")]

    match = models.ForeignKey("matches.Match", on_delete=models.CASCADE, related_name="streams")
    kind = models.CharField(max_length=10, choices=KIND_CHOICES)
    title = models.CharField(max_length=120, help_text="Shown to viewers, e.g. 'Official stream' or 'Spanish commentary'.")
    url = models.URLField(max_length=600, help_text="https only. For YouTube paste the watch, share or live link.")
    language = models.CharField(max_length=40, blank=True)
    source_credit = models.CharField(
        max_length=120, blank=True, help_text="Who provides the video (rights holder or provider). Shown under the player."
    )
    is_active = models.BooleanField(default=True, help_text="Untick to hide the stream without deleting it.")
    starts_at = models.DateTimeField(null=True, blank=True, help_text="Optional: show the stream only from this time.")
    ends_at = models.DateTimeField(null=True, blank=True, help_text="Optional: stop showing it after this time.")
    priority = models.PositiveSmallIntegerField(default=0, help_text="Lower numbers are shown first.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["priority", "id"]
        indexes = [models.Index(fields=["match", "is_active"], name="stream_match_active_idx")]

    def __str__(self):
        return f"{self.title} ({self.get_kind_display()}) for match {self.match_id}"

    def clean(self):
        super().clean()
        errors = {}
        if self.kind and self.url:
            try:
                self.url = sources.clean_stream(self.kind, self.url, embed_hosts(), hls_hosts())
            except sources.InvalidStream as exc:
                errors["url"] = str(exc)
        if self.starts_at and self.ends_at and self.ends_at <= self.starts_at:
            errors["ends_at"] = "The end time must be after the start time."
        if errors:
            raise ValidationError(errors)

    def in_window(self, now=None):
        now = now or timezone.now()
        return (self.starts_at is None or self.starts_at <= now) and (self.ends_at is None or now < self.ends_at)

    def is_valid_source(self):
        """Checked again when serving, so a link saved before the allowlist changed (or by a script) is not shown."""
        try:
            sources.clean_stream(self.kind, self.url, embed_hosts(), hls_hosts())
        except sources.InvalidStream:
            return False
        return True
