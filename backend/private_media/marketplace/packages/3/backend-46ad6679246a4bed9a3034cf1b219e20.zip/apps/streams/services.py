from django.utils import timezone

from integrations.sportmonks.constants import LIVE_STATUSES


def playable_streams(match, now=None):
    """The streams viewers may see for this match right now: it must be in play, and each stream active,
    inside its time window and from an approved host. Uses the prefetched `streams` when the view provided them."""
    if match.status not in LIVE_STATUSES:
        return []
    now = now or timezone.now()
    rows = [s for s in match.streams.all() if s.is_active and s.in_window(now) and s.is_valid_source()]
    rows.sort(key=lambda s: (s.priority, s.id))
    return [
        {"id": s.id, "kind": s.kind, "title": s.title, "language": s.language, "credit": s.source_credit, "url": s.url}
        for s in rows
    ]
