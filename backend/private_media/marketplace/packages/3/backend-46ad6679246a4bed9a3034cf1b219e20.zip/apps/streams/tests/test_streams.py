from datetime import timedelta

import pytest
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import Team
from apps.matches.models import Match
from apps.streams.models import MatchStream

pytestmark = pytest.mark.django_db
VIDEO = "dQw4w9WgXcQ"
WATCH = f"https://www.youtube.com/watch?v={VIDEO}"
EMBED = f"https://www.youtube-nocookie.com/embed/{VIDEO}"
HLS = "https://cdn.example.com/live/match.m3u8"
_ids = iter(range(1, 100000))


def make_match(status="LIVE"):
    home = Team.objects.create(provider_id=next(_ids), name=f"Home {next(_ids)}")
    away = Team.objects.create(provider_id=next(_ids), name=f"Away {next(_ids)}")
    return Match.objects.create(
        provider_id=next(_ids), home_team=home, away_team=away, scheduled_at=timezone.now(), status=status
    )


def make_stream(match, **overrides):
    values = {"match": match, "kind": "embed", "title": "Official stream", "url": EMBED}
    values.update(overrides)
    return MatchStream.objects.create(**values)


def detail(client, match):
    return client.get(f"/api/v1/matches/{match.id}/").json()


@pytest.fixture
def client():
    return APIClient()


# --- validation ------------------------------------------------------------------------------------------------

def test_a_youtube_watch_link_is_converted_to_the_embed_address():
    stream = MatchStream(match=make_match(), kind="embed", title="x", url=WATCH)
    stream.clean()
    assert stream.url == EMBED


@pytest.mark.parametrize(
    "kind, url",
    [
        ("embed", "http://www.youtube.com/watch?v=" + VIDEO),
        ("embed", "https://evil.example.com/player"),
        ("embed", "javascript:alert(1)"),
        ("hls", "https://cdn.example.com/live/match.mp4"),
        ("hls", "http://cdn.example.com/live/match.m3u8"),
    ],
)
def test_unsafe_or_unapproved_links_are_rejected(kind, url):
    with pytest.raises(ValidationError) as caught:
        MatchStream(match=make_match(), kind=kind, title="x", url=url).clean()
    assert "url" in caught.value.message_dict


def test_hosts_can_be_approved_in_settings(settings):
    settings.STREAM_EMBED_ALLOWED_HOSTS = "www.youtube-nocookie.com,player.vimeo.com"
    stream = MatchStream(match=make_match(), kind="embed", title="x", url="https://player.vimeo.com/video/1")
    stream.clean()
    assert stream.url == "https://player.vimeo.com/video/1"


def test_an_hls_host_allowlist_is_enforced_when_set(settings):
    settings.STREAM_HLS_ALLOWED_HOSTS = "cdn.example.com"
    MatchStream(match=make_match(), kind="hls", title="x", url=HLS).clean()
    with pytest.raises(ValidationError):
        MatchStream(match=make_match(), kind="hls", title="x", url="https://other.example.com/a.m3u8").clean()


def test_the_end_time_must_follow_the_start_time():
    now = timezone.now()
    with pytest.raises(ValidationError) as caught:
        MatchStream(match=make_match(), kind="embed", title="x", url=EMBED, starts_at=now, ends_at=now).clean()
    assert "ends_at" in caught.value.message_dict


# --- what the API shows ----------------------------------------------------------------------------------------

def test_a_live_match_lists_its_stream(client):
    match = make_match("LIVE")
    stream = make_stream(match, language="English", source_credit="League TV")
    assert detail(client, match)["streams"] == [
        {"id": stream.id, "kind": "embed", "title": "Official stream", "language": "English", "credit": "League TV", "url": EMBED}
    ]


@pytest.mark.parametrize("status", ["SCHEDULED", "FT", "POSTPONED", "CANCELLED"])
def test_nothing_is_shown_when_the_match_is_not_in_play(client, status):
    match = make_match(status)
    make_stream(match)
    assert detail(client, match)["streams"] == []


@pytest.mark.parametrize("status", ["HT", "ET", "PEN"])
def test_breaks_and_extra_time_still_count_as_live(client, status):
    match = make_match(status)
    make_stream(match)
    assert len(detail(client, match)["streams"]) == 1


def test_a_match_without_streams_has_an_empty_list(client):
    assert detail(client, make_match("LIVE"))["streams"] == []


def test_inactive_streams_are_hidden(client):
    match = make_match()
    make_stream(match, is_active=False)
    assert detail(client, match)["streams"] == []


def test_the_time_window_is_respected(client):
    now = timezone.now()
    match = make_match()
    make_stream(match, title="Not yet", starts_at=now + timedelta(hours=1))
    make_stream(match, title="Over", ends_at=now - timedelta(minutes=1))
    make_stream(match, title="Now", starts_at=now - timedelta(hours=1), ends_at=now + timedelta(hours=1))
    assert [s["title"] for s in detail(client, match)["streams"]] == ["Now"]


def test_streams_are_ordered_by_priority(client):
    match = make_match()
    make_stream(match, title="Second", priority=5)
    make_stream(match, title="First", priority=1)
    assert [s["title"] for s in detail(client, match)["streams"]] == ["First", "Second"]


def test_a_link_that_is_no_longer_approved_is_not_served(client, settings):
    match = make_match()
    make_stream(match)  # saved while the host was approved
    settings.STREAM_EMBED_ALLOWED_HOSTS = "player.vimeo.com"
    assert detail(client, match)["streams"] == []


def test_a_link_saved_around_validation_is_not_served(client):
    match = make_match()
    make_stream(match, url="https://evil.example.com/player")  # objects.create skips clean()
    assert detail(client, match)["streams"] == []


def test_the_match_list_does_not_carry_streams(client):
    match = make_match()
    make_stream(match)
    row = client.get("/api/v1/matches/").json()["results"][0]
    assert "streams" not in row


def test_streams_add_no_queries_per_stream(client, django_assert_max_num_queries):
    match = make_match()
    for index in range(5):
        make_stream(match, title=f"Stream {index}")
    with django_assert_max_num_queries(10):
        assert len(detail(client, match)["streams"]) == 5


# --- cache and admin -------------------------------------------------------------------------------------------

def test_adding_a_stream_retires_the_cached_match_page(client, settings):
    settings.PUBLIC_CACHE_ENABLED = True
    cache.clear()
    match = make_match()
    assert detail(client, match)["streams"] == []
    make_stream(match)
    assert len(detail(client, match)["streams"]) == 1
    cache.clear()


def test_the_admin_lists_and_adds_streams(client):
    admin_user = get_user_model().objects.create_superuser("root", "root@example.com", "S3cure-passw0rd!")
    client.force_login(admin_user)
    match = make_match()
    stream = make_stream(match)
    assert client.get("/admin/streams/matchstream/").status_code == 200
    response = client.post(
        "/admin/streams/matchstream/add/",
        {
            "match": match.id, "kind": "embed", "title": "From admin", "url": WATCH, "language": "", "source_credit": "",
            "is_active": "on", "priority": 0,
        },
    )
    assert response.status_code == 302
    assert MatchStream.objects.get(title="From admin").url == EMBED
    assert client.get(f"/admin/streams/matchstream/{stream.id}/change/").status_code == 200


def test_the_admin_refuses_an_unapproved_host(client):
    admin_user = get_user_model().objects.create_superuser("root", "root@example.com", "S3cure-passw0rd!")
    client.force_login(admin_user)
    match = make_match()
    response = client.post(
        "/admin/streams/matchstream/add/",
        {"match": match.id, "kind": "embed", "title": "Bad", "url": "https://evil.example.com/x", "is_active": "on", "priority": 0},
    )
    assert response.status_code == 200  # the form is shown again with an error
    assert not MatchStream.objects.exists()


def test_the_streams_endpoint_agrees_with_the_match_page(client):
    match = make_match("LIVE")
    make_stream(match)
    body = client.get(f"/api/v1/matches/{match.id}/streams/").json()
    assert body["match"] == match.id
    assert body["streams"] == detail(client, match)["streams"] and len(body["streams"]) == 1


def test_the_streams_endpoint_is_empty_when_the_match_is_not_live(client):
    match = make_match("FT")
    make_stream(match)
    assert client.get(f"/api/v1/matches/{match.id}/streams/").json()["streams"] == []


def test_the_streams_endpoint_404s_for_an_unknown_match(client):
    assert client.get("/api/v1/matches/999999/streams/").status_code == 404
