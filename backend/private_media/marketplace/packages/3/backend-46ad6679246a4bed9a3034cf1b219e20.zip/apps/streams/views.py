from django.db.models import Prefetch
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from apps.matches.models import Match

from .models import MatchStream
from .services import playable_streams


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def match_streams(request, match_id):
    """Streams viewers may watch right now. Empty unless the match is in play and a stream is active, in its window
    and from an approved host: the same rule as the `streams` field on the match page."""
    match = get_object_or_404(
        Match.objects.prefetch_related(Prefetch("streams", MatchStream.objects.filter(is_active=True))),
        pk=match_id,
    )
    return Response({"match": match.pk, "streams": playable_streams(match)})
