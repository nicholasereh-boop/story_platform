from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.football.models import League, Player, Team, TeamPlayer
from apps.matches.models import Match
from apps.search import services

pytestmark = pytest.mark.django_db
URL = "/api/v1/search/"
_ids = iter(range(1000, 99000))


@pytest.fixture
def client():
    return APIClient()


def team(name, **extra):
    return Team.objects.create(provider_id=next(_ids), name=name, **extra)


def player(display_name, first="", last="", **extra):
    return Player.objects.create(
        provider_id=next(_ids), display_name=display_name, first_name=first, last_name=last, **extra
    )


def match(home, away, when, status="SCHEDULED", league=None):
    return Match.objects.create(
        provider_id=next(_ids), home_team=home, away_team=away, scheduled_at=when, status=status, league=league
    )


def names(payload, kind, key="name"):
    return [row[key] for row in payload["results"][kind]]


def search(client, q, **params):
    return client.get(URL, {"q": q, **params})


def test_query_is_required_and_needs_two_characters(client):
    assert client.get(URL).status_code == 400
    assert search(client, "a").status_code == 400
    assert search(client, "   a  ").status_code == 400
    assert "q" in search(client, "").json()
    assert search(client, "ab").status_code == 200


def test_unknown_type_and_bad_limit_are_rejected(client):
    assert search(client, "ar", types="teams,cats").status_code == 400
    assert search(client, "ar", types=",").status_code == 400
    assert search(client, "ar", limit="x").status_code == 400
    assert search(client, "ar", limit="0").status_code == 400


def test_limit_is_capped(client):
    assert search(client, "ar", limit="500").json()["limit"] == services.MAX_LIMIT


def test_response_shape_has_every_type_by_default(client):
    data = search(client, "zzz").json()
    assert data["query"] == "zzz"
    assert set(data["results"]) == {"teams", "players", "leagues", "matches"}
    assert data["has_more"] == {"teams": False, "players": False, "leagues": False, "matches": False}


def test_types_parameter_limits_what_is_searched(client):
    team("Arsenal")
    player("Arsenal Fan", "Arsenal", "Fan")
    data = search(client, "arsenal", types="teams").json()
    assert list(data["results"]) == ["teams"]
    assert list(data["has_more"]) == ["teams"]
    both = search(client, "arsenal", types="players, teams").json()
    assert list(both["results"]) == ["teams", "players"]


def test_teams_match_case_insensitively_and_rank_by_closeness(client):
    team("Manchester City")
    team("City")
    team("Bristol City")
    team("Cityzens Reserve")
    team("Chelsea")
    data = search(client, "CITY").json()
    assert names(data, "teams") == ["City", "Cityzens Reserve", "Bristol City", "Manchester City"]


def test_team_short_name_and_code_are_searchable(client):
    team("Manchester United", short_name="Man Utd", code="MUN")
    assert names(search(client, "man utd").json(), "teams") == ["Manchester United"]
    assert names(search(client, "mun").json(), "teams") == ["Manchester United"]
    assert names(search(client, "  mun ").json(), "teams") == ["Manchester United"]


def test_every_word_must_match(client):
    team("Manchester City")
    team("Manchester United")
    team("Leicester City")
    assert names(search(client, "man city").json(), "teams") == ["Manchester City"]
    assert names(search(client, "city man").json(), "teams") == ["Manchester City"]


def test_wildcard_characters_are_literal(client):
    team("Arsenal")
    assert names(search(client, "%%").json(), "teams") == []
    assert names(search(client, "a_s").json(), "teams") == []


def test_players_search_names_and_include_current_team(client):
    arsenal = team("Arsenal")
    saka = player("Bukayo Saka", "Bukayo", "Saka", position="Attacker", nationality="England")
    TeamPlayer.objects.create(team=arsenal, player=saka, active=True, shirt_number=7)
    old = team("Old Club")
    TeamPlayer.objects.create(team=old, player=saka, active=False)
    player("Sakai Other", "Sakai", "Other")

    data = search(client, "saka").json()
    assert names(data, "players", "display_name") == ["Bukayo Saka", "Sakai Other"]
    first = data["results"]["players"][0]
    assert first["current_team"]["name"] == "Arsenal"
    assert set(first) == {"id", "display_name", "position", "nationality", "image", "current_team"}
    assert names(search(client, "bukayo saka").json(), "players", "display_name") == ["Bukayo Saka"]
    assert names(search(client, "saka bukayo").json(), "players", "display_name") == ["Bukayo Saka"]


def test_players_without_a_team_still_appear(client):
    player("Free Agent", "Free", "Agent")
    (row,) = search(client, "agent").json()["results"]["players"]
    assert row["current_team"] is None


def test_leagues_match_name_and_country(client):
    League.objects.create(provider_id=1, name="Premier League", country="England")
    League.objects.create(provider_id=2, name="Championship", country="England")
    League.objects.create(provider_id=3, name="La Liga", country="Spain")
    assert names(search(client, "premier").json(), "leagues") == ["Premier League"]
    assert names(search(client, "england").json(), "leagues") == ["Championship", "Premier League"]
    assert names(search(client, "la liga").json(), "leagues") == ["La Liga"]


def test_matches_for_a_team_are_ordered_live_then_upcoming_then_recent(client):
    now = timezone.now()
    arsenal, chelsea, spurs = team("Arsenal"), team("Chelsea"), team("Tottenham")
    past_old = match(arsenal, chelsea, now - timedelta(days=30), "FT")
    past_new = match(spurs, arsenal, now - timedelta(days=2), "FT")
    soon = match(arsenal, spurs, now + timedelta(days=1))
    later = match(chelsea, arsenal, now + timedelta(days=9))
    live = match(arsenal, chelsea, now - timedelta(minutes=30), "LIVE")
    match(chelsea, spurs, now + timedelta(days=1))

    data = search(client, "arsenal", types="matches", limit=10).json()
    assert [m["id"] for m in data["results"]["matches"]] == [
        live.id, soon.id, later.id, past_new.id, past_old.id,
    ]
    row = data["results"]["matches"][0]
    assert row["home_team"]["name"] == "Arsenal"
    assert row["status"] == "LIVE"


@pytest.mark.parametrize("text", ["arsenal v chelsea", "Arsenal vs Chelsea", "arsenal vs. chelsea", "ARSENAL - CHELSEA"])
def test_versus_queries_find_that_pairing_in_either_order(client, text):
    now = timezone.now()
    arsenal, chelsea, spurs = team("Arsenal"), team("Chelsea"), team("Tottenham")
    home = match(arsenal, chelsea, now + timedelta(days=1))
    away = match(chelsea, arsenal, now + timedelta(days=2))
    match(arsenal, spurs, now + timedelta(days=3))
    data = search(client, text, types="matches").json()
    assert [m["id"] for m in data["results"]["matches"]] == [home.id, away.id]


def test_hyphenated_team_names_are_not_split_as_versus(client):
    now = timezone.now()
    stoke = team("Stoke-on-Trent FC")
    other = team("Derby")
    found = match(stoke, other, now + timedelta(days=1))
    data = search(client, "stoke-on-trent", types="matches").json()
    assert [m["id"] for m in data["results"]["matches"]] == [found.id]


def test_has_more_is_true_only_when_results_were_cut(client):
    now = timezone.now()
    home = team("Arsenal")
    for index in range(4):
        match(home, team(f"Opponent {index}"), now + timedelta(days=index + 1))
    exact = search(client, "arsenal", types="matches", limit=4).json()
    assert len(exact["results"]["matches"]) == 4 and exact["has_more"]["matches"] is False
    cut = search(client, "arsenal", types="matches", limit=3).json()
    assert len(cut["results"]["matches"]) == 3 and cut["has_more"]["matches"] is True


def test_has_more_counts_across_the_match_buckets(client):
    now = timezone.now()
    home = team("Arsenal")
    match(home, team("A"), now - timedelta(minutes=5), "LIVE")
    match(home, team("B"), now + timedelta(days=1))
    match(home, team("C"), now - timedelta(days=1), "FT")
    assert search(client, "arsenal", types="matches", limit=3).json()["has_more"]["matches"] is False
    assert search(client, "arsenal", types="matches", limit=2).json()["has_more"]["matches"] is True


def test_query_count_does_not_grow_with_results(client, django_assert_max_num_queries):
    now = timezone.now()
    club = team("Arsenal", short_name="Gunners")
    for index in range(8):
        rival = team(f"Arsenal Rival {index}")
        match(club, rival, now + timedelta(days=index + 1))
        member = player(f"Arsenal Player {index}", "Arsenal", f"Player{index}")
        TeamPlayer.objects.create(team=rival, player=member, active=True)
    with django_assert_max_num_queries(8):
        response = search(client, "arsenal", limit=20)
    assert response.status_code == 200
    assert len(response.json()["results"]["players"]) == 8


def test_whitespace_is_collapsed(client):
    team("Manchester City")
    data = search(client, "  manchester    city ").json()
    assert data["query"] == "manchester city"
    assert names(data, "teams") == ["Manchester City"]
