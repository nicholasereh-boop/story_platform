import re

from django.db.models import Case, IntegerField, Prefetch, Q, Value, When
from django.utils import timezone

from apps.football.models import League, Player, Team, TeamPlayer
from apps.matches.models import Match
from integrations.sportmonks.constants import LIVE_STATUSES

MIN_QUERY_LENGTH = 2
MAX_QUERY_LENGTH = 100
MAX_TOKENS = 6
DEFAULT_LIMIT = 5
MAX_LIMIT = 20
TYPES = ("teams", "players", "leagues", "matches")

# "Arsenal v Chelsea", "Arsenal vs. Chelsea", "Arsenal - Chelsea". The separator needs
# whitespace on both sides so names such as "Stoke-on-Trent" are left alone.
VERSUS = re.compile(r"\s+(?:vs?\.?|-|–|—)\s+", re.IGNORECASE)


def normalize(raw):
    return " ".join((raw or "").split())[:MAX_QUERY_LENGTH]


def tokens(text):
    return text.split()[:MAX_TOKENS]


def _all_tokens(fields, words):
    """Every word must appear (case-insensitively) in at least one of the fields."""
    query = Q()
    for word in words:
        any_field = Q()
        for field in fields:
            any_field |= Q(**{f"{field}__icontains": word})
        query &= any_field
    return query


def _rank(*fields_and_q, q):
    """0 exact, 1 starts with, 2 a later word starts with, 3 anything else."""
    exact, starts, word = Q(), Q(), Q()
    for field in fields_and_q:
        exact |= Q(**{f"{field}__iexact": q})
        starts |= Q(**{f"{field}__istartswith": q})
        word |= Q(**{f"{field}__icontains": f" {q}"})
    return Case(
        When(exact, then=Value(0)),
        When(starts, then=Value(1)),
        When(word, then=Value(2)),
        default=Value(3),
        output_field=IntegerField(),
    )


def _take(queryset, limit):
    rows = list(queryset[: limit + 1])
    return rows[:limit], len(rows) > limit


def search_teams(q, limit):
    match = _all_tokens(["name", "short_name"], tokens(q))
    if len(tokens(q)) == 1:
        match |= Q(code__iexact=q)
    queryset = Team.objects.filter(match).annotate(rank=_rank("name", "short_name", q=q)).order_by("rank", "name", "id")
    return _take(queryset, limit)


def search_players(q, limit):
    memberships = Prefetch(
        "team_memberships",
        queryset=TeamPlayer.objects.filter(active=True).select_related("team"),
        to_attr="active_memberships",
    )
    queryset = (
        Player.objects.filter(_all_tokens(["display_name", "first_name", "last_name"], tokens(q)))
        .annotate(rank=_rank("display_name", "last_name", q=q))
        .order_by("rank", "display_name", "id")
        .prefetch_related(memberships)
    )
    return _take(queryset, limit)


def search_leagues(q, limit):
    queryset = (
        League.objects.filter(_all_tokens(["name", "short_name", "country"], tokens(q)))
        .annotate(rank=_rank("name", "short_name", q=q))
        .order_by("rank", "-active", "name", "id")
    )
    return _take(queryset, limit)


def _side(prefix, text):
    return _all_tokens([f"{prefix}__name", f"{prefix}__short_name"], tokens(text))


def match_filter(q):
    parts = [part for part in VERSUS.split(q) if part.strip()] if VERSUS.search(q) else [q]
    if len(parts) == 2:
        first, second = parts
        return (_side("home_team", first) & _side("away_team", second)) | (
            _side("home_team", second) & _side("away_team", first)
        )
    return _side("home_team", q) | _side("away_team", q)


def search_matches(q, limit):
    """Live matches first, then the nearest upcoming ones, then the most recent results."""
    base = Match.objects.filter(match_filter(q)).select_related("league", "home_team", "away_team")
    now = timezone.now()
    live = base.filter(status__in=LIVE_STATUSES).order_by("scheduled_at", "id")
    not_live = base.exclude(status__in=LIVE_STATUSES)
    upcoming = not_live.filter(scheduled_at__gte=now).order_by("scheduled_at", "id")
    past = not_live.filter(scheduled_at__lt=now).order_by("-scheduled_at", "-id")
    rows = []
    for queryset in (live, upcoming, past):
        rows.extend(queryset[: limit + 1])
    return rows[:limit], len(rows) > limit


SEARCHERS = {
    "teams": search_teams,
    "players": search_players,
    "leagues": search_leagues,
    "matches": search_matches,
}


def search(q, types=TYPES, limit=DEFAULT_LIMIT):
    return {name: SEARCHERS[name](q, limit) for name in types}
