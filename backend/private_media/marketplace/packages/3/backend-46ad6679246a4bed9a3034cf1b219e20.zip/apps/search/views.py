from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .serializers import SERIALIZERS


def parse_types(raw):
    if not raw:
        return services.TYPES
    requested = [part.strip().lower() for part in raw.split(",") if part.strip()]
    unknown = sorted(set(requested) - set(services.TYPES))
    if unknown or not requested:
        raise ValidationError({"types": [f"Choose from: {', '.join(services.TYPES)}."]})
    return tuple(name for name in services.TYPES if name in requested)


def parse_limit(raw):
    if raw in (None, ""):
        return services.DEFAULT_LIMIT
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise ValidationError({"limit": ["Must be a whole number."]})
    if value < 1:
        raise ValidationError({"limit": ["Must be at least 1."]})
    return min(value, services.MAX_LIMIT)


class SearchView(APIView):
    throttle_scope = "search"

    @extend_schema(
        parameters=[
            OpenApiParameter("q", str, required=True, description="Search text, at least 2 characters."),
            OpenApiParameter("types", str, description="Comma separated: teams, players, leagues, matches."),
            OpenApiParameter("limit", int, description="Results per type (1-20, default 5)."),
        ],
        responses={200: dict},
    )
    def get(self, request):
        q = services.normalize(request.query_params.get("q"))
        if len(q) < services.MIN_QUERY_LENGTH:
            raise ValidationError({"q": [f"Enter at least {services.MIN_QUERY_LENGTH} characters."]})
        types = parse_types(request.query_params.get("types"))
        limit = parse_limit(request.query_params.get("limit"))

        found = services.search(q, types, limit)
        context = {"request": request}
        return Response(
            {
                "query": q,
                "limit": limit,
                "results": {
                    name: SERIALIZERS[name](rows, many=True, context=context).data for name, (rows, _) in found.items()
                },
                "has_more": {name: more for name, (_, more) in found.items()},
            }
        )
