from apps.football.serializers import LeagueMiniSerializer, PlayerSerializer, TeamSerializer
from apps.matches.serializers import MatchListSerializer


class SearchTeamSerializer(TeamSerializer):
    class Meta(TeamSerializer.Meta):
        fields = ("id", "name", "short_name", "country", "logo")


class SearchPlayerSerializer(PlayerSerializer):
    class Meta(PlayerSerializer.Meta):
        fields = ("id", "display_name", "position", "nationality", "image", "current_team")


SERIALIZERS = {
    "teams": SearchTeamSerializer,
    "players": SearchPlayerSerializer,
    "leagues": LeagueMiniSerializer,
    "matches": MatchListSerializer,
}
