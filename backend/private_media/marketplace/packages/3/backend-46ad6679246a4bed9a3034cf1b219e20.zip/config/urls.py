from django.conf import settings
from django.contrib import admin
from django.urls import include, path
from apps.users.views import ThrottledTokenObtainPairView, ThrottledTokenRefreshView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path(settings.ADMIN_URL, admin.site.urls),
    path("api/v1/", include("apps.core.urls")),
    path("api/v1/auth/", include("apps.users.urls")),
    path("api/v1/", include("apps.football.urls")),
    path("api/v1/", include("apps.matches.urls")),
    path("api/v1/", include("apps.streams.urls")),
    path("api/v1/", include("apps.search.urls")),
    path("api/v1/", include("apps.news.urls")),
    path("api/v1/admin-panel/", include("apps.monitor.urls")),
    path("api/v1/my/favorites/", include("apps.favorites.urls")),
    path("api/v1/my/notifications/", include("apps.notifications.urls")),
    path("api/v1/token/", ThrottledTokenObtainPairView.as_view(), name="token"),
    path("api/v1/token/refresh/", ThrottledTokenRefreshView.as_view(), name="token_refresh"),
]

if settings.API_DOCS_ENABLED:
    urlpatterns += [
        path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
        path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
    ]
