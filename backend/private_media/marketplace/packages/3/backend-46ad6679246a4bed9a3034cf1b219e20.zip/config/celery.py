import os

from celery import Celery
from celery.schedules import crontab

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.development")
app = Celery("config")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
app.conf.beat_schedule = {
    "live-scores-every-15-seconds": {
        "task": "apps.matches.tasks.fetch_live_scores",
        "schedule": 15.0,
        "options": {"expires": 14},
    },
    "match-details-every-minute": {
        "task": "apps.matches.tasks.sync_match_details",
        "schedule": 60.0,
        "options": {"expires": 55},
    },
    "fixtures-every-10-minutes": {
        "task": "apps.matches.tasks.sync_fixtures",
        "schedule": 600.0,
    },
    "standings-every-15-minutes": {
        "task": "apps.football.tasks.sync_standings",
        "schedule": 900.0,
    },
    "reference-data-daily": {
        "task": "apps.football.tasks.sync_reference_data",
        "schedule": crontab(hour=3, minute=0),
    },
    "players-daily": {
        "task": "apps.football.tasks.sync_players",
        "schedule": crontab(hour=3, minute=30),
    },
    "purge-old-notifications-daily": {
        "task": "apps.notifications.tasks.purge_old_notifications",
        "schedule": crontab(hour=4, minute=0),
    },
    "flush-expired-tokens-daily": {
        "task": "apps.users.tasks.flush_expired_tokens",
        "schedule": crontab(hour=4, minute=30),
    },
}
