from .base import *

DEBUG = True
API_DOCS_ENABLED = True
