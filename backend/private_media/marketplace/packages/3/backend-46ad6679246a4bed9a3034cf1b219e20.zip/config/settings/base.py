import os
from pathlib import Path
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Running `python manage.py ...` directly (outside Docker) does not read .env by itself. Real environment
# variables always win, so Docker, CI and production are unaffected.
try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR.parent / ".env")  # project root, next to docker-compose.yml
    load_dotenv(BASE_DIR / ".env")  # or backend/.env
except ImportError:
    pass


def _flag(name, default):
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "unsafe-development-key")
# Off unless asked for; production.py refuses to start with it on.
DEBUG = _flag("DJANGO_DEBUG", False)
# The admin lives at an unguessable path in production (it also gets no-store and login lockout).
ADMIN_URL = os.getenv("ADMIN_URL", "admin/").strip("/") + "/"
# Swagger UI and the schema describe every endpoint; public only when asked for (always on in development).
API_DOCS_ENABLED = _flag("API_DOCS_ENABLED", False)
ALLOWED_HOSTS = [x.strip() for x in os.getenv("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if x.strip()]

INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth", "django.contrib.contenttypes",
    "django.contrib.postgres", "django.contrib.sessions", "django.contrib.messages", "django.contrib.staticfiles",
    "corsheaders", "rest_framework", "django_filters", "drf_spectacular",
    "django_celery_beat", "rest_framework_simplejwt.token_blacklist",
    "apps.core", "apps.users", "apps.football", "apps.matches", "apps.search", "apps.favorites", "apps.notifications", "apps.news", "apps.streams", "apps.monitor",
]

MIDDLEWARE = [
    "apps.monitor.middleware.RequestMetricsMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "apps.core.security.SecurityHeadersMiddleware",
    "apps.core.security.LoginLockoutMiddleware",
    "django.middleware.http.ConditionalGetMiddleware",  # ETag / 304 Not Modified
    "apps.core.apicache.PublicCacheMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [],
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages",
    ]},
}]
WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("POSTGRES_DB", "football"),
        "USER": os.getenv("POSTGRES_USER", "postgres"),
        "PASSWORD": os.getenv("POSTGRES_PASSWORD", "postgres"),
        "HOST": os.getenv("POSTGRES_HOST", "localhost"),
        "PORT": os.getenv("POSTGRES_PORT", "5432"),
        # "require" / "verify-full" encrypt the connection to a managed or remote database.
        "OPTIONS": {"sslmode": os.getenv("POSTGRES_SSLMODE", "prefer")},
    }
}
DATA_UPLOAD_MAX_MEMORY_SIZE = 1_000_000  # the API takes small JSON bodies only
DATA_UPLOAD_MAX_NUMBER_FIELDS = 200

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

CORS_ALLOWED_ORIGINS = [x.strip() for x in os.getenv("CORS_ALLOWED_ORIGINS", "http://localhost:5173").split(",") if x.strip()]

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.AllowAny",),
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "DEFAULT_FILTER_BACKENDS": ("django_filters.rest_framework.DjangoFilterBackend",),
    "DEFAULT_PAGINATION_CLASS": "apps.core.pagination.StandardPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_THROTTLE_CLASSES": (
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
        "rest_framework.throttling.ScopedRateThrottle",
    ),
    # How many reverse proxies sit in front of Django. Without it every visitor shares the proxy's address
    # and throttling either blocks everyone together or (if X-Forwarded-For is trusted blindly) can be spoofed.
    "NUM_PROXIES": int(os.getenv("NUM_PROXIES", "0")),
    "DEFAULT_THROTTLE_RATES": {
        "anon": os.getenv("THROTTLE_ANON", "300/min"),
        "user": os.getenv("THROTTLE_USER", "600/min"),
        "auth": os.getenv("THROTTLE_AUTH", "10/min"),
        "search": os.getenv("THROTTLE_SEARCH", "60/min"),
    },
}
# Failed logins per address+account before that pair is locked out, and for how long (see apps/core/security.py).
LOGIN_LOCKOUT_FAILURES = int(os.getenv("LOGIN_LOCKOUT_FAILURES", "5"))
LOGIN_LOCKOUT_IP_FAILURES = int(os.getenv("LOGIN_LOCKOUT_IP_FAILURES", "30"))
LOGIN_LOCKOUT_SECONDS = int(os.getenv("LOGIN_LOCKOUT_SECONDS", "900"))

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=int(os.getenv("JWT_ACCESS_MINUTES", "15"))),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=int(os.getenv("JWT_REFRESH_DAYS", "7"))),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "ALGORITHM": "HS256",
    # A separate key lets the token key be rotated without touching Django's own signing.
    "SIGNING_KEY": os.getenv("JWT_SIGNING_KEY") or SECRET_KEY,
    "AUTH_HEADER_TYPES": ("Bearer",),
}
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
CELERY_BROKER_URL = os.getenv("CELERY_BROKER_URL", REDIS_URL)
CELERY_RESULT_BACKEND = os.getenv("CELERY_RESULT_BACKEND", REDIS_URL)
CACHES = {"default": {"BACKEND": "django_redis.cache.RedisCache", "LOCATION": REDIS_URL, "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"}}}

# Redis Pub/Sub fan-out to the WebSocket server (the database sync works with it off).
REALTIME_PUBLISH_ENABLED = _flag("REALTIME_PUBLISH_ENABLED", True)
# Redis response cache for the public API (see apps/core/apicache.py).
PUBLIC_CACHE_ENABLED = _flag("PUBLIC_CACHE_ENABLED", True)
# Skip provider calls while nothing is live or about to start.
LIVE_ADAPTIVE_POLLING = _flag("LIVE_ADAPTIVE_POLLING", True)

# Live video. Only hosts listed here may be embedded (exact host names, comma-separated). YouTube links are
# converted to the privacy-friendly www.youtube-nocookie.com address, so that is the host to approve.
STREAM_EMBED_ALLOWED_HOSTS = os.getenv("STREAM_EMBED_ALLOWED_HOSTS", "www.youtube-nocookie.com")
# Optional allowlist for HLS playlist hosts. Empty accepts any https host; set it once you know your provider.
STREAM_HLS_ALLOWED_HOSTS = os.getenv("STREAM_HLS_ALLOWED_HOSTS", "")

SPECTACULAR_SETTINGS = {"TITLE": "Football Platform API", "VERSION": "1.0.0"}

SPORTMONKS_API_TOKEN = os.getenv("SPORTMONKS_API_TOKEN", "")
SPORTMONKS_BASE_URL = os.getenv("SPORTMONKS_BASE_URL", "https://api.sportmonks.com/v3/football")
SPORTMONKS_TIMEOUT = float(os.getenv("SPORTMONKS_TIMEOUT", "20"))
SPORTMONKS_LEAGUE_IDS = {
    int(x) for x in os.getenv("SPORTMONKS_LEAGUE_IDS", "").split(",") if x.strip().isdigit()
}

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"plain": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "plain"}},
    "loggers": {
        "django.request": {"handlers": ["console"], "level": "WARNING", "propagate": False},
        "django.security": {"handlers": ["console"], "level": "WARNING", "propagate": False},
        "apps": {"handlers": ["console"], "level": "INFO"},
        "integrations": {"handlers": ["console"], "level": "INFO"},
    },
}

# Staff monitoring dashboard (/ops). Counters live in Redis for 72 hours; set MONITOR_ENABLED=false to switch recording off.
MONITOR_ENABLED = _flag("MONITOR_ENABLED", True)
MONITOR_REDIS_URL = os.getenv("MONITOR_REDIS_URL", REDIS_URL)
REALTIME_HEALTH_URL = os.getenv("REALTIME_HEALTH_URL", "http://localhost:8080/health")
