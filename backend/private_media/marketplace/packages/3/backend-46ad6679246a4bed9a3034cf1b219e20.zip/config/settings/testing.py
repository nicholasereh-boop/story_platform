from .development import *

CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True
REALTIME_PUBLISH_ENABLED = False  # tests switch it on through the fake_redis fixture
LIVE_ADAPTIVE_POLLING = False
PUBLIC_CACHE_ENABLED = False  # cache tests switch it on explicitly
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
SPORTMONKS_LEAGUE_IDS = set()
REST_FRAMEWORK = {
    **REST_FRAMEWORK,
    "DEFAULT_THROTTLE_RATES": {"anon": "100000/min", "user": "100000/min", "auth": "100000/min", "search": "100000/min"},
}
LOGIN_LOCKOUT_FAILURES = 100000  # lockout tests lower it explicitly
LOGIN_LOCKOUT_IP_FAILURES = 100000
API_DOCS_ENABLED = True
MONITOR_ENABLED = False  # monitor tests switch it on with an in-memory store
