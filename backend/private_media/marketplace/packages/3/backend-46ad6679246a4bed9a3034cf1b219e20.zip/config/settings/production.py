import logging
import os

from .base import *
from .base import _flag  # star-imports skip underscore names
from .security import enforce_production, split_csv

DEBUG = False
API_DOCS_ENABLED = _flag("API_DOCS_ENABLED", False)

# HTTPS everywhere. Django sits behind a TLS-terminating proxy that sets X-Forwarded-Proto.
SECURE_SSL_REDIRECT = _flag("SECURE_SSL_REDIRECT", True)
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_REDIRECT_EXEMPT = [r"^api/v1/health/$"]  # the platform's health probe speaks plain HTTP

# HSTS: browsers refuse plain HTTP for a year. Preload is opt-in because it is hard to undo.
SECURE_HSTS_SECONDS = int(os.getenv("SECURE_HSTS_SECONDS", "31536000"))
SECURE_HSTS_INCLUDE_SUBDOMAINS = _flag("SECURE_HSTS_INCLUDE_SUBDOMAINS", True)
SECURE_HSTS_PRELOAD = _flag("SECURE_HSTS_PRELOAD", False)

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"
SECURE_CROSS_ORIGIN_OPENER_POLICY = "same-origin"
X_FRAME_OPTIONS = "DENY"

# Cookies only matter for the admin (the API authenticates with a bearer token), but they are locked down anyway.
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_AGE = int(os.getenv("SESSION_COOKIE_AGE", str(8 * 3600)))  # admin sessions: a working day
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = "Lax"
CSRF_TRUSTED_ORIGINS = split_csv(os.getenv("CSRF_TRUSTED_ORIGINS"))

# Bearer tokens are not cookies, so credentialed cross-site requests are never needed.
CORS_ALLOW_CREDENTIALS = False

# Refuse to boot with placeholder or weak secrets, wildcard hosts, plain-HTTP origins or the default admin path.
enforce_production(
    secret_key=SECRET_KEY,
    jwt_signing_key=SIMPLE_JWT["SIGNING_KEY"],
    allowed_hosts=ALLOWED_HOSTS,
    cors_origins=CORS_ALLOWED_ORIGINS,
    csrf_origins=CSRF_TRUSTED_ORIGINS,
    db_password=DATABASES["default"]["PASSWORD"],
    admin_url=ADMIN_URL,
    debug=_flag("DJANGO_DEBUG", False),
)

# Error reporting. Optional: nothing is sent unless SENTRY_DSN is set. Personal data is never attached.
if os.getenv("SENTRY_DSN"):
    try:
        import sentry_sdk

        sentry_sdk.init(
            dsn=os.environ["SENTRY_DSN"],
            environment=os.getenv("SENTRY_ENVIRONMENT", "production"),
            send_default_pii=False,
            traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0")),
        )
    except ImportError:
        logging.getLogger(__name__).warning("SENTRY_DSN is set but sentry-sdk is not installed")
