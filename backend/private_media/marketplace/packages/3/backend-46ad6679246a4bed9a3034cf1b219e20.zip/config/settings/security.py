"""Production safety checks. Pure functions, so they can be unit-tested without importing the settings."""
from django.core.exceptions import ImproperlyConfigured

KNOWN_BAD_SECRETS = {"", "unsafe-development-key", "change-me", "changeme", "secret", "django-insecure"}
KNOWN_BAD_DB_PASSWORDS = {"", "postgres", "password", "change-me", "changeme"}
MIN_SECRET_LENGTH = 50
MIN_UNIQUE_CHARACTERS = 8


def split_csv(value):
    return [item.strip() for item in (value or "").split(",") if item.strip()]


def weak_secret(value):
    value = value or ""
    if value.lower() in KNOWN_BAD_SECRETS or value.lower().startswith("django-insecure"):
        return True
    return len(value) < MIN_SECRET_LENGTH or len(set(value)) < MIN_UNIQUE_CHARACTERS


def production_problems(
    *, secret_key, jwt_signing_key, allowed_hosts, cors_origins, csrf_origins, db_password, admin_url, debug=False
):
    """Everything wrong with a production configuration, as readable sentences. Empty means fine."""
    problems = []
    if debug:
        problems.append("DJANGO_DEBUG must be false in production.")
    if weak_secret(secret_key):
        problems.append(
            f"DJANGO_SECRET_KEY is missing, a known placeholder, or weak (use {MIN_SECRET_LENGTH}+ random characters)."
        )
    if jwt_signing_key != secret_key and weak_secret(jwt_signing_key):
        problems.append("JWT_SIGNING_KEY is weak (use 50+ random characters, or leave it unset to reuse the secret key).")
    if not allowed_hosts or any(host in {"*", ".*"} for host in allowed_hosts):
        problems.append("DJANGO_ALLOWED_HOSTS must list the real host names, not be empty or '*'.")
    for origin in cors_origins:
        if origin == "*" or not origin.startswith("https://"):
            problems.append(f"CORS_ALLOWED_ORIGINS entry {origin!r} must be an https:// origin.")
    for origin in csrf_origins:
        if not origin.startswith("https://"):
            problems.append(f"CSRF_TRUSTED_ORIGINS entry {origin!r} must be an https:// origin.")
    if (db_password or "").lower() in KNOWN_BAD_DB_PASSWORDS:
        problems.append("POSTGRES_PASSWORD is empty or a well-known default.")
    if admin_url.strip("/") == "admin":
        problems.append("ADMIN_URL is still the default 'admin/'; pick an unguessable path.")
    return problems


def enforce_production(**config):
    problems = production_problems(**config)
    if problems:
        raise ImproperlyConfigured("Unsafe production configuration:\n- " + "\n- ".join(problems))
