import logging
import time
from contextlib import nullcontext

import httpx

from .exceptions import SportmonksAuthError, SportmonksError, SportmonksRateLimited

logger = logging.getLogger(__name__)


class SportmonksClient:
    max_attempts = 3
    max_pages = 200
    low_quota_warning = 50

    def __init__(self, token=None, base_url=None, timeout=None, transport=None):
        if token is None or base_url is None or timeout is None:
            from django.conf import settings

            token = settings.SPORTMONKS_API_TOKEN if token is None else token
            base_url = settings.SPORTMONKS_BASE_URL if base_url is None else base_url
            timeout = settings.SPORTMONKS_TIMEOUT if timeout is None else timeout
        if not token:
            raise SportmonksAuthError("SPORTMONKS_API_TOKEN is not configured")
        self._client = httpx.Client(
            base_url=base_url.rstrip("/") + "/",
            timeout=timeout,
            headers={"Authorization": token, "Accept": "application/json"},
            transport=transport,
        )

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def get(self, path, params=None):
        last_error = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                response = self._client.get(path.lstrip("/"), params=params)
            except httpx.TransportError as exc:
                last_error = SportmonksError(f"Network error calling Sportmonks: {exc.__class__.__name__}")
                self._backoff(attempt)
                continue

            if response.status_code in (401, 403):
                raise SportmonksAuthError(f"Sportmonks rejected the token ({response.status_code})")
            if response.status_code == 429:
                raise SportmonksRateLimited(retry_after=self._retry_after(response))
            if response.status_code >= 500:
                last_error = SportmonksError(f"Sportmonks server error {response.status_code}")
                self._backoff(attempt)
                continue
            if response.status_code >= 400:
                raise SportmonksError(f"Sportmonks request failed with {response.status_code}")

            payload = response.json()
            self._check_quota(payload)
            return payload
        raise last_error

    def paginate(self, path, params=None, per_page=50):
        params = dict(params or {})
        params["per_page"] = per_page
        for page in range(1, self.max_pages + 1):
            params["page"] = page
            payload = self.get(path, params)
            data = payload.get("data") or []
            if isinstance(data, dict):
                yield data
            else:
                yield from data
            pagination = payload.get("pagination") or {}
            if not pagination.get("has_more"):
                return
        logger.warning("Stopped paginating %s after %s pages", path, self.max_pages)

    def leagues(self, includes="country;seasons"):
        return self.paginate("leagues", {"include": includes})

    def teams_by_season(self, season_id, includes="country;venue"):
        return self.paginate(f"teams/seasons/{season_id}", {"include": includes})

    def squad(self, team_id, includes="player.nationality"):
        return self.paginate(f"squads/teams/{team_id}", {"include": includes})

    def fixtures_between(self, start, end, includes, league_ids=None):
        params = {"include": includes}
        if league_ids:
            params["filters"] = "fixtureLeagues:" + ",".join(str(i) for i in sorted(league_ids))
        return self.paginate(f"fixtures/between/{start:%Y-%m-%d}/{end:%Y-%m-%d}", params)

    def livescores_inplay(self, includes):
        return self.paginate("livescores/inplay", {"include": includes})

    def fixtures_multi(self, ids, includes):
        ids = ",".join(str(i) for i in ids)
        return self.paginate(f"fixtures/multi/{ids}", {"include": includes})

    def standings_by_season(self, season_id, includes="participant;details.type;form"):
        return self.paginate(f"standings/seasons/{season_id}", {"include": includes})

    def _backoff(self, attempt):
        if attempt < self.max_attempts:
            time.sleep(min(2 ** attempt, 8))

    @staticmethod
    def _retry_after(response):
        header = response.headers.get("Retry-After")
        if header and header.isdigit():
            return int(header)
        try:
            return int(response.json()["rate_limit"]["resets_in_seconds"])
        except (ValueError, KeyError, TypeError):
            return 60

    def _check_quota(self, payload):
        rate_limit = payload.get("rate_limit")
        if isinstance(rate_limit, dict) and rate_limit.get("remaining") is not None:
            if rate_limit["remaining"] < self.low_quota_warning:
                logger.warning(
                    "Sportmonks quota low: %s requests left for %s (resets in %ss)",
                    rate_limit["remaining"],
                    rate_limit.get("requested_entity"),
                    rate_limit.get("resets_in_seconds"),
                )


def client_scope(client=None):
    return nullcontext(client) if client is not None else SportmonksClient()
