from decimal import Decimal

from integrations.sportmonks import normalizers as n


def fixture_payload(**overrides):
    raw = {
        "id": 100,
        "league_id": 8,
        "season_id": 2500,
        "starting_at": "2026-10-21 19:00:00",
        "starting_at_timestamp": 1792609200,
        "state": {"developer_name": "INPLAY_2ND_HALF"},
        "participants": [
            {"id": 1, "name": "Arsenal", "image_path": "a.png", "meta": {"location": "home"}},
            {"id": 2, "name": "Chelsea", "image_path": "c.png", "meta": {"location": "away"}},
        ],
        "scores": [
            {"description": "1ST_HALF", "score": {"goals": 1, "participant": "home"}},
            {"description": "1ST_HALF", "score": {"goals": 0, "participant": "away"}},
            {"description": "CURRENT", "score": {"goals": 2, "participant": "home"}},
            {"description": "CURRENT", "score": {"goals": 1, "participant": "away"}},
        ],
        "periods": [
            {"started": 1792609260, "ended": 1792612000, "ticking": False, "minutes": 45},
            {"started": 1792613000, "ended": None, "ticking": True, "minutes": 67},
        ],
        "venue": {"name": "Emirates Stadium"},
        "round": {"name": "9"},
    }
    raw.update(overrides)
    return raw


def test_fixture_live_normalization():
    fixture = n.normalize_fixture(fixture_payload())
    assert fixture["status"] == "LIVE"
    assert fixture["minute"] == 67
    assert (fixture["home_score"], fixture["away_score"]) == (2, 1)
    assert (fixture["home_ht_score"], fixture["away_ht_score"]) == (1, 0)
    assert fixture["home"]["name"] == "Arsenal"
    assert fixture["venue"] == "Emirates Stadium"
    assert fixture["scheduled_at"].tzinfo is not None


def test_fixture_finished_has_no_minute_and_an_end_time():
    fixture = n.normalize_fixture(fixture_payload(state={"developer_name": "FT"}, periods=[
        {"started": 1792609260, "ended": 1792612000, "ticking": False, "minutes": 45},
        {"started": 1792613000, "ended": 1792616000, "ticking": False, "minutes": 90},
    ]))
    assert fixture["status"] == "FT"
    assert fixture["minute"] is None
    assert fixture["ended_at"] is not None


def test_fixture_unknown_state_keeps_status_unset():
    assert n.normalize_fixture(fixture_payload(state={"developer_name": "SOMETHING_NEW"}))["status"] is None


def test_fixture_rejects_invalid_payloads():
    assert n.normalize_fixture(fixture_payload(participants=[])) is None
    assert n.normalize_fixture(fixture_payload(starting_at=None, starting_at_timestamp=None)) is None
    same = [
        {"id": 1, "name": "A", "meta": {"location": "home"}},
        {"id": 1, "name": "A", "meta": {"location": "away"}},
    ]
    assert n.normalize_fixture(fixture_payload(participants=same)) is None


def test_event_types_and_assist_cleanup():
    goal = n.normalize_event({"id": 1, "type": {"developer_name": "GOAL"}, "player_id": 5,
                              "related_player_id": 5, "minute": 12, "participant_id": 1})
    assert goal["type"] == "GOAL" and goal["assist_provider_id"] is None
    penalty = n.normalize_event({"id": 2, "type": {"developer_name": "PENALTY"}, "player_id": 5})
    assert penalty["type"] == "GOAL"
    by_id = n.normalize_event({"id": 3, "type_id": 20, "player_id": 5})
    assert by_id["type"] == "RED_CARD"
    assert n.normalize_event({"id": 4, "type_id": 9999})["type"] == "OTHER"
    assert n.normalize_event({"type_id": 14}) is None


def test_lineup_starters_and_bench():
    starter = n.normalize_lineup({"player_id": 1, "team_id": 2, "type_id": 11, "jersey_number": 7, "position_id": 27})
    assert starter["starter"] is True and starter["position"] == "Attacker"
    assert n.normalize_lineup({"player_id": 1, "team_id": 2, "type_id": 12})["starter"] is False
    assert n.normalize_lineup({"player_id": 1, "team_id": 2, "type_id": 99}) is None


def test_statistics_grouped_per_team_with_validation():
    stats = n.normalize_statistics([
        {"participant_id": 1, "type": {"developer_name": "BALL_POSSESSION"}, "data": {"value": 61.5}},
        {"participant_id": 1, "type": {"developer_name": "CORNERS"}, "data": {"value": 6}},
        {"participant_id": 2, "type": {"developer_name": "BALL_POSSESSION"}, "data": {"value": 250}},
        {"participant_id": 2, "type": {"developer_name": "UNKNOWN"}, "data": {"value": 1}},
    ])
    assert stats[1]["possession"] == Decimal("61.5") and stats[1]["corners"] == 6
    assert stats[2]["possession"] is None
    assert stats[1]["shots"] is None


def test_standing_details_and_form():
    standing = n.normalize_standing({
        "participant_id": 1, "position": 2, "points": 20,
        "participant": {"name": "Arsenal", "image_path": "a.png"},
        "details": [
            {"type": {"developer_name": "OVERALL_MATCHES_PLAYED"}, "value": 9},
            {"type_id": 130, "value": 6},
            {"type_id": 133, "value": 15},
            {"type_id": 134, "value": 5},
        ],
        "form": [{"form": "L", "sort_order": 2}, {"form": "W", "sort_order": 1}],
    })
    assert standing["played"] == 9 and standing["won"] == 6
    assert standing["goal_difference"] == 10
    assert standing["form"] == "WL"
    assert n.normalize_standing({"participant_id": 1, "position": 0}) is None


def test_league_season_team_player():
    league = n.normalize_league({"id": 8, "name": "Premier League", "short_code": "UK PL",
                                 "country": {"name": "England"}, "image_path": "pl.png", "active": True})
    assert league["country"] == "England"
    assert n.normalize_league({"id": 8}) is None
    season = n.normalize_season({"id": 1, "name": "2026/2027", "starting_at": "2026-08-01",
                                 "ending_at": "2025-01-01", "is_current": True}, league_provider_id=8)
    assert season["end_date"] is None and season["is_current"] is True
    assert n.normalize_team({"id": 1, "name": "X", "placeholder": True}) is None
    team = n.normalize_team({"id": 1, "name": "Arsenal", "short_code": "ARS", "founded": 1886,
                             "venue": {"name": "Emirates"}})
    assert team["stadium"] == "Emirates" and team["code"] == "ARS"
    member = n.normalize_squad_member({"jersey_number": 7, "position_id": 27, "player": {
        "id": 9, "display_name": "Bukayo Saka", "date_of_birth": "2001-09-05", "nationality": {"name": "England"}}})
    assert member["player"]["nationality"] == "England" and member["shirt_number"] == 7
    assert member["position"] == "Attacker"
    assert n.normalize_squad_member({"jersey_number": 7}) is None
