import httpx
import pytest

from integrations.sportmonks.client import SportmonksClient
from integrations.sportmonks.exceptions import SportmonksAuthError, SportmonksError, SportmonksRateLimited


def make_client(handler):
    return SportmonksClient(
        token="secret-token",
        base_url="https://example.test/v3/football",
        timeout=5,
        transport=httpx.MockTransport(handler),
    )


def test_token_is_sent_in_header_never_in_url():
    seen = {}

    def handler(request):
        seen["auth"] = request.headers["authorization"]
        seen["url"] = str(request.url)
        return httpx.Response(200, json={"data": []})

    make_client(handler).get("leagues", {"include": "country"})
    assert seen["auth"] == "secret-token"
    assert "secret-token" not in seen["url"]
    assert seen["url"].startswith("https://example.test/v3/football/leagues")


def test_paginate_follows_pages_until_done():
    pages = {
        1: {"data": [{"id": 1}], "pagination": {"has_more": True}},
        2: {"data": [{"id": 2}], "pagination": {"has_more": False}},
    }

    def handler(request):
        return httpx.Response(200, json=pages[int(request.url.params["page"])])

    assert [row["id"] for row in make_client(handler).paginate("leagues")] == [1, 2]


def test_missing_data_is_treated_as_empty():
    client = make_client(lambda request: httpx.Response(200, json={"message": "No result(s) found"}))
    assert list(client.paginate("fixtures/multi/1")) == []


def test_rate_limit_exposes_retry_after():
    client = make_client(lambda r: httpx.Response(429, json={"rate_limit": {"resets_in_seconds": 42}}))
    with pytest.raises(SportmonksRateLimited) as info:
        client.get("livescores/inplay")
    assert info.value.retry_after == 42


def test_auth_errors_are_not_retried():
    calls = []

    def handler(request):
        calls.append(1)
        return httpx.Response(401, json={})

    with pytest.raises(SportmonksAuthError):
        make_client(handler).get("leagues")
    assert len(calls) == 1


def test_server_errors_are_retried_then_succeed(monkeypatch):
    monkeypatch.setattr("integrations.sportmonks.client.time.sleep", lambda seconds: None)
    responses = [httpx.Response(502), httpx.Response(200, json={"data": [{"id": 1}]})]
    client = make_client(lambda request: responses.pop(0))
    assert client.get("leagues")["data"] == [{"id": 1}]


def test_persistent_server_errors_raise(monkeypatch):
    monkeypatch.setattr("integrations.sportmonks.client.time.sleep", lambda seconds: None)
    with pytest.raises(SportmonksError):
        make_client(lambda request: httpx.Response(503)).get("leagues")


def test_missing_token_is_rejected():
    with pytest.raises(SportmonksAuthError):
        SportmonksClient(token="", base_url="https://example.test", timeout=5)
