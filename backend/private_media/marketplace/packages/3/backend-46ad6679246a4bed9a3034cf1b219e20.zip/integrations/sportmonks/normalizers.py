import logging
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation

from . import constants as c

logger = logging.getLogger(__name__)


def _text(value, max_length):
    if value is None:
        return ""
    return str(value).strip()[:max_length]


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _non_negative_int(value):
    number = _int(value)
    return number if number is not None and number >= 0 else None


def _decimal(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _datetime_utc(timestamp=None, text=None):
    if timestamp is not None:
        try:
            return datetime.fromtimestamp(int(timestamp), tz=timezone.utc)
        except (TypeError, ValueError, OverflowError, OSError):
            pass
    if text:
        try:
            return datetime.strptime(str(text), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


def normalize_league(raw):
    provider_id = _int(raw.get("id"))
    name = _text(raw.get("name"), 200)
    if provider_id is None or not name:
        return None
    country = raw.get("country") if isinstance(raw.get("country"), dict) else {}
    return {
        "provider_id": provider_id,
        "name": name,
        "short_name": _text(raw.get("short_code"), 100),
        "country": _text(country.get("name"), 100),
        "logo": _text(raw.get("image_path"), 200),
        "active": bool(raw.get("active", True)),
    }


def normalize_season(raw, league_provider_id=None):
    provider_id = _int(raw.get("id"))
    league_id = _int(league_provider_id if league_provider_id is not None else raw.get("league_id"))
    name = _text(raw.get("name"), 100)
    if provider_id is None or league_id is None or not name:
        return None
    start, end = _date(raw.get("starting_at")), _date(raw.get("ending_at"))
    if start and end and end < start:
        end = None
    return {
        "provider_id": provider_id,
        "league_provider_id": league_id,
        "name": name,
        "start_date": start,
        "end_date": end,
        "is_current": bool(raw.get("is_current", False)),
    }


def normalize_team(raw):
    provider_id = _int(raw.get("id"))
    name = _text(raw.get("name"), 200)
    if provider_id is None or not name or raw.get("placeholder"):
        return None
    country = raw.get("country") if isinstance(raw.get("country"), dict) else {}
    venue = raw.get("venue") if isinstance(raw.get("venue"), dict) else {}
    return {
        "provider_id": provider_id,
        "name": name,
        "short_name": _text(raw.get("short_code"), 100),
        "code": _text(raw.get("short_code"), 20),
        "country": _text(country.get("name"), 100),
        "logo": _text(raw.get("image_path"), 200),
        "stadium": _text(venue.get("name"), 200),
        "founded": _non_negative_int(raw.get("founded")),
        "active": True,
    }


def normalize_player(raw):
    provider_id = _int(raw.get("id"))
    display_name = _text(raw.get("display_name") or raw.get("common_name") or raw.get("name"), 200)
    if provider_id is None or not display_name:
        return None
    nationality = raw.get("nationality") if isinstance(raw.get("nationality"), dict) else {}
    return {
        "provider_id": provider_id,
        "first_name": _text(raw.get("firstname"), 100),
        "last_name": _text(raw.get("lastname"), 100),
        "display_name": display_name,
        "date_of_birth": _date(raw.get("date_of_birth")),
        "nationality": _text(nationality.get("name"), 100),
        "position": c.POSITION_ID_TO_NAME.get(_int(raw.get("position_id")), ""),
        "image": _text(raw.get("image_path"), 200),
    }


def normalize_squad_member(raw):
    player_raw = raw.get("player")
    if not isinstance(player_raw, dict):
        return None
    player = normalize_player(player_raw)
    if player is None:
        return None
    position = c.POSITION_ID_TO_NAME.get(_int(raw.get("position_id")), player["position"])
    return {
        "player": player,
        "shirt_number": _non_negative_int(raw.get("jersey_number")),
        "position": position,
    }


def _participants(raw):
    result = {}
    for participant in raw.get("participants") or []:
        location = (participant.get("meta") or {}).get("location")
        provider_id = _int(participant.get("id"))
        name = _text(participant.get("name"), 200)
        if location in ("home", "away") and provider_id is not None and name:
            result[location] = {
                "provider_id": provider_id,
                "name": name,
                "logo": _text(participant.get("image_path"), 200),
            }
    return result


def _scores(raw):
    current, half_time = {}, {}
    for score in raw.get("scores") or []:
        data = score.get("score") or {}
        side, goals = data.get("participant"), _non_negative_int(data.get("goals"))
        if side not in ("home", "away") or goals is None:
            continue
        if score.get("description") == "CURRENT":
            current[side] = goals
        elif score.get("description") == "1ST_HALF":
            half_time[side] = goals
    return current, half_time


def _periods(raw):
    periods = [p for p in raw.get("periods") or [] if isinstance(p, dict)]
    minute = None
    for period in periods:
        if period.get("ticking"):
            minute = _non_negative_int(period.get("minutes"))
    starts = [_int(p.get("started")) for p in periods if _int(p.get("started"))]
    ends = [_int(p.get("ended")) for p in periods if _int(p.get("ended"))]
    started_at = _datetime_utc(timestamp=min(starts)) if starts else None
    return minute, started_at, ends


def normalize_fixture(raw):
    provider_id = _int(raw.get("id"))
    scheduled_at = _datetime_utc(raw.get("starting_at_timestamp"), raw.get("starting_at"))
    teams = _participants(raw)
    if provider_id is None or scheduled_at is None or set(teams) != {"home", "away"}:
        return None
    if teams["home"]["provider_id"] == teams["away"]["provider_id"]:
        return None

    state = raw.get("state") if isinstance(raw.get("state"), dict) else {}
    status = c.STATE_TO_STATUS.get(state.get("developer_name"))
    current, half_time = _scores(raw)
    minute, started_at, ends = _periods(raw)
    ended_at = _datetime_utc(timestamp=max(ends)) if ends and status == "FT" else None
    if status not in c.LIVE_STATUSES:
        minute = None
    if minute is not None and minute > 150:
        minute = None
    if started_at and ended_at and ended_at < started_at:
        ended_at = None

    venue = raw.get("venue") if isinstance(raw.get("venue"), dict) else {}
    round_ = raw.get("round") if isinstance(raw.get("round"), dict) else {}
    return {
        "provider_id": provider_id,
        "league_provider_id": _int(raw.get("league_id")),
        "season_provider_id": _int(raw.get("season_id")),
        "home": teams["home"],
        "away": teams["away"],
        "scheduled_at": scheduled_at,
        "started_at": started_at,
        "ended_at": ended_at,
        "status": status,
        "minute": minute,
        "home_score": current.get("home", 0),
        "away_score": current.get("away", 0),
        "home_ht_score": half_time.get("home"),
        "away_ht_score": half_time.get("away"),
        "venue": _text(venue.get("name"), 200),
        "round": _text(round_.get("name"), 100),
    }


def normalize_event(raw):
    provider_id = _int(raw.get("id"))
    if provider_id is None:
        return None
    type_obj = raw.get("type") if isinstance(raw.get("type"), dict) else {}
    event_type = c.EVENT_NAME_TO_TYPE.get(str(type_obj.get("developer_name", "")).upper())
    if event_type is None:
        event_type = c.EVENT_ID_TO_TYPE.get(_int(raw.get("type_id")), "OTHER")
    player_id = _int(raw.get("player_id"))
    related_id = _int(raw.get("related_player_id"))
    if related_id == player_id:
        related_id = None
    description = " ".join(
        part for part in (_text(raw.get("player_name"), 100), _text(raw.get("result"), 50),
                          _text(raw.get("info"), 100), _text(raw.get("addition"), 100)) if part
    )
    return {
        "provider_id": provider_id,
        "type": event_type,
        "minute": _non_negative_int(raw.get("minute")),
        "extra_minute": _non_negative_int(raw.get("extra_minute")),
        "team_provider_id": _int(raw.get("participant_id")),
        "player_provider_id": player_id,
        "player_name": _text(raw.get("player_name"), 200),
        "assist_provider_id": related_id,
        "assist_name": _text(raw.get("related_player_name"), 200),
        "description": description,
    }


def normalize_lineup(raw):
    player_id, team_id = _int(raw.get("player_id")), _int(raw.get("team_id"))
    type_id = _int(raw.get("type_id"))
    if player_id is None or team_id is None or type_id not in (c.LINEUP_TYPE_STARTER, c.LINEUP_TYPE_BENCH):
        return None
    return {
        "player_provider_id": player_id,
        "player_name": _text(raw.get("player_name"), 200),
        "team_provider_id": team_id,
        "starter": type_id == c.LINEUP_TYPE_STARTER,
        "shirt_number": _non_negative_int(raw.get("jersey_number")),
        "position": c.POSITION_ID_TO_NAME.get(_int(raw.get("position_id")), ""),
    }


def normalize_statistics(raw_stats):
    by_team = {}
    for stat in raw_stats or []:
        team_id = _int(stat.get("participant_id"))
        type_obj = stat.get("type") if isinstance(stat.get("type"), dict) else {}
        field = c.STAT_NAME_TO_FIELD.get(str(type_obj.get("developer_name", "")).upper())
        value = (stat.get("data") or {}).get("value")
        if team_id is None or field is None or value is None:
            continue
        if field in c.DECIMAL_STAT_FIELDS:
            number = _decimal(value)
            if field == "possession" and number is not None and not (0 <= number <= 100):
                number = None
        else:
            number = _non_negative_int(value)
        row = by_team.setdefault(team_id, {name: None for name in c.STAT_FIELDS})
        row[field] = number
    return by_team


def normalize_standing(raw):
    participant = raw.get("participant") if isinstance(raw.get("participant"), dict) else {}
    team_id, position = _int(raw.get("participant_id")), _int(raw.get("position"))
    if team_id is None or position is None or position < 1:
        return None
    row = {name: 0 for name in c.STANDING_ID_TO_FIELD.values()}
    seen_gd = False
    for detail in raw.get("details") or []:
        type_obj = detail.get("type") if isinstance(detail.get("type"), dict) else {}
        field = c.STANDING_NAME_TO_FIELD.get(str(type_obj.get("developer_name", "")).upper())
        if field is None:
            field = c.STANDING_ID_TO_FIELD.get(_int(detail.get("type_id")))
        value = _int(detail.get("value"))
        if field is None or value is None:
            continue
        if field in ("goal_difference",):
            seen_gd = True
        row[field] = value if field in ("goal_difference", "goals_for", "goals_against") else max(value, 0)
    if not seen_gd:
        row["goal_difference"] = row["goals_for"] - row["goals_against"]
    forms = sorted(
        (f for f in raw.get("form") or [] if isinstance(f, dict) and f.get("form")),
        key=lambda f: _int(f.get("sort_order")) or 0,
    )
    row.update(
        {
            "team_provider_id": team_id,
            "team_name": _text(participant.get("name"), 200),
            "team_logo": _text(participant.get("image_path"), 200),
            "position": position,
            "points": _int(raw.get("points")) or 0,
            "form": "".join(str(f["form"])[:1] for f in forms)[-20:],
        }
    )
    return row
