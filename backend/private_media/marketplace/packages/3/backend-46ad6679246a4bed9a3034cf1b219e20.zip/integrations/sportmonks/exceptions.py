class SportmonksError(Exception):
    pass


class SportmonksAuthError(SportmonksError):
    pass


class SportmonksRateLimited(SportmonksError):
    def __init__(self, message="Sportmonks rate limit reached", retry_after=60):
        super().__init__(message)
        self.retry_after = retry_after
