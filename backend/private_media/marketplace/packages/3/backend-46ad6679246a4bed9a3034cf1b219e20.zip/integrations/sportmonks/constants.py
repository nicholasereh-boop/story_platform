STATE_TO_STATUS = {
    "NS": "SCHEDULED",
    "TBA": "SCHEDULED",
    "PENDING": "SCHEDULED",
    "DELAYED": "SCHEDULED",
    "INPLAY_1ST_HALF": "LIVE",
    "INPLAY_2ND_HALF": "LIVE",
    "BREAK": "LIVE",
    "HT": "HT",
    "INPLAY_ET": "ET",
    "INPLAY_ET_2ND_HALF": "ET",
    "EXTRA_TIME_BREAK": "ET",
    "INPLAY_PENALTIES": "PEN",
    "PEN_BREAK": "PEN",
    "FT": "FT",
    "AET": "FT",
    "FT_PEN": "FT",
    "AWARDED": "FT",
    "WO": "FT",
    "POSTPONED": "POSTPONED",
    "SUSPENDED": "SUSPENDED",
    "INTERRUPTED": "SUSPENDED",
    "ABANDONED": "ABANDONED",
    "CANCELLED": "CANCELLED",
    "DELETED": "CANCELLED",
}

LIVE_STATUSES = ("LIVE", "HT", "ET", "PEN")

EVENT_NAME_TO_TYPE = {
    "GOAL": "GOAL",
    "PENALTY": "GOAL",
    "OWNGOAL": "OWN_GOAL",
    "OWN_GOAL": "OWN_GOAL",
    "YELLOWCARD": "YELLOW_CARD",
    "REDCARD": "RED_CARD",
    "YELLOWREDCARD": "RED_CARD",
    "SUBSTITUTION": "SUBSTITUTION",
    "VAR": "VAR",
    "VAR_CARD": "VAR",
    "MISSED_PENALTY": "OTHER",
}

EVENT_ID_TO_TYPE = {
    10: "VAR",
    14: "GOAL",
    15: "OWN_GOAL",
    16: "GOAL",
    17: "OTHER",
    18: "SUBSTITUTION",
    19: "YELLOW_CARD",
    20: "RED_CARD",
    21: "RED_CARD",
}

POSITION_ID_TO_NAME = {
    24: "Goalkeeper",
    25: "Defender",
    26: "Midfielder",
    27: "Attacker",
}

LINEUP_TYPE_STARTER = 11
LINEUP_TYPE_BENCH = 12

STAT_NAME_TO_FIELD = {
    "CORNERS": "corners",
    "SHOTS_TOTAL": "shots",
    "SHOTS_ON_TARGET": "shots_on_target",
    "SHOTS_OFF_TARGET": "shots_off_target",
    "BALL_POSSESSION": "possession",
    "FOULS": "fouls",
    "OFFSIDES": "offsides",
    "YELLOWCARDS": "yellow_cards",
    "REDCARDS": "red_cards",
    "PASSES": "passes",
    "SUCCESSFUL_PASSES": "passes_completed",
    "EXPECTED_GOALS": "expected_goals",
}

STAT_FIELDS = tuple(STAT_NAME_TO_FIELD.values())
DECIMAL_STAT_FIELDS = ("possession", "expected_goals")

STANDING_NAME_TO_FIELD = {
    "OVERALL_MATCHES_PLAYED": "played",
    "OVERALL_WON": "won",
    "OVERALL_DRAW": "drawn",
    "OVERALL_LOST": "lost",
    "OVERALL_GOALS_SCORED": "goals_for",
    "OVERALL_GOALS_AGAINST": "goals_against",
    "GOAL_DIFFERENCE": "goal_difference",
}

STANDING_ID_TO_FIELD = {
    129: "played",
    130: "won",
    131: "drawn",
    132: "lost",
    133: "goals_for",
    134: "goals_against",
    179: "goal_difference",
}
