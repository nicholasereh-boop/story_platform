import json

import pytest
import redis

from apps.core import pubsub


class FakeRedis:
    def __init__(self):
        self.seq = 0
        self.published = []
        self.store = {}
        self.fail = False

    def get(self, key):
        if key == pubsub.SEQ_KEY:
            return str(self.seq)
        return self.store.get(key)

    def set(self, key, value, ex=None):
        if self.fail:
            raise redis.ConnectionError("redis is down")
        self.store[key] = value

    def register_script(self, script):
        def run(keys, args):
            if self.fail:
                raise redis.ConnectionError("redis is down")
            self.seq += 1
            channel, body = args
            body = body.replace('"seq":0', f'"seq":{self.seq}', 1)
            self.published.append((channel, json.loads(body)))
            return self.seq

        return run

    def messages(self, channel=None, type=None):
        return [
            message for ch, message in self.published
            if (channel is None or ch == channel) and (type is None or message["type"] == type)
        ]


@pytest.fixture(autouse=True)
def fake_redis(monkeypatch, settings):
    settings.REALTIME_PUBLISH_ENABLED = True
    fake = FakeRedis()
    monkeypatch.setattr(pubsub, "get_client", lambda: fake)
    return fake
