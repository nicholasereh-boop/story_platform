# Fix for: ImportError: cannot import name 'services' from 'apps'

## Cause
Two different `video_tools` apps were mixed in one folder: the tested one (it has a `services/` FOLDER) and a separate scaffold
(it has a `services.py` FILE, different models, and URLs under /jobs/ instead of /downloads/). Python cannot use both, so the
`from .. import services` line in `__init__.py` fails. Removing that one line is not enough: the next error is the same clash.
The fix is to use ONE app. This folder is the tested one, and the one the React pages call.

## Steps (Windows, from `story_platform\backend`)
1. Stop the dev server. Keep a copy of your current `apps\video_tools` somewhere safe, just in case.
2. Replace the app's code, but KEEP your current `migrations` folder for now:
   - delete every file and folder inside `apps\video_tools` EXCEPT `migrations`
     (this removes `services.py`, `providers\`, `validators.py`, `cleanup.py`, `tests_urls.py` and any `__pycache__`)
   - copy everything from this zip's `backend\apps\video_tools` into it, EXCEPT its `migrations` folder.
3. Delete the scaffold's tests: `tests\test_video_tools.py` and `tests\test_video_tools_security.py`.
4. Roll back the old video tables. This is safe: no download has ever worked, so there is nothing to lose:
       python manage.py migrate video_tools zero
   (If it says there is nothing to roll back, you never migrated the scaffold, and you can continue.)
5. Replace `apps\video_tools\migrations` with the `migrations` folder from this zip, then:
       python manage.py migrate
       python manage.py check
6. Make sure `config\settings\base.py` has `"apps.video_tools"` in INSTALLED_APPS and `config\api_urls.py` includes `apps.video_tools.urls`.
