const WS_URL = import.meta.env.VITE_WS_URL || "ws://localhost:8080";

export function connectLive(onMessage, onStatus = () => {}) {
  let socket;
  let attempt = 0;
  let timer;
  let closed = false;

  function open() {
    onStatus("connecting");
    socket = new WebSocket(WS_URL);
    socket.onopen = () => {
      attempt = 0;
      onStatus("open");
    };
    socket.onmessage = (event) => {
      try {
        onMessage(JSON.parse(event.data));
      } catch {
        onMessage({ type: "raw", data: event.data });
      }
    };
    socket.onclose = () => {
      onStatus("closed");
      if (closed) return;
      attempt += 1;
      timer = setTimeout(open, Math.min(1000 * 2 ** attempt, 15000));
    };
    socket.onerror = () => socket.close();
  }

  open();

  const stop = () => {
    closed = true;
    clearTimeout(timer);
    socket?.close();
  };
  stop.reconnect = () => {
    if (socket && socket.readyState === 1) socket.close();
  };
  stop.send = (payload) => {
    if (socket && socket.readyState === 1) socket.send(JSON.stringify(payload));
  };
  return stop;
}
