import {
  changePasswordRequest, getMe, loginRequest, logoutRequest, register as registerRequest, updateMe, updateSettings,
} from "../api.js";
import { usePrefs } from "../prefs/store.js";
import { useAuth } from "./store.js";

function adopt(user) {
  useAuth.getState().setUser(user);
  // Saved settings follow the account to any device.
  usePrefs.getState().setPrefs(user.profile || {});
  return user;
}

export async function loadUser() {
  return adopt(await getMe());
}

export async function login(identifier, password) {
  const tokens = await loginRequest(identifier.trim(), password);
  useAuth.getState().setTokens(tokens.access, tokens.refresh);
  return loadUser();
}

export async function signUp(form) {
  await registerRequest(form);
  return login(form.username, form.password);
}

// Called once at startup: turns saved tokens back into a signed-in user.
export async function restoreSession() {
  if (!useAuth.getState().refresh) return;
  try {
    await loadUser();
  } catch (error) {
    // Only a rejected session signs the user out; an offline server must not.
    if (error?.response?.status === 401 || !useAuth.getState().refresh) useAuth.getState().clear();
    else useAuth.getState().setStatus("anonymous");
  }
}

export async function logout() {
  const { refresh } = useAuth.getState();
  try {
    if (refresh) await logoutRequest(refresh);
  } catch {
    /* the local session ends either way */
  }
  useAuth.getState().clear();
}

export async function saveAccount(changes) {
  const user = await updateMe(changes);
  useAuth.getState().setUser({ ...useAuth.getState().user, ...user });
  return user;
}

export async function saveSettings(changes) {
  const profile = await updateSettings(changes);
  usePrefs.getState().setPrefs(profile);
  const { user } = useAuth.getState();
  if (user) useAuth.getState().setUser({ ...user, profile });
  return profile;
}

export async function changePassword(currentPassword, newPassword) {
  const tokens = await changePasswordRequest({ current_password: currentPassword, new_password: newPassword });
  useAuth.getState().setTokens(tokens.access, tokens.refresh);
}
