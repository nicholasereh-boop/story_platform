import { create } from "zustand";

const KEY = "fl.auth";

function read() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    return { access: saved?.access || null, refresh: saved?.refresh || null };
  } catch {
    return { access: null, refresh: null };
  }
}

function persist(access, refresh) {
  try {
    if (access || refresh) localStorage.setItem(KEY, JSON.stringify({ access, refresh }));
    else localStorage.removeItem(KEY);
  } catch {
    /* storage unavailable: the session lasts until the tab closes */
  }
}

const saved = read();

// status: "anonymous" | "loading" (tokens found, profile not fetched yet) | "authenticated"
export const useAuth = create((set, get) => ({
  access: saved.access,
  refresh: saved.refresh,
  user: null,
  status: saved.refresh ? "loading" : "anonymous",
  setTokens(access, refresh) {
    persist(access, refresh);
    set({ access, refresh });
  },
  setUser(user) {
    set({ user, status: "authenticated" });
  },
  setStatus(status) {
    set({ status });
  },
  clear() {
    persist(null, null);
    set({ access: null, refresh: null, user: null, status: "anonymous" });
  },
}));
