import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  deleteNotification, getNotificationPrefs, getNotifications, getUnreadCount, markNotificationsRead,
  updateNotificationPrefs,
} from "../api.js";
import { useIsSignedIn } from "../favorites/hooks.js";
import { markedRead } from "../lib/notifications.js";

const COUNT_KEY = ["notifications", "count"];

// New notifications are found by polling: cheap (one COUNT query) and works without extra infrastructure.
export function useUnreadCount() {
  const signedIn = useIsSignedIn();
  return useQuery({ queryKey: COUNT_KEY, queryFn: getUnreadCount, enabled: signedIn, refetchInterval: 30000, select: (data) => data.count });
}

export function useNotifications({ page, unread }) {
  const signedIn = useIsSignedIn();
  return useQuery({
    queryKey: ["notifications", "list", { page, unread }],
    queryFn: () => getNotifications({ page, unread: unread ? 1 : undefined }),
    enabled: signedIn,
    placeholderData: keepPreviousData,
  });
}

export function useMarkRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload) => markNotificationsRead(payload),
    onMutate: (payload) => {
      const ids = payload.all ? "all" : payload.ids;
      queryClient.setQueriesData({ queryKey: ["notifications", "list"] }, (page) => markedRead(page, ids));
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });
}

export function useDismiss() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteNotification,
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });
}

export function useNotificationPrefs() {
  const signedIn = useIsSignedIn();
  return useQuery({ queryKey: ["notifications", "prefs"], queryFn: getNotificationPrefs, enabled: signedIn });
}

export function useUpdatePrefs() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updateNotificationPrefs,
    onMutate: async (changes) => {
      await queryClient.cancelQueries({ queryKey: ["notifications", "prefs"] });
      const previous = queryClient.getQueryData(["notifications", "prefs"]);
      queryClient.setQueryData(["notifications", "prefs"], (current) => ({ ...current, ...changes }));
      return { previous };
    },
    onError: (_error, _changes, context) => queryClient.setQueryData(["notifications", "prefs"], context?.previous),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["notifications", "prefs"] }),
  });
}
