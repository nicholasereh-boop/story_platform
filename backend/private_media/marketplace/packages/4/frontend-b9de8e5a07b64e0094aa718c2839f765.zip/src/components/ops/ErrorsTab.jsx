import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getOpsErrors } from "../../api.js";
import { OVERVIEW_REFRESH_MS } from "../../lib/ops.js";
import Async, { Empty } from "../Async.jsx";

export default function ErrorsTab() {
  const query = useQuery({ queryKey: ["ops", "errors"], queryFn: getOpsErrors, refetchInterval: OVERVIEW_REFRESH_MS, staleTime: 0 });
  return (
    <Async query={query}>
      {({ results }) =>
        results.length === 0 ? (
          <Empty>No server errors recorded recently.</Empty>
        ) : (
          <div className="card list ops-scroll">
            <table className="ops-table">
              <thead><tr><th>When</th><th>Request</th><th>Status</th><th>Time</th><th>Cause</th></tr></thead>
              <tbody>
                {results.map((e, i) => (
                  <tr key={`${e.t}-${i}`}>
                    <td>{new Date(e.t * 1000).toLocaleString()}</td>
                    <td className="ops-route"><span className={`ops-method ops-m-${e.method}`}>{e.method}</span> {e.path}</td>
                    <td className="ops-bad">{e.status}</td>
                    <td>{e.ms} ms</td>
                    <td>{e.exc || "–"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="muted ops-hint" style={{ padding: "0 12px" }}>The last 200 server errors. Stack traces are not stored; find them in the server log.</p>
          </div>
        )
      }
    </Async>
  );
}
