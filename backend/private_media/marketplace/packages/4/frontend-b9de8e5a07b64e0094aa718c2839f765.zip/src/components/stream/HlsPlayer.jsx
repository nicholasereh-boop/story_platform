import React, { useEffect, useRef, useState } from "react";
import { hlsRecovery } from "../../lib/stream.js";

const NATIVE = "application/vnd.apple.mpegurl";

export default function HlsPlayer({ src, title }) {
  const video = useRef(null);
  const [error, setError] = useState(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const element = video.current;
    if (!element) return undefined;
    setError(null);
    let hls = null;
    let cancelled = false;
    let retries = 0;

    if (element.canPlayType(NATIVE)) {
      // Safari and iOS play HLS natively.
      element.src = src;
    } else {
      // hls.js is only downloaded when a stream is actually opened.
      import("hls.js")
        .then(({ default: Hls }) => {
          if (cancelled) return;
          if (!Hls.isSupported()) {
            setError("This browser cannot play this stream.");
            return;
          }
          hls = new Hls({ lowLatencyMode: true });
          hls.on(Hls.Events.ERROR, (_event, data) => {
            const action = hlsRecovery(data, retries);
            if (action === "ignore") return;
            retries += 1;
            if (action === "reload") hls.startLoad();
            else if (action === "recover") hls.recoverMediaError();
            else {
              hls.destroy();
              setError("The stream is unavailable or has stopped.");
            }
          });
          hls.on(Hls.Events.FRAG_LOADED, () => { retries = 0; });
          hls.loadSource(src);
          hls.attachMedia(element);
        })
        .catch(() => !cancelled && setError("The video player could not be loaded."));
    }

    return () => {
      cancelled = true;
      if (hls) hls.destroy();
      element.removeAttribute("src");
      element.load?.();
    };
  }, [src, attempt]);

  return (
    <div className="player-frame">
      <video ref={video} controls playsInline preload="auto" title={title} aria-label={title} />
      {error && (
        <div className="player-error" role="alert">
          <p>{error}</p>
          <button type="button" className="link-button" onClick={() => setAttempt((n) => n + 1)}>Try again</button>
        </div>
      )}
    </div>
  );
}
