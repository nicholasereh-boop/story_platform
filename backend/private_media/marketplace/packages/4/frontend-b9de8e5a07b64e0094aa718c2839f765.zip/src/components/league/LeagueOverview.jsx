import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getLeagueStandings, getLeagueStatistics, getResults, getUpcomingMatches } from "../../api.js";
import Async, { Empty } from "../Async.jsx";
import MatchGroups from "../MatchGroups.jsx";
import StandingsTable from "../StandingsTable.jsx";
import { Tile } from "./LeagueStats.jsx";

const TOP_ROWS = 6;

export default function LeagueOverview({ leagueId, season, onTab }) {
  const param = season || undefined;
  const standings = useQuery({ queryKey: ["league", leagueId, "standings", season], queryFn: () => getLeagueStandings(leagueId, { season: param }), retry: false });
  const fixtures = useQuery({ queryKey: ["league", leagueId, "overview-fixtures", season], queryFn: () => getUpcomingMatches({ league: leagueId, season: param, page_size: 5 }) });
  const results = useQuery({ queryKey: ["league", leagueId, "overview-results", season], queryFn: () => getResults({ league: leagueId, season: param, page_size: 5 }) });
  const stats = useQuery({ queryKey: ["league", leagueId, "statistics", season], queryFn: () => getLeagueStatistics(leagueId, { season: param }), retry: false });

  return (
    <>
      {stats.data && (
        <div className="grid stat-tiles">
          <Tile label="Matches played" value={stats.data.summary.played} />
          <Tile label="Goals" value={stats.data.summary.goals} />
          <Tile label="Goals per match" value={stats.data.summary.goals_per_match} />
        </div>
      )}

      <div className="section-head">
        <h2>Table</h2>
        <button type="button" className="link-button" onClick={() => onTab("standings")}>Full table</button>
      </div>
      {standings.isError && standings.error?.response?.status === 404
        ? <Empty>No table available yet.</Empty>
        : <Async query={standings}>{(d) => <StandingsTable rows={d.table.slice(0, TOP_ROWS)} />}</Async>}

      <div className="section-head">
        <h2>Next fixtures</h2>
        <button type="button" className="link-button" onClick={() => onTab("fixtures")}>All fixtures</button>
      </div>
      <Async query={fixtures}>{(d) => <MatchGroups matches={d.results} by="day" emptyText="No upcoming fixtures." />}</Async>

      <div className="section-head">
        <h2>Latest results</h2>
        <button type="button" className="link-button" onClick={() => onTab("results")}>All results</button>
      </div>
      <Async query={results}>{(d) => <MatchGroups matches={d.results} by="day" emptyText="No results yet." />}</Async>
    </>
  );
}
