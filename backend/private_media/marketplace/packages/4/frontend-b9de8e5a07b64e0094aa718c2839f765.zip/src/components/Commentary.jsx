import React from "react";
import { buildCommentary } from "../lib/commentary.js";
import { Empty } from "./Async.jsx";

export default function Commentary({ match }) {
  const feed = buildCommentary(match);
  if (feed.length === 0) return <Empty>Commentary starts at kick-off.</Empty>;
  return (
    <>
      <p className="muted note">Generated from the match events and status.</p>
      <ol className="card commentary">
        {feed.map((entry) => (
          <li key={entry.id} className={`commentary-item commentary-${entry.kind}`}>
            <span className="when">{entry.time}</span>
            <span aria-hidden="true">{entry.icon}</span>
            <span>{entry.text}</span>
          </li>
        ))}
      </ol>
    </>
  );
}
