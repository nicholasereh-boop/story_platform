import React from "react";
import { highlightParts } from "../lib/search.js";

export default function Highlight({ text, query }) {
  return (
    <>
      {highlightParts(text, query).map((part, index) =>
        part.match ? <mark key={index}>{part.text}</mark> : <React.Fragment key={index}>{part.text}</React.Fragment>,
      )}
    </>
  );
}
