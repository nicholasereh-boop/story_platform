import React from "react";
import { NavLink } from "react-router-dom";
import { useUnreadCount } from "../notifications/hooks.js";
import { badgeText } from "../lib/notifications.js";

export default function NotificationBell() {
  const { data: count } = useUnreadCount();
  const text = badgeText(count);
  return (
    <NavLink to="/notifications" className={({ isActive }) => (isActive ? "active" : undefined)} aria-label={count ? `Notifications, ${count} unread` : "Notifications"}>
      Alerts{text && <span className="badge">{text}</span>}
    </NavLink>
  );
}
