import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getNews } from "../api.js";
import NewsCard from "./NewsCard.jsx";

// "Latest news" for a team, league or player page. Renders nothing while loading, on error, or when empty,
// so a page without news looks exactly as it did before.
export default function RelatedNews({ filter, id, title = "Latest news" }) {
  const query = useQuery({
    queryKey: ["news", "related", filter, id],
    queryFn: () => getNews({ [filter]: id, page_size: 3 }),
    staleTime: 60000,
  });
  const articles = query.data?.results ?? [];
  if (articles.length === 0) return null;
  return (
    <section>
      <div className="section-head"><h2>{title}</h2><Link to="/news">All news</Link></div>
      <div className="news-grid">{articles.map((article) => <NewsCard key={article.id} article={article} compact />)}</div>
    </section>
  );
}
