import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getSquad } from "../../api.js";
import { groupSquad } from "../../lib/team.js";
import Async, { Empty } from "../Async.jsx";

export default function TeamSquad({ teamId }) {
  const query = useQuery({ queryKey: ["team", teamId, "squad"], queryFn: () => getSquad(teamId) });
  return (
    <Async query={query}>
      {(members) => members.length === 0 ? <Empty>Squad not available yet.</Empty> : (
        groupSquad(members).map((group) => (
          <section key={group.key} className="group">
            <h3>{group.label}</h3>
            <div className="card list">
              {group.items.map((m) => (
                <Link key={m.player.id} to={`/players/${m.player.id}`} className="squad-row">
                  <span className="shirt">{m.shirt_number ?? "-"}</span>
                  <span>{m.player.name}</span>
                </Link>
              ))}
            </div>
          </section>
        ))
      )}
    </Async>
  );
}
