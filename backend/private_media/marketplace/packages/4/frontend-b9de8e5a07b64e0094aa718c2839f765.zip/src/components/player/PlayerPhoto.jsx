import React, { useState } from "react";
import { initials } from "../../lib/player.js";

export default function PlayerPhoto({ player, size = 96 }) {
  const [failed, setFailed] = useState(false);
  const style = { width: size, height: size };
  if (!player.image || failed) {
    return <span className="portrait portrait-fallback" style={style} aria-hidden="true">{initials(player.display_name)}</span>;
  }
  return <img className="portrait" src={player.image} alt={player.display_name} style={style} loading="lazy" onError={() => setFailed(true)} />;
}
