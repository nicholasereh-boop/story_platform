import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getLiveMatches, getUpcomingMatches } from "../../api.js";
import { untilLabel } from "../../lib/team.js";
import MatchRow from "../MatchRow.jsx";

export default function NextMatch({ teamId }) {
  const live = useQuery({ queryKey: ["team", teamId, "live"], queryFn: () => getLiveMatches({ team: teamId }), refetchInterval: 30000 });
  const next = useQuery({ queryKey: ["team", teamId, "next"], queryFn: () => getUpcomingMatches({ team: teamId, page_size: 1 }) });

  const playing = live.data?.[0];
  const upcoming = next.data?.results?.[0];
  const match = playing ?? upcoming;
  if (!match) return null;
  return (
    <section>
      <div className="section-head">
        <h2>{playing ? "Playing now" : "Next match"}</h2>
        {!playing && <small className="muted">{untilLabel(match.scheduled_at)}</small>}
      </div>
      <div className="card list"><MatchRow match={match} /></div>
    </section>
  );
}
