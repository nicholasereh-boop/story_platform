import React from "react";
import { Link } from "react-router-dom";
import { useTimezone } from "../prefs/store.js";
import { hasScore, isLive, statusLabel, teamsOf } from "../lib/format.js";
import TeamLogo from "./TeamLogo.jsx";

export default function MatchRow({ match }) {
  const TZ = useTimezone();
  const { home, away } = teamsOf(match);
  const played = hasScore(match.status);
  return (
    <Link to={`/matches/${match.id}`} className="match-row">
      <span className={isLive(match.status) ? "status is-live" : "status"}>{statusLabel(match, TZ)}</span>
      <span className="team team-home"><span>{home.name}</span><TeamLogo team={home} /></span>
      <strong className="score">{played ? `${match.home_score} - ${match.away_score}` : "vs"}</strong>
      <span className="team team-away"><TeamLogo team={away} /><span>{away.name}</span></span>
    </Link>
  );
}
