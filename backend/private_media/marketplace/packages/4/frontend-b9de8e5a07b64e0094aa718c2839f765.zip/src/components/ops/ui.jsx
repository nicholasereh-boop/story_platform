import React from "react";

export function Dot({ tone = "muted", label }) {
  return <span className={`ops-dot ops-${tone}`} role="img" aria-label={label || tone} title={label || tone} />;
}

export function Stat({ label, value, tone = "muted", hint }) {
  return (
    <div className="ops-stat">
      <span className="ops-stat-label">{label}</span>
      <strong className={`ops-figure ops-${tone}`}>{value}</strong>
      {hint ? <span className="muted ops-hint">{hint}</span> : null}
    </div>
  );
}

export function Section({ title, aside, children }) {
  return (
    <section className="ops-section">
      <div className="ops-section-head">
        <h2>{title}</h2>
        {aside}
      </div>
      {children}
    </section>
  );
}
