import React, { useState } from "react";

export default function PasswordInput({ label, error, ...props }) {
  const [visible, setVisible] = useState(false);
  return (
    <label className="field">
      <span>{label}</span>
      <span className="password-wrap">
        <input {...props} type={visible ? "text" : "password"} aria-invalid={error ? "true" : undefined} />
        <button type="button" className="toggle" onClick={() => setVisible((value) => !value)} aria-pressed={visible}>
          {visible ? "Hide" : "Show"}
        </button>
      </span>
      {error && <small className="error">{error}</small>}
    </label>
  );
}
