import React from "react";
import { Link } from "react-router-dom";
import { CATEGORY_LABELS, publishedDate, safeUrl, tagLinks } from "../lib/news.js";
import { useTimezone } from "../prefs/store.js";

export default function NewsCard({ article, compact = false }) {
  const tz = useTimezone();
  const image = safeUrl(article.image);
  const tags = tagLinks(article).slice(0, 3);
  return (
    <article className={compact ? "news-card compact" : "news-card"}>
      {image && !compact && <Link to={`/news/${article.slug}`} tabIndex={-1} aria-hidden="true"><img src={image} alt="" loading="lazy" /></Link>}
      <div className="news-body">
        <small className="muted">
          {article.category === "transfer" && <span className="pill">{CATEGORY_LABELS.transfer}</span>}
          {publishedDate(article.published_at, tz)}
        </small>
        <h3><Link to={`/news/${article.slug}`}>{article.title}</Link></h3>
        {!compact && article.summary && <p>{article.summary}</p>}
        {!compact && tags.length > 0 && (
          <div className="tags">{tags.map((tag) => <Link key={tag.key} to={tag.to} className="tag">{tag.label}</Link>)}</div>
        )}
      </div>
    </article>
  );
}
