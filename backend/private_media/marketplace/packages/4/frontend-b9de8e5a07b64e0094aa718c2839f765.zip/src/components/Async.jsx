import React from "react";

export function Loading({ label = "Loading..." }) {
  return <p className="muted" role="status">{label}</p>;
}

export function ErrorBox({ error, onRetry }) {
  const status = error?.response?.status;
  const message = status === 404 ? "We could not find that." : "Something went wrong while loading this.";
  return (
    <div className="notice notice-error" role="alert">
      <span>{message}</span>
      {onRetry && status !== 404 && <button type="button" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function Empty({ children }) {
  return <p className="muted empty">{children}</p>;
}

export default function Async({ query, children }) {
  if (query.isPending) return <Loading />;
  if (query.isError) return <ErrorBox error={query.error} onRetry={query.refetch} />;
  return children(query.data);
}
