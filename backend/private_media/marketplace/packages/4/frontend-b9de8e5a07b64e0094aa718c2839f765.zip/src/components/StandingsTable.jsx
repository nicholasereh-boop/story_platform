import React from "react";
import { Link } from "react-router-dom";
import { Empty } from "./Async.jsx";
import TeamLogo from "./TeamLogo.jsx";

export default function StandingsTable({ rows, highlight = [] }) {
  if (!rows || rows.length === 0) return <Empty>No table available yet.</Empty>;
  return (
    <div className="card table-wrap">
      <table className="table">
        <thead>
          <tr><th>#</th><th className="left">Team</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GD</th><th>Pts</th></tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className={highlight.includes(row.team.id) ? "highlight" : undefined}>
              <td>{row.position}</td>
              <td className="left"><Link to={`/teams/${row.team.id}`} className="inline"><TeamLogo team={row.team} size={20} /> {row.team.name}</Link></td>
              <td>{row.played}</td><td>{row.won}</td><td>{row.drawn}</td><td>{row.lost}</td>
              <td>{row.goal_difference}</td><td><strong>{row.points}</strong></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
