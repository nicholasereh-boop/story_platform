import React from "react";

export default function Field({ label, error, ...props }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input {...props} aria-invalid={error ? "true" : undefined} />
      {error && <small className="error">{error}</small>}
    </label>
  );
}
