import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getLeagueStatistics } from "../../api.js";
import Async, { Empty } from "../Async.jsx";
import { coverageNote, shares } from "../../lib/league.js";

export function Tile({ label, value }) {
  return <div className="card stat-tile"><strong>{value}</strong><small className="muted">{label}</small></div>;
}

function Leaders({ title, rows, unit }) {
  return (
    <section>
      <h2>{title}</h2>
      {rows.length === 0 ? <Empty>No data yet.</Empty> : (
        <div className="card table-wrap">
          <table className="table">
            <thead><tr><th>#</th><th className="left">Player</th><th className="left">Team</th><th>{unit}</th></tr></thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={`${row.player.id}-${row.team?.id ?? 0}`}>
                  <td>{index + 1}</td>
                  <td className="left"><Link to={`/players/${row.player.id}`}>{row.player.name}</Link></td>
                  <td className="left">{row.team ? <Link to={`/teams/${row.team.id}`}>{row.team.name}</Link> : "-"}</td>
                  <td><strong>{row.total}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default function LeagueStats({ leagueId, season }) {
  const query = useQuery({
    queryKey: ["league", leagueId, "statistics", season],
    queryFn: () => getLeagueStatistics(leagueId, { season: season || undefined }),
    retry: false,
  });
  if (query.isError && query.error?.response?.status === 404) return <Empty>No statistics available yet.</Empty>;
  return (
    <Async query={query}>
      {(data) => {
        const s = data.summary;
        const [home, draw, away] = shares(s.home_wins, s.draws, s.away_wins);
        const note = coverageNote(data.coverage);
        return (
          <>
            <p className="muted note">Season {data.season.name}</p>
            <div className="grid stat-tiles">
              <Tile label="Matches played" value={s.played} />
              <Tile label="Goals" value={s.goals} />
              <Tile label="Goals per match" value={s.goals_per_match} />
              <Tile label="Yellow cards" value={s.yellow_cards} />
              <Tile label="Red cards" value={s.red_cards} />
            </div>
            {s.played > 0 && (
              <div className="card results-split">
                <div className="stat-line"><span>Home wins {home}%</span><span>Draws {draw}%</span><span>Away wins {away}%</span></div>
                <div className="bar split-bar"><span style={{ width: `${home}%` }} /><span className="draw" style={{ width: `${draw}%` }} /><span className="away" style={{ width: `${away}%` }} /></div>
              </div>
            )}
            <Leaders title="Top scorers" rows={data.top_scorers} unit="Goals" />
            <Leaders title="Top assists" rows={data.top_assists} unit="Assists" />
            {note && <p className="muted note">{note}</p>}
          </>
        );
      }}
    </Async>
  );
}
