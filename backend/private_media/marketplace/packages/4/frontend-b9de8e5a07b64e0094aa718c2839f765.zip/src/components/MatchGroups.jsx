import React from "react";
import { useTimezone } from "../prefs/store.js";
import { groupByDay, groupByLeague } from "../lib/format.js";
import { Empty } from "./Async.jsx";
import MatchRow from "./MatchRow.jsx";

export default function MatchGroups({ matches, by = "league", emptyText = "No matches to show." }) {
  const TZ = useTimezone();
  if (!matches || matches.length === 0) return <Empty>{emptyText}</Empty>;
  const groups = by === "day" ? groupByDay(matches, TZ) : groupByLeague(matches);
  return (
    <div className="groups">
      {groups.map((group) => (
        <section key={group.key} className="group">
          <h3>{group.label}</h3>
          <div className="card list">{group.items.map((match) => <MatchRow key={match.id} match={match} />)}</div>
        </section>
      ))}
    </div>
  );
}
