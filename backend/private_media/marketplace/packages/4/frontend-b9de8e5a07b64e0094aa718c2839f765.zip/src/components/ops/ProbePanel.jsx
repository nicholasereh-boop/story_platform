import React from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { runOpsProbe } from "../../api.js";
import { formatMs, latencyTone, probeSummary, statusTone } from "../../lib/ops.js";

export default function ProbePanel() {
  const client = useQueryClient();
  const probe = useMutation({
    mutationFn: (fresh) => runOpsProbe(fresh),
    onSuccess: () => client.invalidateQueries({ queryKey: ["ops", "endpoints"] }),
  });
  const results = probe.data?.results || [];
  const summary = probeSummary(results);
  return (
    <div className="ops-probe">
      <button type="button" disabled={probe.isPending} onClick={() => probe.mutate(false)}>
        {probe.isPending ? "Testing…" : "Test public endpoints"}
      </button>
      <button type="button" disabled={probe.isPending} onClick={() => probe.mutate(true)} title="Skips the response cache to time the real work">
        Test uncached
      </button>
      {probe.isError && <span className="ops-bad" role="alert">The test could not run.</span>}
      {results.length > 0 && (
        <details open className="card ops-probe-results">
          <summary>
            {summary.failed ? <span className="ops-bad">{summary.failed} of {summary.total} failed</span> : <span className="ops-good">All {summary.total} responded</span>}
            {summary.slowest ? <span className="muted"> · slowest {formatMs(summary.slowest.ms)}</span> : null}
          </summary>
          <table className="ops-table">
            <tbody>
              {results.map((r) => (
                <tr key={r.route}>
                  <td className="ops-route">/{r.route}</td>
                  <td className={`ops-${statusTone(r.status)}`}>{r.status}</td>
                  <td className={`ops-${latencyTone(r.ms)}`}>{formatMs(r.ms)}</td>
                  <td className="muted">{r.cache}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </details>
      )}
    </div>
  );
}
