import React from "react";

export default function Form({ results }) {
  if (!results || results.length === 0) return null;
  return (
    <span className="form-pills" aria-label={`Recent form: ${results.join(" ")}`}>
      {results.map((result, index) => <span key={index} className={`pill pill-${result}`}>{result}</span>)}
    </span>
  );
}
