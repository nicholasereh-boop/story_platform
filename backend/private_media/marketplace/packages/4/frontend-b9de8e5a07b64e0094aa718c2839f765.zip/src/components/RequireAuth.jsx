import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../auth/store.js";
import { Loading } from "./Async.jsx";

export default function RequireAuth({ children }) {
  const status = useAuth((state) => state.status);
  const location = useLocation();
  if (status === "loading") return <Loading />;
  if (status !== "authenticated") return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  return children;
}
