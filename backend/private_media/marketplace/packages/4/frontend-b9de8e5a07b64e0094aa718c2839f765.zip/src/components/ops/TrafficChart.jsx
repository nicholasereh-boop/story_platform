import React from "react";
import { chartBars, formatCount } from "../../lib/ops.js";

const W = 600;
const H = 140;

export default function TrafficChart({ hourly }) {
  const { max, bars } = chartBars(hourly, { width: W, height: H });
  if (!bars.length || max <= 1 && bars.every((b) => !b.requests)) {
    return <p className="muted empty">No traffic recorded in this window yet.</p>;
  }
  const every = Math.ceil(bars.length / 8);
  return (
    <figure className="ops-chart">
      <svg viewBox={`0 0 ${W} ${H + 22}`} role="img" aria-label={`Requests per hour, busiest hour ${max}`} preserveAspectRatio="none">
        <line x1="0" x2={W} y1={H + 0.5} y2={H + 0.5} className="ops-axis" />
        {bars.map((bar, index) => (
          <g key={index}>
            <title>{`${bar.label}: ${bar.requests} requests, ${bar.s4} client errors, ${bar.s5} server errors`}</title>
            <rect x={bar.x} y={bar.y} width={bar.width} height={bar.height} className="ops-bar" />
            {bar.clientErrorHeight > 0 && <rect x={bar.x} y={bar.y} width={bar.width} height={bar.clientErrorHeight} className="ops-bar-warn" />}
            {bar.serverErrorHeight > 0 && <rect x={bar.x} y={bar.y} width={bar.width} height={bar.serverErrorHeight} className="ops-bar-bad" />}
            {index % every === 0 && <text x={bar.x} y={H + 16} className="ops-tick">{bar.label}</text>}
          </g>
        ))}
      </svg>
      <figcaption className="muted">
        Requests per hour (UTC), busiest {formatCount(max)}. <span className="ops-key ops-key-warn" /> 4xx <span className="ops-key ops-key-bad" /> 5xx
      </figcaption>
    </figure>
  );
}
