import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getResults, getTeamStatistics } from "../../api.js";
import { ordinal } from "../../lib/team.js";
import Async from "../Async.jsx";
import MatchGroups from "../MatchGroups.jsx";
import Form from "./Form.jsx";
import NextMatch from "./NextMatch.jsx";

function Positions({ positions }) {
  if (!positions || positions.length === 0) return null;
  return (
    <section>
      <h2>League position</h2>
      <div className="grid">
        {positions.map((p) => (
          <Link key={`${p.league.id}-${p.season}`} to={`/leagues/${p.league.id}?tab=standings&season=${p.season}`} className="card position-card">
            <strong>{ordinal(p.position)}</strong>
            <span>{p.league.name}<small className="muted"> {p.season_name}</small></span>
            <small className="muted">{p.points} pts · {p.played} played</small>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default function TeamOverview({ team, onTab }) {
  const stats = useQuery({ queryKey: ["team", String(team.id), "statistics", "current"], queryFn: () => getTeamStatistics(team.id, { scope: "current" }) });
  const results = useQuery({ queryKey: ["team", String(team.id), "overview-results"], queryFn: () => getResults({ team: team.id, page_size: 5 }) });

  return (
    <>
      <NextMatch teamId={team.id} />
      <Positions positions={team.positions} />
      {stats.data?.form?.length > 0 && <p className="form-line">Form <Form results={stats.data.form} /></p>}
      <div className="section-head">
        <h2>Latest results</h2>
        <button type="button" className="link-button" onClick={() => onTab("results")}>All results</button>
      </div>
      <Async query={results}>{(d) => <MatchGroups matches={d.results} by="day" emptyText="No results yet." />}</Async>
    </>
  );
}
