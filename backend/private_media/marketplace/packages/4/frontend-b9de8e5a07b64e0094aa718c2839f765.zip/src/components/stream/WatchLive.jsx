import React, { useState } from "react";
import { EMBED_ALLOW, EMBED_SANDBOX, currentStream, hostOf, playableStreams, streamLabel } from "../../lib/stream.js";
import HlsPlayer from "./HlsPlayer.jsx";

function Embed({ stream }) {
  return (
    <div className="player-frame">
      <iframe
        src={stream.url}
        title={stream.title || "Live stream"}
        sandbox={EMBED_SANDBOX}
        allow={EMBED_ALLOW}
        allowFullScreen
        referrerPolicy="strict-origin-when-cross-origin"
        loading="lazy"
      />
    </div>
  );
}

/** "Watch live" panel. Renders nothing unless the match is in play and has at least one valid stream. */
export default function WatchLive({ match }) {
  const streams = playableStreams(match);
  const [selected, setSelected] = useState(null);
  const stream = currentStream(streams, selected);
  if (!stream) return null;

  return (
    <section className="card watch-live" aria-label="Watch live">
      <div className="section-head">
        <h2>Watch live</h2>
        {streams.length === 1 && <small className="muted">{streamLabel(stream, 0)}</small>}
      </div>
      {streams.length > 1 && (
        <div className="chips" role="tablist" aria-label="Streams">
          {streams.map((item, index) => (
            <button key={item.id} type="button" role="tab" aria-selected={item.id === stream.id} className={item.id === stream.id ? "chip active" : "chip"} onClick={() => setSelected(item.id)}>
              {streamLabel(item, index)}
            </button>
          ))}
        </div>
      )}
      {stream.kind === "hls" ? <HlsPlayer key={stream.id} src={stream.url} title={stream.title || "Live stream"} /> : <Embed key={stream.id} stream={stream} />}
      <small className="muted">{stream.credit ? `Video provided by ${stream.credit}` : `Video from ${hostOf(stream.url)}`}</small>
    </section>
  );
}
