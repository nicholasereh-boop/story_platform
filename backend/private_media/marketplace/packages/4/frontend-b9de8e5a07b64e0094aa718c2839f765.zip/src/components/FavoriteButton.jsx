import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useFavorite, useIsSignedIn } from "../favorites/hooks.js";

const NOUN = { teams: "team", leagues: "league", matches: "match" };

export default function FavoriteButton({ kind, id }) {
  const signedIn = useIsSignedIn();
  const location = useLocation();
  const { active, loading, toggle, error } = useFavorite(kind, id);

  if (!signedIn) {
    return (
      <Link to="/login" state={{ from: location.pathname + location.search }} className="fav-button" title={`Log in to follow this ${NOUN[kind]}`}>
        <span aria-hidden="true">☆</span> Follow
      </Link>
    );
  }
  return (
    <button
      type="button"
      className={active ? "fav-button is-on" : "fav-button"}
      onClick={toggle}
      disabled={loading}
      aria-pressed={active}
      title={error ? "Could not save. Try again." : undefined}
    >
      <span aria-hidden="true">{active ? "★" : "☆"}</span> {active ? "Following" : "Follow"}
    </button>
  );
}
