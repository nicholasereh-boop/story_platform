import React, { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { logout } from "../auth/session.js";
import { useAuth } from "../auth/store.js";
import { isStaff } from "../lib/ops.js";
import NotificationBell from "./NotificationBell.jsx";

const LINKS = [
  ["/", "Home"],
  ["/live", "Live"],
  ["/fixtures", "Fixtures"],
  ["/results", "Results"],
  ["/leagues", "Leagues"],
  ["/teams", "Teams"],
  ["/players", "Players"],
  ["/news", "News"],
];

export default function Layout() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const user = useAuth((state) => state.user);
  const status = useAuth((state) => state.status);
  const active = ({ isActive }) => (isActive ? "active" : undefined);

  async function signOut() {
    await logout();
    navigate("/", { replace: true });
  }

  function submit(event) {
    event.preventDefault();
    const term = q.trim();
    if (term) navigate(`/search?q=${encodeURIComponent(term)}`);
  }

  return (
    <>
      <header className="site-header">
        <div className="bar">
          <NavLink to="/" className="brand">Football Live</NavLink>
          <form onSubmit={submit} role="search" className="search-box">
            <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search teams, players, leagues, matches" aria-label="Search" />
          </form>
        </div>
        <nav className="main-nav" aria-label="Main">
          {LINKS.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => (isActive ? "active" : undefined)}>{label}</NavLink>
          ))}
          {status === "authenticated" && user ? (
            <>
              <NavLink to="/favorites" className={active}>Favorites</NavLink>
              {isStaff(user) && <NavLink to="/ops" className={active}>Admin</NavLink>}
              <NotificationBell />
              <NavLink to="/profile" className={active}>{user.username}</NavLink>
              <button type="button" className="nav-button" onClick={signOut}>Log out</button>
            </>
          ) : status === "loading" ? null : (
            <>
              <NavLink to="/login" className={active}>Log in</NavLink>
              <NavLink to="/register" className={active}>Register</NavLink>
            </>
          )}
        </nav>
      </header>
      <main><Outlet /></main>
    </>
  );
}
