import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getOpsOverview } from "../../api.js";
import {
  OVERVIEW_REFRESH_MS, errorTone, formatAge, formatCount, formatInterval, formatMs, formatPercent, latencyTone,
  overallLabel, overallTone, serviceTone, syncTone,
} from "../../lib/ops.js";
import Async from "../Async.jsx";
import { Dot, Section, Stat } from "./ui.jsx";

const SERVICE_NAMES = { database: "Database", redis: "Redis", celery: "Background workers", realtime: "Live updates server" };

function detail(service) {
  if (service.error) return service.error;
  if (service.workers !== undefined) return `${service.workers} worker${service.workers === 1 ? "" : "s"}`;
  if (service.clients !== undefined) return `${service.clients} connected`;
  return "Responding";
}

export default function OverviewTab() {
  const query = useQuery({ queryKey: ["ops", "overview"], queryFn: getOpsOverview, refetchInterval: OVERVIEW_REFRESH_MS, staleTime: 0 });
  return (
    <Async query={query}>
      {(data) => (
        <>
          <div className={`card ops-banner ops-border-${overallTone(data.status)}`}>
            <Dot tone={overallTone(data.status)} label={overallLabel(data.status)} />
            <div>
              <strong>{overallLabel(data.status)}</strong>
              <div className="muted">
                {data.problems.length ? `Needs attention: ${data.problems.join(", ")}` : "Every check is passing."}
                {!data.monitoring.enabled && " Request recording is switched off."}
              </div>
            </div>
          </div>

          <Section title="Services">
            <div className="ops-grid">
              {Object.entries(data.services).map(([key, service]) => (
                <div className="card ops-service" key={key}>
                  <Dot tone={serviceTone(service)} label={service.ok ? "Up" : "Down"} />
                  <div>
                    <strong>{SERVICE_NAMES[key] || key}</strong>
                    <div className="muted">{service.ok ? detail(service) : `Not responding${service.error ? ` (${service.error})` : ""}`}</div>
                  </div>
                  <span className={`ops-ms ops-${latencyTone(service.ms)}`}>{formatMs(service.ms)}</span>
                </div>
              ))}
              <div className="card ops-service">
                <Dot tone={data.provider.configured ? "good" : "warn"} label={data.provider.configured ? "Configured" : "Not configured"} />
                <div>
                  <strong>{data.provider.name} data provider</strong>
                  <div className="muted">{data.provider.configured ? "API token is set" : "No API token: nothing can sync"}</div>
                </div>
              </div>
            </div>
          </Section>

          <Section title="Traffic, last hour">
            <div className="card ops-stats">
              <Stat label="Requests" value={formatCount(data.last_hour.requests)} tone="muted" />
              <Stat label="Server errors" value={formatCount(data.last_hour.s5)} tone={data.last_hour.s5 ? "bad" : "good"} hint={formatPercent(data.last_hour.error_rate)} />
              <Stat label="Client errors" value={formatCount(data.last_hour.s4)} tone={data.last_hour.s4 ? "warn" : "good"} />
              <Stat label="Median" value={formatMs(data.last_hour.p50_ms)} tone={latencyTone(data.last_hour.p50_ms)} />
              <Stat label="Slowest 5%" value={formatMs(data.last_hour.p95_ms)} tone={latencyTone(data.last_hour.p95_ms)} />
              <Stat label="Cache hits" value={formatPercent(data.last_hour.cache_hit_rate)} tone="muted" />
            </div>
          </Section>

          <Section title="Data sync">
            <div className="card list ops-scroll">
              <table className="ops-table">
                <thead><tr><th>Job</th><th>Last run</th><th>Expected every</th><th>State</th></tr></thead>
                <tbody>
                  {data.syncs.map((row) => (
                    <tr key={row.name}>
                      <td>{row.name}</td>
                      <td>{formatAge(row.age_seconds)}</td>
                      <td>{formatInterval(row.expected_seconds)}</td>
                      <td><Dot tone={syncTone(row.status)} label={row.status} /> {row.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="muted ops-hint">“idle” means nothing is live right now, so the job has nothing to do.</p>
          </Section>

          <Section title="Site content">
            <div className="card ops-stats">
              {Object.entries({
                users: "Users", staff: "Staff", leagues: "Leagues", teams: "Teams", players: "Players", matches: "Matches",
                live_matches: "Live now", news: "Articles", active_streams: "Active streams",
              }).map(([key, label]) => (
                <Stat key={key} label={label} value={formatCount(data.counts[key])} tone={key === "live_matches" && data.counts[key] ? "good" : "muted"} />
              ))}
            </div>
          </Section>
          <p className="muted ops-hint">Updated {new Date(data.generated_at).toLocaleTimeString()} · refreshes every {OVERVIEW_REFRESH_MS / 1000}s</p>
        </>
      )}
    </Async>
  );
}
