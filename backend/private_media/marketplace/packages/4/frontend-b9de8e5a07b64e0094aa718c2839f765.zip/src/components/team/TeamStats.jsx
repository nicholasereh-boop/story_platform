import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getTeamStatistics } from "../../api.js";
import { shares } from "../../lib/league.js";
import Async, { Empty } from "../Async.jsx";
import { Tile } from "../league/LeagueStats.jsx";
import Form from "./Form.jsx";

const SCOPE_LABELS = { current: "Current season", all: "All matches" };

function Split({ label, record }) {
  return (
    <tr>
      <td className="left">{label}</td>
      <td>{record.played}</td><td>{record.won}</td><td>{record.drawn}</td><td>{record.lost}</td>
      <td>{record.goals_for}</td><td>{record.goals_against}</td>
    </tr>
  );
}

export default function TeamStats({ teamId }) {
  const [scope, setScope] = useState("current");
  const query = useQuery({
    queryKey: ["team", teamId, "statistics", scope],
    queryFn: () => getTeamStatistics(teamId, { scope }),
  });
  return (
    <>
      <div className="chips" role="group" aria-label="Statistics scope">
        {Object.entries(SCOPE_LABELS).map(([key, label]) => (
          <button key={key} type="button" className={scope === key ? "chip active" : "chip"} onClick={() => setScope(key)}>{label}</button>
        ))}
      </div>
      <Async query={query}>
        {(data) => {
          const o = data.overall;
          if (o.played === 0) return <Empty>No finished matches yet.</Empty>;
          const [won, drawn, lost] = shares(o.won, o.drawn, o.lost);
          return (
            <>
              {scope === "current" && data.scope.type === "all" && <p className="muted note">No current-season matches yet, so all finished matches are counted.</p>}
              <div className="grid stat-tiles">
                <Tile label="Played" value={o.played} />
                <Tile label="Goals for" value={o.goals_for} />
                <Tile label="Goals against" value={o.goals_against} />
                <Tile label="Goal difference" value={o.goal_difference} />
                <Tile label="Clean sheets" value={o.clean_sheets} />
                <Tile label="Failed to score" value={o.failed_to_score} />
                <Tile label="Scored per match" value={o.goals_per_match} />
                <Tile label="Conceded per match" value={o.conceded_per_match} />
              </div>
              <div className="card results-split">
                <div className="stat-line"><span>Won {won}%</span><span>Drawn {drawn}%</span><span>Lost {lost}%</span></div>
                <div className="bar split-bar"><span style={{ width: `${won}%` }} /><span className="draw" style={{ width: `${drawn}%` }} /><span className="lost" style={{ width: `${lost}%` }} /></div>
              </div>
              <div className="card table-wrap">
                <table className="table">
                  <thead><tr><th className="left"></th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th></tr></thead>
                  <tbody>
                    <Split label="Overall" record={o} />
                    <Split label="Home" record={data.home} />
                    <Split label="Away" record={data.away} />
                  </tbody>
                </table>
              </div>
              <p>Form: <Form results={data.form} /></p>
            </>
          );
        }}
      </Async>
    </>
  );
}
