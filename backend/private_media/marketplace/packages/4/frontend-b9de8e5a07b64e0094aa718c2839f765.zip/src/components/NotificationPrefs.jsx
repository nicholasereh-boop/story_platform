import React from "react";
import { ErrorBox, Loading } from "./Async.jsx";
import { PREF_GROUPS } from "../lib/notifications.js";
import { useNotificationPrefs, useUpdatePrefs } from "../notifications/hooks.js";

export default function NotificationPrefs() {
  const query = useNotificationPrefs();
  const update = useUpdatePrefs();
  if (query.isPending) return <Loading />;
  if (query.isError) return <ErrorBox error={query.error} onRetry={query.refetch} />;
  const prefs = query.data;

  const toggle = (field) => (
    <input type="checkbox" checked={Boolean(prefs[field])} onChange={(event) => update.mutate({ [field]: event.target.checked })} />
  );

  return (
    <section className="form">
      <h2>Notifications</h2>
      <label className="check strong">{toggle("enabled")} <span>Notifications are on</span></label>
      {PREF_GROUPS.map((group) => (
        <fieldset key={group.title} className="prefs" disabled={!prefs.enabled}>
          <legend>{group.title}</legend>
          {group.items.map((item) => (
            <label key={item.field} className="check">{toggle(item.field)} <span>{item.label}</span></label>
          ))}
        </fieldset>
      ))}
      <p className="muted">Notifications cover matches you follow, and matches of the teams and leagues you follow.</p>
      {update.isError && <p role="alert" className="error">Could not save that change.</p>}
    </section>
  );
}
