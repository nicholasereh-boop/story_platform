import React from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getResults, getUpcomingMatches } from "../../api.js";
import Async from "../Async.jsx";
import MatchGroups from "../MatchGroups.jsx";
import Pagination from "../Pagination.jsx";
import { PAGE_SIZE } from "../../lib/format.js";

export default function TeamMatches({ teamId, kind, page, onPage }) {
  const fetcher = kind === "results" ? getResults : getUpcomingMatches;
  const query = useQuery({
    queryKey: ["team", teamId, kind, page],
    queryFn: () => fetcher({ team: teamId, page }),
    placeholderData: keepPreviousData,
  });
  return (
    <Async query={query}>
      {(data) => (
        <>
          <MatchGroups matches={data.results} by="day" emptyText={kind === "results" ? "No results yet." : "No upcoming fixtures."} />
          <Pagination page={page} count={data.count} size={PAGE_SIZE} onChange={onPage} />
        </>
      )}
    </Async>
  );
}
