import React, { useState } from "react";

export default function TeamLogo({ team, size = 24 }) {
  const [failed, setFailed] = useState(false);
  const initials = (team?.name || "?").slice(0, 2).toUpperCase();
  if (!team?.logo || failed) {
    return <span className="logo logo-fallback" style={{ width: size, height: size }} aria-hidden="true">{initials}</span>;
  }
  return (
    <img className="logo" src={team.logo} alt="" width={size} height={size} loading="lazy" onError={() => setFailed(true)} />
  );
}
