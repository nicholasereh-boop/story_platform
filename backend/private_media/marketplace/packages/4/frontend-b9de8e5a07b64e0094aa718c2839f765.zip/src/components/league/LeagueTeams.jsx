import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getLeagueTeams } from "../../api.js";
import Async, { Empty } from "../Async.jsx";
import TeamLogo from "../TeamLogo.jsx";

export default function LeagueTeams({ leagueId, season }) {
  const query = useQuery({
    queryKey: ["league", leagueId, "teams", season],
    queryFn: () => getLeagueTeams(leagueId, { season: season || undefined }),
    retry: false,
  });
  if (query.isError && query.error?.response?.status === 404) return <Empty>No teams available yet.</Empty>;
  return (
    <Async query={query}>
      {(data) => data.teams.length === 0 ? <Empty>No teams available yet.</Empty> : (
        <div className="grid">
          {data.teams.map((team) => (
            <Link key={team.id} to={`/teams/${team.id}`} className="card tile">
              <TeamLogo team={team} size={36} />
              <span><strong>{team.name}</strong><small>{team.stadium}</small></span>
            </Link>
          ))}
        </div>
      )}
    </Async>
  );
}
