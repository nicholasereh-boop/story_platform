import React from "react";
import { NavLink } from "react-router-dom";

export default function AccountTabs() {
  const cls = ({ isActive }) => (isActive ? "tab active" : "tab");
  return (
    <nav className="tabs" aria-label="Account">
      <NavLink to="/profile" className={cls}>Profile</NavLink>
      <NavLink to="/settings" className={cls}>Settings</NavLink>
    </nav>
  );
}
