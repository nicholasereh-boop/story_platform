import React, { useState } from "react";
import { Link } from "react-router-dom";
import { EVENT_LABELS, eventMinute, isLive, minuteLabel, teamsOf } from "../lib/format.js";
import { eventIcon, eventText } from "../lib/live.js";
import TeamLogo from "./TeamLogo.jsx";

const PREVIEW = 5;

export default function LiveCard({ match, flash = false }) {
  const [expanded, setExpanded] = useState(false);
  const { home, away } = teamsOf(match);
  const events = match.events || [];
  const shown = expanded ? events : events.slice(-PREVIEW);
  const hidden = events.length - shown.length;

  return (
    <article className={flash ? "card live-card flash" : "card live-card"}>
      <div className="live-card-head">
        <small>{match.league?.name}</small>
        <span className={isLive(match.status) ? "status is-live" : "status"}>{minuteLabel(match)}</span>
      </div>

      <Link to={`/matches/${match.id}`} className="live-card-score">
        <span className="team team-home"><span>{home.name}</span><TeamLogo team={home} size={28} /></span>
        <strong className="score">{match.home_score} - {match.away_score}</strong>
        <span className="team team-away"><TeamLogo team={away} size={28} /><span>{away.name}</span></span>
      </Link>

      {events.length > 0 && (
        <ul className="live-events">
          {shown.map((event) => (
            <li key={event.id} className={`live-event event-${event.kind} ${event.team?.id === home.id ? "side-home" : "side-away"}`} title={EVENT_LABELS[event.type] || event.type}>
              <span className="when">{eventMinute(event)}</span>
              <span aria-hidden="true">{eventIcon(event)}</span>
              <span>{eventText(event)}</span>
            </li>
          ))}
        </ul>
      )}
      {events.length > PREVIEW && (
        <button type="button" className="link-button" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Show fewer events" : `Show ${hidden} earlier event${hidden === 1 ? "" : "s"}`}
        </button>
      )}
    </article>
  );
}
