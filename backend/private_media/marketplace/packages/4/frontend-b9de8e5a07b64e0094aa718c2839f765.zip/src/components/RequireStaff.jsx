import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../auth/store.js";
import { isStaff } from "../lib/ops.js";
import RequireAuth from "./RequireAuth.jsx";

function Forbidden() {
  return (
    <div className="card" role="alert">
      <h1>Staff only</h1>
      <p className="muted">This area is for site administrators. Your account does not have access.</p>
      <Link to="/" className="text-link">Back to the home page</Link>
    </div>
  );
}

// The server enforces this too (every /admin-panel/ call returns 403 to non-staff); this only hides the screen.
export default function RequireStaff({ children }) {
  const user = useAuth((state) => state.user);
  return <RequireAuth>{isStaff(user) ? children : <Forbidden />}</RequireAuth>;
}
