import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getOpsEndpoints } from "../../api.js";
import {
  ENDPOINTS_REFRESH_MS, METHODS, WINDOWS, errorTone, filterEndpoints, formatCount, formatMs, formatPercent, latencyTone,
  nextSort, sortEndpoints,
} from "../../lib/ops.js";
import Async from "../Async.jsx";
import ProbePanel from "./ProbePanel.jsx";
import TrafficChart from "./TrafficChart.jsx";
import { Section, Stat } from "./ui.jsx";

const COLUMNS = [
  ["method", "Method"], ["route", "Endpoint"], ["requests", "Requests"], ["error_rate", "Errors"], ["avg_ms", "Avg"],
  ["p50_ms", "p50"], ["p95_ms", "p95"], ["cache_hit_rate", "Cache"],
];

export default function EndpointsTab() {
  const [hours, setHours] = useState(24);
  const [filters, setFilters] = useState({ query: "", method: "", onlyActive: false, onlyErrors: false });
  const [sort, setSort] = useState({ key: "requests", dir: "desc" });
  const query = useQuery({
    queryKey: ["ops", "endpoints", hours], queryFn: () => getOpsEndpoints(hours),
    refetchInterval: ENDPOINTS_REFRESH_MS, staleTime: 0, placeholderData: (previous) => previous,
  });
  const rows = useMemo(
    () => sortEndpoints(filterEndpoints(query.data?.endpoints || [], filters), sort.key, sort.dir),
    [query.data, filters, sort],
  );
  const set = (patch) => setFilters((current) => ({ ...current, ...patch }));

  return (
    <>
      <div className="ops-toolbar">
        <label>Window
          <select value={hours} onChange={(event) => setHours(Number(event.target.value))}>
            {WINDOWS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </label>
        <ProbePanel />
      </div>
      <Async query={query}>
        {(data) => (
          <>
            <div className="card ops-stats">
              <Stat label="Requests" value={formatCount(data.totals.requests)} />
              <Stat label="5xx" value={formatCount(data.totals.s5)} tone={data.totals.s5 ? "bad" : "good"} hint={formatPercent(data.totals.error_rate)} />
              <Stat label="4xx" value={formatCount(data.totals.s4)} tone={data.totals.s4 ? "warn" : "good"} />
              <Stat label="Median" value={formatMs(data.totals.p50_ms)} tone={latencyTone(data.totals.p50_ms)} />
              <Stat label="p95" value={formatMs(data.totals.p95_ms)} tone={latencyTone(data.totals.p95_ms)} />
              <Stat label="Cache hits" value={formatPercent(data.totals.cache_hit_rate)} />
            </div>
            <div className="card"><TrafficChart hourly={data.hourly} /></div>

            <Section title={`Endpoints (${rows.length} of ${data.endpoints.length})`}>
              <div className="ops-filters">
                <input type="search" placeholder="Filter by path" aria-label="Filter endpoints" value={filters.query} onChange={(e) => set({ query: e.target.value })} />
                <select aria-label="Method" value={filters.method} onChange={(e) => set({ method: e.target.value })}>
                  <option value="">All methods</option>
                  {METHODS.map((m) => <option key={m}>{m}</option>)}
                </select>
                <label className="check"><input type="checkbox" checked={filters.onlyActive} onChange={(e) => set({ onlyActive: e.target.checked })} /> With traffic</label>
                <label className="check"><input type="checkbox" checked={filters.onlyErrors} onChange={(e) => set({ onlyErrors: e.target.checked })} /> With errors</label>
              </div>
              <div className="card list ops-scroll">
                <table className="ops-table">
                  <thead>
                    <tr>
                      {COLUMNS.map(([key, label]) => (
                        <th key={key} aria-sort={sort.key === key ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}>
                          <button type="button" className="ops-sort" onClick={() => setSort(nextSort(sort, key))}>
                            {label}{sort.key === key ? (sort.dir === "asc" ? " ▲" : " ▼") : ""}
                          </button>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row) => (
                      <tr key={`${row.method} ${row.route}`} className={row.requests ? undefined : "ops-idle"}>
                        <td><span className={`ops-method ops-m-${row.method}`}>{row.method}</span></td>
                        <td className="ops-route">/{row.route}</td>
                        <td>{formatCount(row.requests)}</td>
                        <td className={`ops-${errorTone(row.requests ? row.error_rate : null)}`}>
                          {row.requests ? `${row.s5 ? `${row.s5}× 5xx` : ""}${row.s5 && row.s4 ? ", " : ""}${row.s4 ? `${row.s4}× 4xx` : ""}${!row.s4 && !row.s5 ? "none" : ""}` : "–"}
                        </td>
                        <td>{formatMs(row.avg_ms)}</td>
                        <td>{formatMs(row.p50_ms)}</td>
                        <td className={`ops-${latencyTone(row.p95_ms)}`}>{formatMs(row.p95_ms)}</td>
                        <td>{formatPercent(row.cache_hit_rate)}</td>
                      </tr>
                    ))}
                    {!rows.length && <tr><td colSpan={COLUMNS.length} className="muted">No endpoints match.</td></tr>}
                  </tbody>
                </table>
              </div>
              <p className="muted ops-hint">Greyed rows are registered endpoints with no traffic in this window. Percentiles come from latency buckets, so they are approximate.</p>
            </Section>
          </>
        )}
      </Async>
    </>
  );
}
