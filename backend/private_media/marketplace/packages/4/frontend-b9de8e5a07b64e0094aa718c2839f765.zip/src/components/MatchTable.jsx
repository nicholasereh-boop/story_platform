import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getLeagueStandings } from "../api.js";
import { Empty, ErrorBox, Loading } from "./Async.jsx";
import StandingsTable from "./StandingsTable.jsx";
import { teamsOf } from "../lib/format.js";

export default function MatchTable({ match }) {
  const leagueId = match.league?.id;
  const { home, away } = teamsOf(match);
  const query = useQuery({
    queryKey: ["match", match.id, "table", leagueId, match.season],
    queryFn: () => getLeagueStandings(leagueId, { season: match.season ?? undefined }),
    enabled: Boolean(leagueId),
    retry: false,
  });

  if (!leagueId) return <Empty>This match is not part of a league table.</Empty>;
  if (query.isPending) return <Loading />;
  if (query.isError) {
    return query.error?.response?.status === 404 ? <Empty>No table available yet.</Empty> : <ErrorBox error={query.error} onRetry={query.refetch} />;
  }
  return (
    <>
      <p className="muted note">{match.league.name} · {query.data.season.name}</p>
      <StandingsTable rows={query.data.table} highlight={[home.id, away.id]} />
    </>
  );
}
