import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getPlayerStatistics } from "../../api.js";
import { minutesLabel, scopeLabel, statisticsNote, summaryTiles } from "../../lib/player.js";
import Async, { Empty } from "../Async.jsx";
import { Tile } from "../league/LeagueStats.jsx";

const SCOPES = { current: "Current season", all: "All matches" };

export default function PlayerStats({ playerId }) {
  const [scope, setScope] = useState("current");
  const query = useQuery({
    queryKey: ["player", playerId, "statistics", scope],
    queryFn: () => getPlayerStatistics(playerId, { scope }),
  });
  return (
    <section>
      <div className="section-head">
        <h2>Statistics</h2>
        <div className="chips" role="group" aria-label="Statistics scope">
          {Object.entries(SCOPES).map(([key, label]) => (
            <button key={key} type="button" className={scope === key ? "chip active" : "chip"} onClick={() => setScope(key)}>{label}</button>
          ))}
        </div>
      </div>
      <Async query={query}>
        {(data) => {
          const empty = data.competitions.length === 0;
          const note = statisticsNote(data);
          return (
            <>
              <p className="muted note">{scopeLabel(data.scope)}</p>
              {empty ? <Empty>No appearances or events recorded yet.</Empty> : (
                <>
                  <div className="grid stat-tiles">
                    {summaryTiles(data.totals).map(([label, value]) => <Tile key={label} label={label} value={value} />)}
                  </div>
                  <div className="card table-wrap">
                    <table className="table">
                      <thead><tr><th className="left">Competition</th><th>Squad</th><th>Starts</th><th>Min</th><th>G</th><th>A</th><th>YC</th><th>RC</th></tr></thead>
                      <tbody>
                        {data.competitions.map((c) => (
                          <tr key={c.league?.id ?? "other"}>
                            <td className="left">{c.league ? <Link to={`/leagues/${c.league.id}`}>{c.league.name}</Link> : "Other"}</td>
                            <td>{c.matches}</td><td>{c.starts}</td><td>{minutesLabel(c.minutes)}</td>
                            <td>{c.goals}</td><td>{c.assists}</td><td>{c.yellow_cards}</td><td>{c.red_cards}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
              {note && <p className="muted note">{note}</p>}
            </>
          );
        }}
      </Async>
    </section>
  );
}
