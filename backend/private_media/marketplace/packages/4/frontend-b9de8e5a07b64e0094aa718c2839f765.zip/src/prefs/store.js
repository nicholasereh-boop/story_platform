import { create } from "zustand";
import { normalizePrefs, parseStoredPrefs, resolveTimezone } from "../lib/prefs.js";

const KEY = "fl.prefs";

function read() {
  try {
    return parseStoredPrefs(localStorage.getItem(KEY));
  } catch {
    return normalizePrefs(null);
  }
}

function persist(prefs) {
  try {
    localStorage.setItem(KEY, JSON.stringify(prefs));
  } catch {
    /* storage unavailable: preferences just last for this visit */
  }
}

function applyTheme(theme) {
  if (typeof document === "undefined") return;
  if (theme === "light" || theme === "dark") document.documentElement.dataset.theme = theme;
  else delete document.documentElement.dataset.theme;
}

export const usePrefs = create((set, get) => ({
  ...read(),
  setPrefs(next) {
    const merged = normalizePrefs({ timezone: get().timezone, theme: get().theme, ...next });
    persist(merged);
    applyTheme(merged.theme);
    set(merged);
  },
}));

applyTheme(usePrefs.getState().theme);

export const getTZ = () => resolveTimezone(usePrefs.getState().timezone);
export const useTimezone = () => usePrefs((state) => resolveTimezone(state.timezone));
