import React, { Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import RequireAuth from "./components/RequireAuth.jsx";
import RequireStaff from "./components/RequireStaff.jsx";
import Home from "./pages/Home.jsx";

// Everything except the shell and the landing page is split into its own chunk.
const Fixtures = lazy(() => import("./pages/Fixtures.jsx"));
const Favorites = lazy(() => import("./pages/Favorites.jsx"));
const LeagueDetail = lazy(() => import("./pages/LeagueDetail.jsx"));
const Leagues = lazy(() => import("./pages/Leagues.jsx"));
const Live = lazy(() => import("./pages/Live.jsx"));
const Login = lazy(() => import("./pages/Login.jsx"));
const MatchDetail = lazy(() => import("./pages/MatchDetail.jsx"));
const News = lazy(() => import("./pages/News.jsx"));
const NewsArticle = lazy(() => import("./pages/NewsArticle.jsx"));
const Ops = lazy(() => import("./pages/Ops.jsx"));
const NotFound = lazy(() => import("./pages/NotFound.jsx"));
const Notifications = lazy(() => import("./pages/Notifications.jsx"));
const PlayerDetail = lazy(() => import("./pages/PlayerDetail.jsx"));
const Players = lazy(() => import("./pages/Players.jsx"));
const Profile = lazy(() => import("./pages/Profile.jsx"));
const Register = lazy(() => import("./pages/Register.jsx"));
const Results = lazy(() => import("./pages/Results.jsx"));
const Search = lazy(() => import("./pages/Search.jsx"));
const Settings = lazy(() => import("./pages/Settings.jsx"));
const Status = lazy(() => import("./pages/Status.jsx"));
const TeamDetail = lazy(() => import("./pages/TeamDetail.jsx"));
const Teams = lazy(() => import("./pages/Teams.jsx"));

function Loading() {
  return <p className="muted" role="status">Loading…</p>;
}

function Page({ children }) {
  return <Suspense fallback={<Loading />}>{children}</Suspense>;
}

function Private({ children }) {
  return (
    <RequireAuth>
      <Page>{children}</Page>
    </RequireAuth>
  );
}

function Staff({ children }) {
  return (
    <RequireStaff>
      <Page>{children}</Page>
    </RequireStaff>
  );
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="live" element={<Page><Live /></Page>} />
        <Route path="fixtures" element={<Page><Fixtures /></Page>} />
        <Route path="results" element={<Page><Results /></Page>} />
        <Route path="matches/:id" element={<Page><MatchDetail /></Page>} />
        <Route path="leagues" element={<Page><Leagues /></Page>} />
        <Route path="leagues/:id" element={<Page><LeagueDetail /></Page>} />
        <Route path="teams" element={<Page><Teams /></Page>} />
        <Route path="teams/:id" element={<Page><TeamDetail /></Page>} />
        <Route path="players" element={<Page><Players /></Page>} />
        <Route path="players/:id" element={<Page><PlayerDetail /></Page>} />
        <Route path="news" element={<Page><News /></Page>} />
        <Route path="news/:slug" element={<Page><NewsArticle /></Page>} />
        <Route path="search" element={<Page><Search /></Page>} />
        <Route path="register" element={<Page><Register /></Page>} />
        <Route path="login" element={<Page><Login /></Page>} />
        <Route path="profile" element={<Private><Profile /></Private>} />
        <Route path="favorites" element={<Private><Favorites /></Private>} />
        <Route path="notifications" element={<Private><Notifications /></Private>} />
        <Route path="settings" element={<Private><Settings /></Private>} />
        <Route path="ops" element={<Staff><Ops /></Staff>} />
        <Route path="status" element={<Page><Status /></Page>} />
        <Route path="*" element={<Page><NotFound /></Page>} />
      </Route>
    </Routes>
  );
}
