import { useEffect, useRef, useState } from "react";
import { changedScores, scoreMap } from "../lib/live.js";

export function useScoreFlash(matches, duration = 4000) {
  const previous = useRef(new Map());
  const [flashing, setFlashing] = useState(() => new Set());

  useEffect(() => {
    const changed = changedScores(previous.current, matches);
    previous.current = scoreMap(matches);
    if (changed.length === 0) return;
    setFlashing((current) => new Set([...current, ...changed]));
    setTimeout(() => {
      setFlashing((current) => {
        const next = new Set(current);
        for (const id of changed) next.delete(id);
        return next;
      });
    }, duration);
  }, [matches, duration]);

  return flashing;
}
