import { create } from "zustand";
import { initialState, reduce } from "./reducer.js";

const UPDATING = new Set(["snapshot", "match_update", "match_event", "event_removed"]);

export const useLiveStore = create((set, get) => ({
  ...initialState,
  connection: "connecting",
  synced: false,
  updatedAt: null,
  setConnection: (connection) => set({ connection }),
  resetSequence: () => set({ seq: 0, synced: false }),
  apply: (message) => {
    const { state, gap } = reduce({ matches: get().matches, seq: get().seq }, message);
    const extra = {};
    if (!gap && message && UPDATING.has(message.type)) extra.updatedAt = Date.now();
    if (!gap && message?.type === "snapshot") extra.synced = true;
    set({ ...state, ...extra });
    return gap;
  },
}));
