import { useEffect, useMemo } from "react";
import { retainLive } from "./connection.js";
import { LIVE_STATUSES, sortLiveMatches } from "./reducer.js";
import { useLiveStore } from "./store.js";

export function useLiveMatches() {
  useEffect(() => retainLive(), []);
  const matches = useLiveStore((state) => state.matches);
  const connection = useLiveStore((state) => state.connection);
  const synced = useLiveStore((state) => state.synced);
  const updatedAt = useLiveStore((state) => state.updatedAt);
  const live = useMemo(
    () => sortLiveMatches(matches).filter((match) => LIVE_STATUSES.includes(match.status)),
    [matches],
  );
  return { matches: live, connection, synced, updatedAt };
}

export function useLiveOverlay(matchId, enabled) {
  useEffect(() => (enabled ? retainLive() : undefined), [enabled]);
  return useLiveStore((state) => state.matches[matchId]);
}
