export const LIVE_STATUSES = ["LIVE", "HT", "ET", "PEN"];
export const initialState = { matches: {}, seq: 0 };

const SEQUENCED = new Set(["match_update", "match_event", "event_removed"]);

function sortEvents(events) {
  return [...events].sort(
    (a, b) => (a.minute ?? 0) - (b.minute ?? 0) || (a.extra_minute ?? 0) - (b.extra_minute ?? 0) || a.id - b.id,
  );
}

function withMatch(matches, message, events) {
  const existing = matches[message.match_id];
  if (!message.match) return matches;
  const merged = { ...existing, ...message.match, events: events ?? existing?.events ?? message.match.events ?? [] };
  return { ...matches, [message.match_id]: merged };
}

function apply(state, message) {
  switch (message.type) {
    case "match_update":
      return withMatch(state.matches, message, message.events ? sortEvents(message.events) : undefined);
    case "match_event": {
      const matches = withMatch(state.matches, message);
      const match = matches[message.match_id];
      if (!match) return matches;
      const known = match.events.some((event) => event.id === message.event.id);
      if (known) return matches;
      return { ...matches, [message.match_id]: { ...match, events: sortEvents([...match.events, message.event]) } };
    }
    case "event_removed": {
      const match = state.matches[message.match_id];
      if (!match) return state.matches;
      const removed = new Set(message.event_ids);
      return {
        ...state.matches,
        [message.match_id]: { ...match, events: match.events.filter((event) => !removed.has(event.id)) },
      };
    }
    default:
      return state.matches;
  }
}

export function reduce(state, message) {
  if (!message || typeof message !== "object") return { state, gap: false };

  if (message.type === "snapshot") {
    const matches = {};
    for (const match of message.matches || []) matches[match.id] = { ...match, events: match.events || [] };
    return { state: { matches, seq: message.seq ?? 0 }, gap: false };
  }

  if (!SEQUENCED.has(message.type)) return { state, gap: false };

  if (typeof message.seq === "number") {
    if (message.seq <= state.seq) return { state, gap: false };
    if (state.seq > 0 && message.seq > state.seq + 1) return { state, gap: true };
  }
  return {
    state: { matches: apply(state, message), seq: typeof message.seq === "number" ? message.seq : state.seq },
    gap: false,
  };
}

export function sortLiveMatches(matches) {
  return Object.values(matches).sort(
    (a, b) =>
      (a.league?.name || "").localeCompare(b.league?.name || "") ||
      new Date(a.scheduled_at) - new Date(b.scheduled_at),
  );
}
