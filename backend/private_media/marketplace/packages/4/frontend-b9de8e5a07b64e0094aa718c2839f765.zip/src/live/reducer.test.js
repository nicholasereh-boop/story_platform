import test from "node:test";
import assert from "node:assert/strict";
import { initialState, reduce, sortLiveMatches } from "./reducer.js";

const match = (overrides = {}) => ({
  id: 1, provider_id: 100, league: { id: 8, name: "Premier League" },
  home: { id: 1, name: "Arsenal" }, away: { id: 2, name: "Chelsea" },
  status: "LIVE", minute: 30, home_score: 0, away_score: 0, scheduled_at: "2026-10-21T19:00:00+00:00",
  ...overrides,
});
const goal = { id: 11, type: "GOAL", kind: "goal", minute: 12, player: { id: 9, name: "Saka" } };

const snapshot = (seq = 5, matches = [match({ events: [] })]) => ({ type: "snapshot", seq, matches });

test("snapshot replaces the state and sets the sequence", () => {
  const { state, gap } = reduce(initialState, snapshot(7));
  assert.equal(gap, false);
  assert.equal(state.seq, 7);
  assert.deepEqual(state.matches[1].events, []);
});

test("match_update merges the new score and keeps events", () => {
  let { state } = reduce(initialState, snapshot(5, [match({ events: [goal] })]));
  ({ state } = reduce(state, { type: "match_update", seq: 6, match_id: 1, match: match({ home_score: 1, minute: 31 }) }));
  assert.equal(state.matches[1].home_score, 1);
  assert.equal(state.matches[1].minute, 31);
  assert.equal(state.matches[1].events.length, 1);
  assert.equal(state.seq, 6);
});

test("a newly announced match brings its events", () => {
  const { state } = reduce(initialState, {
    type: "match_update", seq: 1, match_id: 1, match: match(), events: [goal], changes: { created: true },
  });
  assert.equal(state.matches[1].events[0].player.name, "Saka");
});

test("match_event appends once and updates the score", () => {
  let { state } = reduce(initialState, snapshot(5));
  const message = { type: "match_event", seq: 6, match_id: 1, event: goal, match: match({ home_score: 1 }) };
  ({ state } = reduce(state, message));
  assert.equal(state.matches[1].home_score, 1);
  assert.equal(state.matches[1].events.length, 1);
  ({ state } = reduce(state, { ...message, seq: 7 }));
  assert.equal(state.matches[1].events.length, 1);
});

test("events stay ordered by minute", () => {
  let { state } = reduce(initialState, snapshot(1));
  const late = { id: 12, type: "YELLOW_CARD", kind: "card", minute: 40 };
  ({ state } = reduce(state, { type: "match_event", seq: 2, match_id: 1, event: late, match: match() }));
  ({ state } = reduce(state, { type: "match_event", seq: 3, match_id: 1, event: goal, match: match() }));
  assert.deepEqual(state.matches[1].events.map((e) => e.id), [11, 12]);
});

test("event_removed drops VAR-cancelled events", () => {
  let { state } = reduce(initialState, snapshot(5, [match({ events: [goal] })]));
  ({ state } = reduce(state, { type: "event_removed", seq: 6, match_id: 1, event_ids: [11] }));
  assert.equal(state.matches[1].events.length, 0);
});

test("old or duplicate messages are ignored", () => {
  let { state } = reduce(initialState, snapshot(5));
  const result = reduce(state, { type: "match_update", seq: 5, match_id: 1, match: match({ home_score: 9 }) });
  assert.equal(result.state.matches[1].home_score, 0);
  assert.equal(result.gap, false);
});

test("a skipped sequence number reports a gap and leaves the state untouched", () => {
  const { state } = reduce(initialState, snapshot(5));
  const result = reduce(state, { type: "match_update", seq: 8, match_id: 1, match: match({ home_score: 3 }) });
  assert.equal(result.gap, true);
  assert.equal(result.state.matches[1].home_score, 0);
});

test("messages before the first snapshot are applied without gap checks", () => {
  const result = reduce(initialState, { type: "match_update", seq: 42, match_id: 1, match: match() });
  assert.equal(result.gap, false);
  assert.equal(result.state.seq, 42);
});

test("unknown messages are ignored", () => {
  assert.deepEqual(reduce(initialState, { type: "connected" }).state, initialState);
  assert.deepEqual(reduce(initialState, null).state, initialState);
});

test("live matches sort by league then kickoff", () => {
  const sorted = sortLiveMatches({
    1: match({ id: 1, league: { name: "La Liga" } }),
    2: match({ id: 2, league: { name: "Bundesliga" }, scheduled_at: "2026-10-21T20:00:00+00:00" }),
    3: match({ id: 3, league: { name: "Bundesliga" }, scheduled_at: "2026-10-21T18:00:00+00:00" }),
  });
  assert.deepEqual(sorted.map((m) => m.id), [3, 2, 1]);
});
