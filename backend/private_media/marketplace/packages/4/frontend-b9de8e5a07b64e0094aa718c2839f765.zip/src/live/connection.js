import { connectLive } from "../ws";
import { useLiveStore } from "./store.js";

let stop = null;
let users = 0;

export function retainLive() {
  users += 1;
  if (!stop) {
    const { apply, setConnection, resetSequence } = useLiveStore.getState();
    stop = connectLive(
      (message) => {
        if (apply(message)) stop?.reconnect();
      },
      (status) => {
        setConnection(status);
        if (status === "open") resetSequence();
      },
    );
  }
  return () => {
    users -= 1;
    if (users === 0 && stop) {
      stop();
      stop = null;
    }
  };
}
