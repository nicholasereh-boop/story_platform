import axios from "axios";
import { useAuth } from "./auth/store.js";
import { getTZ } from "./prefs/store.js";

export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1" });

export { getTZ };

api.interceptors.request.use((config) => {
  const { access } = useAuth.getState();
  if (access && !config.headers.Authorization) config.headers.Authorization = `Bearer ${access}`;
  return config;
});

let refreshing = null;

function refreshAccessToken() {
  const { refresh } = useAuth.getState();
  if (!refresh) return Promise.reject(new Error("No refresh token"));
  if (!refreshing) {
    refreshing = axios
      .post(`${api.defaults.baseURL}/token/refresh/`, { refresh })
      .then(({ data }) => {
        useAuth.getState().setTokens(data.access, data.refresh || refresh);
        return data.access;
      })
      .finally(() => {
        refreshing = null;
      });
  }
  return refreshing;
}

const AUTH_CALLS = /\/(token|auth\/(register|logout))\/$/;

// An expired access token is replaced once, transparently; a dead refresh token signs the user out.
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const { config, response } = error;
    const canRetry =
      response?.status === 401 && config && !config._retried && !AUTH_CALLS.test(config.url || "") && useAuth.getState().refresh;
    if (!canRetry) throw error;
    config._retried = true;
    try {
      const access = await refreshAccessToken();
      config.headers.Authorization = `Bearer ${access}`;
    } catch (refreshError) {
      if (refreshError?.response?.status === 401) useAuth.getState().clear();
      throw error;
    }
    return api(config);
  },
);

const get = async (url, params) => (await api.get(url, { params })).data;

export const getMatches = (params) => get("/matches/", params);
export const getLiveMatches = (params) => get("/matches/live/", params);
export const getTodayMatches = (params) => get("/matches/today/", { tz: getTZ(), ...params });
export const getUpcomingMatches = (params) => get("/matches/upcoming/", params);
export const getResults = (params) => get("/matches/results/", params);
export const getMatch = (id) => get(`/matches/${id}/`);
export const getH2H = (id, params) => get(`/matches/${id}/h2h/`, params);

export const getLeagues = (params) => get("/leagues/", params);
export const getLeague = (id) => get(`/leagues/${id}/`);
export const getLeagueStandings = (id, params) => get(`/leagues/${id}/standings/`, params);

export const getLeagueTeams = (id, params) => get(`/leagues/${id}/teams/`, params);
export const getLeagueStatistics = (id, params) => get(`/leagues/${id}/statistics/`, params);
export const getSeasons = (params) => get("/seasons/", params);

export const getTeams = (params) => get("/teams/", params);
export const getTeam = (id) => get(`/teams/${id}/`);
export const getSquad = (id) => get(`/teams/${id}/squad/`);
export const getTeamStatistics = (id, params) => get(`/teams/${id}/statistics/`, params);

export const getPlayers = (params) => get("/players/", params);
export const getPlayer = (id) => get(`/players/${id}/`);
export const getPlayerStatistics = (id, params) => get(`/players/${id}/statistics/`, params);

export const search = (params) => get("/search/", params);

export async function register(data) {
  return (await api.post("/auth/register/", data)).data;
}

export const loginRequest = async (username, password) => (await api.post("/token/", { username, password })).data;
export const getMe = () => get("/auth/me/");
export const updateMe = async (data) => (await api.patch("/auth/me/", data)).data;
export const updateSettings = async (data) => (await api.patch("/auth/me/settings/", data)).data;
export const changePasswordRequest = async (data) => (await api.post("/auth/me/password/", data)).data;
export const logoutRequest = (refresh) => api.post("/auth/logout/", { refresh });

export async function getHealth() {
  try {
    return (await api.get("/health/")).data;
  } catch (err) {
    return err.response?.data || { status: "unreachable" };
  }
}

export const getFavorites = () => get("/my/favorites/");
export const getFavoriteIds = () => get("/my/favorites/ids/");
export const addFavorite = async (kind, id) => (await api.put(`/my/favorites/${kind}/${id}/`)).data;
export const removeFavorite = (kind, id) => api.delete(`/my/favorites/${kind}/${id}/`);

export const getNotifications = (params) => get("/my/notifications/", params);
export const getUnreadCount = () => get("/my/notifications/unread-count/");
export const markNotificationsRead = async (payload) => (await api.post("/my/notifications/read/", payload)).data;
export const deleteNotification = (id) => api.delete(`/my/notifications/${id}/`);
export const getNotificationPrefs = () => get("/my/notifications/preferences/");
export const updateNotificationPrefs = async (data) => (await api.patch("/my/notifications/preferences/", data)).data;

export const getNews = (params) => get("/news/", params);
export const getArticle = (slug) => get(`/news/${encodeURIComponent(slug)}/`);

// Staff monitoring (403 for anyone who is not staff).
export const getOpsOverview = () => get("/admin-panel/overview/");
export const getOpsEndpoints = (hours) => get("/admin-panel/endpoints/", { hours });
export const getOpsErrors = () => get("/admin-panel/errors/");
export const runOpsProbe = async (fresh = false) => (await api.post("/admin-panel/probe/", { fresh })).data;
