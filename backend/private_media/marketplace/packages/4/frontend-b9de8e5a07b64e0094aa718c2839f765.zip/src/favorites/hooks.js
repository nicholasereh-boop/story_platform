import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { addFavorite, getFavoriteIds, getFavorites, removeFavorite } from "../api.js";
import { useAuth } from "../auth/store.js";
import { emptyIds, hasFavorite, withFavorite, withoutFavorite } from "../lib/favorites.js";

const IDS_KEY = ["favorites", "ids"];
const LIST_KEY = ["favorites", "list"];

export function useIsSignedIn() {
  return useAuth((state) => state.status === "authenticated");
}

export function useFavoriteIds() {
  const signedIn = useIsSignedIn();
  return useQuery({ queryKey: IDS_KEY, queryFn: getFavoriteIds, enabled: signedIn, staleTime: 60000 });
}

export function useFavorites() {
  const signedIn = useIsSignedIn();
  return useQuery({ queryKey: LIST_KEY, queryFn: getFavorites, enabled: signedIn });
}

// Optimistic follow/unfollow: the star flips at once and flips back if the server refuses.
export function useFavorite(kind, id) {
  const queryClient = useQueryClient();
  const ids = useFavoriteIds();
  const active = hasFavorite(ids.data, kind, id);

  const mutation = useMutation({
    mutationFn: (on) => (on ? addFavorite(kind, id) : removeFavorite(kind, id)),
    onMutate: async (on) => {
      await queryClient.cancelQueries({ queryKey: IDS_KEY });
      const previous = queryClient.getQueryData(IDS_KEY) ?? emptyIds();
      queryClient.setQueryData(IDS_KEY, withFavorite(previous, kind, id, on));
      if (!on) queryClient.setQueryData(LIST_KEY, (list) => (list ? withoutFavorite(list, kind, id) : list));
      return { previous };
    },
    onError: (_error, _on, context) => queryClient.setQueryData(IDS_KEY, context?.previous),
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: IDS_KEY });
      queryClient.invalidateQueries({ queryKey: LIST_KEY });
    },
  });

  return { active, loading: ids.isPending && ids.fetchStatus !== "idle", toggle: () => mutation.mutate(!active), error: mutation.isError };
}
