import { QueryClient } from "@tanstack/react-query";
import { useAuth } from "./auth/store.js";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 15000,
      refetchOnWindowFocus: false,
      retry: (count, error) => error?.response?.status !== 404 && count < 2,
    },
  },
});

// Per-user data must never outlive the user: drop it on logout, session expiry or account switch.
useAuth.subscribe((state, previous) => {
  if (previous.user?.id !== state.user?.id) {
    queryClient.removeQueries({ queryKey: ["favorites"] });
    queryClient.removeQueries({ queryKey: ["notifications"] });
  }
});
