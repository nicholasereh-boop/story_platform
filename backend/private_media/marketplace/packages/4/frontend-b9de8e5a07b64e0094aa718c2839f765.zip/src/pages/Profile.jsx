import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { logout, saveAccount } from "../auth/session.js";
import { useAuth } from "../auth/store.js";
import AccountTabs from "../components/AccountTabs.jsx";
import Field from "../components/Field.jsx";
import { fieldErrors, messageFrom } from "../lib/errors.js";

export default function Profile() {
  const navigate = useNavigate();
  const user = useAuth((state) => state.user);
  const [form, setForm] = useState({ username: user.username, email: user.email });
  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => setForm({ username: user.username, email: user.email }), [user.username, user.email]);

  const dirty = form.username.trim() !== user.username || form.email.trim().toLowerCase() !== user.email;
  const set = (field) => (event) => {
    setSaved(false);
    setForm({ ...form, [field]: event.target.value });
  };

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      await saveAccount({ username: form.username.trim(), email: form.email.trim() });
      setSaved(true);
    } catch (err) {
      const found = fieldErrors(err);
      setErrors(Object.keys(found).length ? found : { form: messageFrom(err) });
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    await logout();
    navigate("/", { replace: true });
  }

  return (
    <>
      <h1>Your account</h1>
      <AccountTabs />
      <form onSubmit={submit} className="form">
        <Field label="Username" value={form.username} onChange={set("username")} error={errors.username} required autoComplete="username" />
        <Field label="Email" type="email" value={form.email} onChange={set("email")} error={errors.email} required autoComplete="email" />
        <p className="muted">Member since {new Date(user.date_joined).toLocaleDateString(undefined, { dateStyle: "long" })}</p>
        <button disabled={busy || !dirty}>{busy ? "Saving..." : "Save changes"}</button>
        {saved && <p role="status" className="ok">Saved.</p>}
        {errors.form && <p role="alert" className="error">{errors.form}</p>}
      </form>
      <h2>Session</h2>
      <button type="button" className="secondary" onClick={signOut}>Log out</button>
    </>
  );
}
