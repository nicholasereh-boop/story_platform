import React, { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { changePassword, saveSettings } from "../auth/session.js";
import AccountTabs from "../components/AccountTabs.jsx";
import NotificationPrefs from "../components/NotificationPrefs.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import { fieldErrors, messageFrom } from "../lib/errors.js";
import { THEMES, THEME_LABELS, detectTimezone, resolveTimezone, timezoneOptions } from "../lib/prefs.js";
import { usePrefs } from "../prefs/store.js";

function Preferences() {
  const queryClient = useQueryClient();
  const prefs = usePrefs();
  const zones = useMemo(timezoneOptions, []);
  const [state, setState] = useState({ busy: false, saved: false, error: "" });

  async function save(changes) {
    setState({ busy: true, saved: false, error: "" });
    try {
      await saveSettings(changes);
      // Kick-off times and "today" depend on the zone, so refetch what is on screen.
      if ("timezone" in changes) await queryClient.invalidateQueries();
      setState({ busy: false, saved: true, error: "" });
    } catch (err) {
      setState({ busy: false, saved: false, error: messageFrom(err) });
    }
  }

  return (
    <section className="form">
      <h2>Preferences</h2>
      <label className="field">
        <span>Time zone</span>
        <select value={prefs.timezone} disabled={state.busy} onChange={(event) => save({ timezone: event.target.value })}>
          <option value="">Use my device ({detectTimezone()})</option>
          {zones.map((zone) => <option key={zone} value={zone}>{zone}</option>)}
        </select>
        <small className="muted">Kick-off times are shown in {resolveTimezone(prefs.timezone)}.</small>
      </label>
      <label className="field">
        <span>Theme</span>
        <select value={prefs.theme} disabled={state.busy} onChange={(event) => save({ theme: event.target.value })}>
          {THEMES.map((theme) => <option key={theme} value={theme}>{THEME_LABELS[theme]}</option>)}
        </select>
      </label>
      {state.saved && <p role="status" className="ok">Saved.</p>}
      {state.error && <p role="alert" className="error">{state.error}</p>}
    </section>
  );
}

function PasswordForm() {
  const empty = { current: "", next: "", confirm: "" };
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (field) => (event) => {
    setDone(false);
    setForm({ ...form, [field]: event.target.value });
  };

  async function submit(event) {
    event.preventDefault();
    setDone(false);
    if (form.next !== form.confirm) {
      setErrors({ confirm: "The two passwords do not match." });
      return;
    }
    setBusy(true);
    setErrors({});
    try {
      await changePassword(form.current, form.next);
      setForm(empty);
      setDone(true);
    } catch (err) {
      const found = fieldErrors(err);
      setErrors({
        current: found.current_password,
        next: found.new_password,
        form: found.form || (Object.keys(found).length ? undefined : messageFrom(err)),
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="form">
      <h2>Change password</h2>
      <PasswordInput label="Current password" value={form.current} onChange={set("current")} error={errors.current} required autoComplete="current-password" />
      <PasswordInput label="New password (8+ characters)" value={form.next} onChange={set("next")} error={errors.next} required minLength={8} autoComplete="new-password" />
      <PasswordInput label="Repeat new password" value={form.confirm} onChange={set("confirm")} error={errors.confirm} required minLength={8} autoComplete="new-password" />
      <button disabled={busy}>{busy ? "Updating..." : "Update password"}</button>
      {done && <p role="status" className="ok">Password updated. Your other devices were signed out.</p>}
      {errors.form && <p role="alert" className="error">{errors.form}</p>}
    </form>
  );
}

export default function Settings() {
  return (
    <>
      <h1>Settings</h1>
      <AccountTabs />
      <Preferences />
      <NotificationPrefs />
      <PasswordForm />
    </>
  );
}
