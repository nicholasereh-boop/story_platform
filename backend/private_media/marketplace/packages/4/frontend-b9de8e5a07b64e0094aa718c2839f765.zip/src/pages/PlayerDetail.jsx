import React from "react";
import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getPlayer } from "../api.js";
import Async from "../components/Async.jsx";
import PlayerPhoto from "../components/player/PlayerPhoto.jsx";
import PlayerStats from "../components/player/PlayerStats.jsx";
import RelatedNews from "../components/RelatedNews.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { ageText } from "../lib/player.js";

function Facts({ player }) {
  const facts = [
    ["Position", player.position],
    ["Nationality", player.nationality],
    ["Age", ageText(player.age)],
    ["Born", player.date_of_birth],
    ["Shirt number", player.shirt_number],
  ].filter(([, value]) => value);
  return (
    <dl className="facts facts-row">
      {facts.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
      {player.current_team && (
        <div>
          <dt>Team</dt>
          <dd><Link to={`/teams/${player.current_team.id}`} className="inline"><TeamLogo team={player.current_team} size={20} /> {player.current_team.name}</Link></dd>
        </div>
      )}
    </dl>
  );
}

export default function PlayerDetail() {
  const { id } = useParams();
  const query = useQuery({ queryKey: ["player", id], queryFn: () => getPlayer(id), staleTime: 300000 });
  return (
    <Async query={query}>
      {(player) => (
        <>
          <section className="card team-profile">
            <PlayerPhoto player={player} size={112} />
            <div>
              <h1>{player.display_name}</h1>
              <Facts player={player} />
            </div>
          </section>
          <PlayerStats playerId={id} />
          <RelatedNews filter="player" id={id} />
        </>
      )}
    </Async>
  );
}
