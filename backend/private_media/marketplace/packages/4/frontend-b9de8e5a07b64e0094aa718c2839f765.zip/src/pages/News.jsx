import React from "react";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { getNews } from "../api.js";
import { Empty, ErrorBox, Loading } from "../components/Async.jsx";
import NewsCard from "../components/NewsCard.jsx";
import Pagination from "../components/Pagination.jsx";
import { CATEGORIES, newsCategory } from "../lib/news.js";
import { useListParams } from "../lib/useListParams.js";

const PAGE_SIZE = 12;

export default function News() {
  const { params, page, update } = useListParams();
  const category = newsCategory(params.get("category"));
  const query = useQuery({
    queryKey: ["news", "list", { page, category }],
    queryFn: () => getNews({ page, page_size: PAGE_SIZE, category: category || undefined }),
    placeholderData: keepPreviousData,
  });

  return (
    <>
      <div className="page-head"><h1>News</h1></div>
      <div className="chips" role="tablist" aria-label="News category">
        {CATEGORIES.map(([key, label]) => (
          <button key={key || "all"} type="button" role="tab" aria-selected={category === key} className={category === key ? "chip active" : "chip"} onClick={() => update({ category: key })}>{label}</button>
        ))}
      </div>
      {query.isPending ? <Loading />
        : query.isError ? <ErrorBox error={query.error} onRetry={query.refetch} />
        : query.data.results.length === 0 ? <Empty>No articles yet.</Empty>
        : (
          <>
            <div className="news-grid">{query.data.results.map((article) => <NewsCard key={article.id} article={article} />)}</div>
            <Pagination page={page} count={query.data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
    </>
  );
}
