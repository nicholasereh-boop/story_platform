import React, { useEffect, useState } from "react";
import { getHealth } from "../api.js";
import { connectLive } from "../ws.js";

export default function Status() {
  const [health, setHealth] = useState(null);
  const [socket, setSocket] = useState("connecting");
  const [last, setLast] = useState(null);
  useEffect(() => {
    getHealth().then(setHealth);
    return connectLive(setLast, setSocket);
  }, []);
  return (
    <>
      <h1>System status</h1>
      <div className="grid">
        <article className="card">
          <small>Django API</small>
          <h3>{health ? health.status : "checking..."}</h3>
          {health?.checks && Object.entries(health.checks).map(([k, v]) => <p key={k}>{k}: {v.ok ? "ok" : "failed"}</p>)}
        </article>
        <article className="card">
          <small>Node WebSocket</small>
          <h3>{socket}</h3>
          <p>{last ? JSON.stringify(last) : "No messages yet."}</p>
        </article>
      </div>
    </>
  );
}
