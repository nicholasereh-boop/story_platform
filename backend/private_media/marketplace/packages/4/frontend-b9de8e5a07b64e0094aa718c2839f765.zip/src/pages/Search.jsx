import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { search } from "../api.js";
import { Empty, ErrorBox, Loading } from "../components/Async.jsx";
import Highlight from "../components/Highlight.jsx";
import MatchRow from "../components/MatchRow.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { useListParams } from "../lib/useListParams.js";
import { useDebounced } from "../lib/useDebounced.js";
import {
  TYPES, TYPE_LABELS, cleanQuery, isSearchable, parseType, requestFor, totalCount, visibleTypes,
} from "../lib/search.js";

const ROWS = {
  teams: (t, q) => (
    <Link key={t.id} to={`/teams/${t.id}`} className="squad-row inline">
      <TeamLogo team={t} size={20} /> <Highlight text={t.name} query={q} />
      {t.country && <small className="muted">{t.country}</small>}
    </Link>
  ),
  players: (p, q) => (
    <Link key={p.id} to={`/players/${p.id}`} className="squad-row">
      <span><Highlight text={p.display_name} query={q} /></span>
      <small className="muted">{[p.position, p.current_team?.name].filter(Boolean).join(" · ")}</small>
    </Link>
  ),
  leagues: (l, q) => (
    <Link key={l.id} to={`/leagues/${l.id}`} className="squad-row">
      <span><Highlight text={l.name} query={q} /></span>
      <small className="muted">{l.country}</small>
    </Link>
  ),
  matches: (m) => <MatchRow key={m.id} match={m} />,
};

export default function Search() {
  const { params, update } = useListParams();
  const urlQuery = params.get("q") || "";
  const type = parseType(params.get("type"));
  const [text, setText] = useState(urlQuery);

  // Follow the URL when it changes from elsewhere (header search box, back button).
  useEffect(() => setText(urlQuery), [urlQuery]);

  const q = cleanQuery(useDebounced(text));
  const enabled = isSearchable(q);

  useEffect(() => {
    if (q !== cleanQuery(urlQuery)) update({ q });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const query = useQuery({
    queryKey: ["search", q, type],
    queryFn: () => search({ q, ...requestFor(type) }),
    enabled,
    staleTime: 60000,
    placeholderData: keepPreviousData,
  });

  const data = query.data;
  const shown = visibleTypes(data, type);

  return (
    <>
      <div className="page-head"><h1>Search</h1></div>
      <input
        className="search-input"
        type="search"
        autoFocus
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder="Teams, players, leagues, or a match like Arsenal v Chelsea"
        aria-label="Search"
      />
      <div className="chips" role="tablist" aria-label="Result type">
        {["all", ...TYPES].map((name) => (
          <button
            key={name}
            type="button"
            role="tab"
            aria-selected={type === name}
            className={type === name ? "chip active" : "chip"}
            onClick={() => update({ type: name === "all" ? "" : name })}
          >
            {name === "all" ? "All" : TYPE_LABELS[name]}
            {type === "all" && data?.results?.[name] ? <span className="count">{data.results[name].length}{data.has_more[name] ? "+" : ""}</span> : null}
          </button>
        ))}
      </div>

      {!enabled ? <Empty>Type at least two characters.</Empty>
        : query.isPending ? <Loading label="Searching..." />
        : query.isError ? <ErrorBox error={query.error} onRetry={query.refetch} />
        : totalCount(data) === 0 ? <Empty>Nothing found for "{data.query}".</Empty>
        : shown.map((name) => {
          const rows = data.results[name];
          if (rows.length === 0) return null;
          return (
            <section key={name}>
              <div className="section-head">
                <h2>{TYPE_LABELS[name]}</h2>
                {type === "all" && data.has_more[name] && (
                  <button type="button" className="link-button" onClick={() => update({ type: name })}>Show all</button>
                )}
              </div>
              <div className="card list">{rows.map((row) => ROWS[name](row, data.query))}</div>
              {type !== "all" && data.has_more[name] && <p className="muted">Showing the first {rows.length}. Refine your search to narrow it down.</p>}
            </section>
          );
        })}
    </>
  );
}
