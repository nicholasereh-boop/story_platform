import React from "react";
import { Link } from "react-router-dom";
import { Empty, ErrorBox, Loading } from "../components/Async.jsx";
import FavoriteButton from "../components/FavoriteButton.jsx";
import MatchRow from "../components/MatchRow.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { useFavorites } from "../favorites/hooks.js";
import { KIND_LABELS, totalFavorites } from "../lib/favorites.js";

function Section({ kind, rows, children }) {
  if (rows.length === 0) return null;
  return (
    <section>
      <h2>{KIND_LABELS[kind]}</h2>
      <div className="card list">{children}</div>
    </section>
  );
}

export default function Favorites() {
  const query = useFavorites();
  if (query.isPending) return <Loading />;
  if (query.isError) return <><h1>Favorites</h1><ErrorBox error={query.error} onRetry={query.refetch} /></>;
  const data = query.data;

  return (
    <>
      <h1>Favorites</h1>
      {totalFavorites(data) === 0 ? (
        <Empty>
          You are not following anything yet. Use the Follow button on a <Link to="/teams" className="text-link">team</Link>,{" "}
          <Link to="/leagues" className="text-link">league</Link> or match page.
        </Empty>
      ) : (
        <>
          <Section kind="matches" rows={data.matches}>
            {data.matches.map((match) => (
              <div key={match.id} className="fav-row">
                <MatchRow match={match} />
                <FavoriteButton kind="matches" id={match.id} />
              </div>
            ))}
          </Section>
          <Section kind="teams" rows={data.teams}>
            {data.teams.map((team) => (
              <div key={team.id} className="fav-row">
                <Link to={`/teams/${team.id}`} className="squad-row inline"><TeamLogo team={team} size={20} /> {team.name}</Link>
                <FavoriteButton kind="teams" id={team.id} />
              </div>
            ))}
          </Section>
          <Section kind="leagues" rows={data.leagues}>
            {data.leagues.map((league) => (
              <div key={league.id} className="fav-row">
                <Link to={`/leagues/${league.id}`} className="squad-row">
                  <span>{league.name}</span><small className="muted">{league.country}</small>
                </Link>
                <FavoriteButton kind="leagues" id={league.id} />
              </div>
            ))}
          </Section>
        </>
      )}
    </>
  );
}
