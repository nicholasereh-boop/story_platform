import React from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getLeagues } from "../api.js";
import Async from "../components/Async.jsx";
import { Empty } from "../components/Async.jsx";
import Pagination from "../components/Pagination.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { PAGE_SIZE } from "../lib/format.js";
import { useListParams } from "../lib/useListParams.js";

export default function Leagues() {
  const { params, page, update } = useListParams();
  const q = params.get("q") || "";
  const query = useQuery({
    queryKey: ["leagues", page, q],
    queryFn: () => getLeagues({ page, search: q || undefined }),
    placeholderData: keepPreviousData,
  });
  return (
    <>
      <div className="page-head">
        <h1>Leagues</h1>
        <input type="search" value={q} onChange={(e) => update({ q: e.target.value })} placeholder="Filter leagues" aria-label="Filter leagues" />
      </div>
      <Async query={query}>
        {(data) => (
          <>
            {data.results.length === 0 ? <Empty>No leagues found.</Empty> : (
              <div className="grid">
                {data.results.map((league) => (
                  <Link key={league.id} to={`/leagues/${league.id}`} className="card tile">
                    <TeamLogo team={league} size={36} />
                    <span><strong>{league.name}</strong><small>{league.country}</small></span>
                  </Link>
                ))}
              </div>
            )}
            <Pagination page={page} count={data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
      </Async>
    </>
  );
}
