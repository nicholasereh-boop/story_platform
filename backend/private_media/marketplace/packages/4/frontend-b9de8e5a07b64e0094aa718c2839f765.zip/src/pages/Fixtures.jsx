import React from "react";
import { getUpcomingMatches } from "../api.js";
import MatchListPage from "./MatchListPage.jsx";

export default function Fixtures() {
  return <MatchListPage title="Fixtures" name="fixtures" fetcher={getUpcomingMatches} by="day" emptyText="No upcoming fixtures." />;
}
