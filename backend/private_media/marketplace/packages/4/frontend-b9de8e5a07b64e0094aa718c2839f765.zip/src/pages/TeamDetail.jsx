import React from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getTeam } from "../api.js";
import Async from "../components/Async.jsx";
import FavoriteButton from "../components/FavoriteButton.jsx";
import RelatedNews from "../components/RelatedNews.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import TeamMatches from "../components/team/TeamMatches.jsx";
import TeamOverview from "../components/team/TeamOverview.jsx";
import TeamSquad from "../components/team/TeamSquad.jsx";
import TeamStats from "../components/team/TeamStats.jsx";
import { TEAM_TABS, teamTab } from "../lib/team.js";
import { useListParams } from "../lib/useListParams.js";

function Profile({ team }) {
  const facts = [
    ["Country", team.country],
    ["Stadium", team.stadium],
    ["Founded", team.founded],
    ["Short name", team.short_name && team.short_name !== team.name ? team.short_name : null],
  ].filter(([, value]) => value);
  return (
    <section className="card team-profile">
      <TeamLogo team={team} size={72} />
      <div>
        <h1>{team.name}</h1>
        <FavoriteButton kind="teams" id={team.id} />
        <dl className="facts facts-row">
          {facts.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
        </dl>
      </div>
    </section>
  );
}

export default function TeamDetail() {
  const { id } = useParams();
  const { params, page, update } = useListParams();
  const tab = teamTab(params.get("tab"));
  const query = useQuery({ queryKey: ["team", id], queryFn: () => getTeam(id), staleTime: 300000 });

  return (
    <Async query={query}>
      {(team) => (
        <>
          <Profile team={team} />
          <div className="tabs" role="tablist">
            {TEAM_TABS.map(([key, label]) => (
              <button key={key} type="button" role="tab" aria-selected={tab === key} className={tab === key ? "tab active" : "tab"} onClick={() => update({ tab: key === "overview" ? "" : key })}>{label}</button>
            ))}
          </div>
          {tab === "overview" && <TeamOverview team={team} onTab={(key) => update({ tab: key })} />}
          {tab === "fixtures" && <TeamMatches teamId={id} kind="fixtures" page={page} onPage={(p) => update({ page: p })} />}
          {tab === "results" && <TeamMatches teamId={id} kind="results" page={page} onPage={(p) => update({ page: p })} />}
          {tab === "squad" && <TeamSquad teamId={id} />}
          {tab === "statistics" && <TeamStats teamId={id} />}
          {tab === "overview" && <RelatedNews filter="team" id={id} />}
        </>
      )}
    </Async>
  );
}
