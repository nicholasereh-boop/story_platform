import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { signUp } from "../auth/session.js";
import { useAuth } from "../auth/store.js";
import Field from "../components/Field.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import { fieldErrors, messageFrom } from "../lib/errors.js";

export default function Register() {
  const navigate = useNavigate();
  const status = useAuth((state) => state.status);
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (field) => (event) => setForm({ ...form, [field]: event.target.value });

  if (status === "authenticated") return <Navigate to="/profile" replace />;

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      await signUp({ ...form, username: form.username.trim(), email: form.email.trim() });
      navigate("/profile", { replace: true });
    } catch (err) {
      const found = fieldErrors(err);
      setErrors(Object.keys(found).length ? found : { form: messageFrom(err, "Registration failed.") });
      setBusy(false);
    }
  }

  return (
    <>
      <h1>Create account</h1>
      <form onSubmit={submit} className="form">
        <Field label="Username" value={form.username} onChange={set("username")} error={errors.username} required autoComplete="username" />
        <Field label="Email" type="email" value={form.email} onChange={set("email")} error={errors.email} required autoComplete="email" />
        <PasswordInput label="Password (8+ characters)" value={form.password} onChange={set("password")} error={errors.password} required minLength={8} autoComplete="new-password" />
        <button disabled={busy}>{busy ? "Creating..." : "Create account"}</button>
        {errors.form && <p role="alert" className="error">{errors.form}</p>}
        <p className="muted">Already registered? <Link to="/login" className="text-link">Log in</Link></p>
      </form>
    </>
  );
}
