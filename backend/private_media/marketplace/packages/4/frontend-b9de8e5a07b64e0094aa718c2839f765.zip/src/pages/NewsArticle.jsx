import React from "react";
import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getArticle } from "../api.js";
import Async from "../components/Async.jsx";
import NewsCard from "../components/NewsCard.jsx";
import { CATEGORY_LABELS, paragraphs, publishedDate, safeUrl, tagLinks } from "../lib/news.js";
import { useTimezone } from "../prefs/store.js";

function Article({ article }) {
  const tz = useTimezone();
  const image = safeUrl(article.image);
  const source = safeUrl(article.source_url);
  const tags = tagLinks(article);
  return (
    <>
      <p><Link to="/news" className="text-link">← All news</Link></p>
      <article className="article">
        <small className="muted">
          {article.category === "transfer" && <span className="pill">{CATEGORY_LABELS.transfer}</span>}
          {publishedDate(article.published_at, tz)}
        </small>
        <h1>{article.title}</h1>
        {article.summary && <p className="lead">{article.summary}</p>}
        {image && <img src={image} alt="" className="article-image" />}
        {paragraphs(article.body).map((text, index) => <p key={index}>{text}</p>)}
        {article.source_name && (
          <p className="muted">Source: {source ? <a href={source} rel="noopener noreferrer nofollow" target="_blank" className="text-link">{article.source_name}</a> : article.source_name}</p>
        )}
        {tags.length > 0 && <div className="tags">{tags.map((tag) => <Link key={tag.key} to={tag.to} className="tag">{tag.label}</Link>)}</div>}
      </article>
      {article.related.length > 0 && (
        <section>
          <h2>Related</h2>
          <div className="news-grid">{article.related.map((item) => <NewsCard key={item.id} article={item} compact />)}</div>
        </section>
      )}
    </>
  );
}

export default function NewsArticle() {
  const { slug } = useParams();
  const query = useQuery({ queryKey: ["news", "article", slug], queryFn: () => getArticle(slug) });
  return <Async query={query}>{(article) => <Article article={article} />}</Async>;
}
