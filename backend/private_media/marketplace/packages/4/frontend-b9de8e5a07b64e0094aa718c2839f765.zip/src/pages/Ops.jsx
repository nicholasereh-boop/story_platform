import React from "react";
import { useSearchParams } from "react-router-dom";
import EndpointsTab from "../components/ops/EndpointsTab.jsx";
import ErrorsTab from "../components/ops/ErrorsTab.jsx";
import OverviewTab from "../components/ops/OverviewTab.jsx";

const TABS = [["overview", "Overview", OverviewTab], ["endpoints", "Endpoints", EndpointsTab], ["errors", "Errors", ErrorsTab]];

export default function Ops() {
  const [params, setParams] = useSearchParams();
  const current = TABS.find(([key]) => key === params.get("tab")) || TABS[0];
  const Tab = current[2];
  return (
    <div className="ops">
      <h1>Site monitor</h1>
      <div className="tabs" role="tablist">
        {TABS.map(([key, label]) => (
          <button
            key={key} type="button" role="tab" aria-selected={key === current[0]}
            className={key === current[0] ? "chip active" : "chip"}
            onClick={() => setParams(key === "overview" ? {} : { tab: key }, { replace: true })}
          >
            {label}
          </button>
        ))}
      </div>
      <Tab />
    </div>
  );
}
