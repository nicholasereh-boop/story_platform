import React from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getH2H, getMatch } from "../api.js";
import FavoriteButton from "../components/FavoriteButton.jsx";
import { useTimezone } from "../prefs/store.js";
import Async, { Empty } from "../components/Async.jsx";
import Commentary from "../components/Commentary.jsx";
import MatchRow from "../components/MatchRow.jsx";
import MatchTable from "../components/MatchTable.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { useLiveOverlay } from "../live/useLive.js";
import WatchLive from "../components/stream/WatchLive.jsx";
import { refreshInterval } from "../lib/stream.js";
import {
  EVENT_LABELS, barShare, dateHeading, eventMinute, hasScore, isLive, kickoffTime, mergeLive,
  minuteLabel, statRows, teamsOf,
} from "../lib/format.js";

const TABS = [
  ["summary", "Summary"],
  ["commentary", "Commentary"],
  ["lineups", "Lineups"],
  ["stats", "Statistics"],
  ["table", "Table"],
  ["h2h", "H2H"],
];

function Events({ match, home }) {
  const events = match.events || [];
  if (events.length === 0) return <Empty>No events yet.</Empty>;
  return (
    <ul className="card timeline">
      {events.map((e) => {
        const isHome = e.team?.id === home.id;
        return (
          <li key={e.id} className={`timeline-item event-${e.kind} ${isHome ? "side-home" : "side-away"}`}>
            <span className="when">{eventMinute(e)}</span>
            <span>
              <strong>{EVENT_LABELS[e.type] || e.type}</strong> {e.player?.name}
              {e.assist && <small className="muted"> ({e.assist.name})</small>}
            </span>
          </li>
        );
      })}
    </ul>
  );
}

function Stats({ match }) {
  const { home, away } = teamsOf(match);
  const rows = statRows(match.statistics || [], home.id, away.id);
  if (rows.length === 0) return <Empty>No statistics yet.</Empty>;
  return (
    <div className="card stats">
      <div className="stat-names"><strong>{home.name}</strong><strong>{away.name}</strong></div>
      {rows.map((row) => {
        const share = barShare(row.home, row.away);
        return (
          <div key={row.key} className="stat">
            <div className="stat-line">
              <strong>{row.home ?? "-"}{row.unit}</strong><span>{row.label}</span><strong>{row.away ?? "-"}{row.unit}</strong>
            </div>
            <div className="bar"><span style={{ width: `${share.home}%` }} /><span className="away" style={{ width: `${share.away}%` }} /></div>
          </div>
        );
      })}
    </div>
  );
}

function Lineups({ match }) {
  const { home, away } = teamsOf(match);
  const lineups = match.lineups || [];
  if (lineups.length === 0) return <Empty>Lineups are not available yet.</Empty>;
  const column = (team) => {
    const players = lineups.filter((l) => l.team?.id === team.id);
    const starters = players.filter((l) => l.starter);
    const subs = players.filter((l) => !l.starter);
    const row = (l) => (
      <Link key={l.player.id} to={`/players/${l.player.id}`} className="squad-row">
        <span className="shirt">{l.shirt_number ?? "-"}</span><span>{l.player.name}{l.captain ? " (C)" : ""}</span><small className="muted">{l.position}</small>
      </Link>
    );
    return (
      <div className="card list" key={team.id}>
        <h3>{team.name}</h3>
        {starters.map(row)}
        {subs.length > 0 && <h4>Substitutes</h4>}
        {subs.map(row)}
      </div>
    );
  };
  return <div className="grid">{column(home)}{column(away)}</div>;
}

function H2H({ id }) {
  const query = useQuery({ queryKey: ["match", id, "h2h"], queryFn: () => getH2H(id) });
  return (
    <Async query={query}>
      {(data) => (
        <>
          <div className="card h2h-summary">
            <span><strong>{data.summary.home_wins}</strong> home wins</span>
            <span><strong>{data.summary.draws}</strong> draws</span>
            <span><strong>{data.summary.away_wins}</strong> away wins</span>
          </div>
          {data.matches.length === 0 ? <Empty>These teams have not met before.</Empty> : (
            <div className="card list">{data.matches.map((m) => <MatchRow key={m.id} match={m} />)}</div>
          )}
        </>
      )}
    </Async>
  );
}

function Header({ match }) {
  const TZ = useTimezone();
  const { home, away } = teamsOf(match);
  const played = hasScore(match.status);
  const info = [
    `${dateHeading(match.scheduled_at, TZ)}, ${kickoffTime(match.scheduled_at, TZ)}`,
    match.venue,
    match.referee && `Referee: ${match.referee}`,
  ].filter(Boolean);
  return (
    <section className="card scoreboard">
      <small>{match.league?.name}{match.round ? ` · ${match.round}` : ""}</small>
      <div className="scoreboard-teams">
        <Link to={`/teams/${home.id}`} className="scoreboard-team"><TeamLogo team={home} size={56} /><span>{home.name}</span></Link>
        <div className="scoreboard-score">
          <strong>{played ? `${match.home_score} - ${match.away_score}` : kickoffTime(match.scheduled_at, TZ)}</strong>
          <span className={isLive(match.status) ? "status is-live" : "status"}>{match.status === "SCHEDULED" ? "Not started" : minuteLabel(match)}</span>
          {match.home_ht_score != null && match.status !== "SCHEDULED" && <small className="muted">HT {match.home_ht_score} - {match.away_ht_score}</small>}
        </div>
        <Link to={`/teams/${away.id}`} className="scoreboard-team"><TeamLogo team={away} size={56} /><span>{away.name}</span></Link>
      </div>
      <small className="muted">{info.join(" · ")}</small>
      <FavoriteButton kind="matches" id={match.id} />
    </section>
  );
}

export default function MatchDetail() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const tab = TABS.some(([key]) => key === params.get("tab")) ? params.get("tab") : "summary";
  const query = useQuery({
    queryKey: ["match", id],
    queryFn: () => getMatch(id),
    // Re-fetch while a stream could appear or disappear, so the player shows up without a reload.
    refetchInterval: (q) => refreshInterval(q.state.data),
  });
  const live = useLiveOverlay(id, query.data ? isLive(query.data.status) : false);

  return (
    <Async query={query}>
      {(data) => {
        const match = mergeLive(data, live);
        const { home } = teamsOf(match);
        return (
          <>
            <Header match={match} />
            <WatchLive match={match} />
            <div className="tabs" role="tablist">
              {TABS.map(([key, label]) => (
                <button key={key} type="button" role="tab" aria-selected={tab === key} className={tab === key ? "tab active" : "tab"} onClick={() => setParams(key === "summary" ? {} : { tab: key }, { replace: true })}>{label}</button>
              ))}
            </div>
            {tab === "summary" && <Events match={match} home={home} />}
            {tab === "commentary" && <Commentary match={match} />}
            {tab === "lineups" && <Lineups match={match} />}
            {tab === "stats" && <Stats match={match} />}
            {tab === "table" && <MatchTable match={match} />}
            {tab === "h2h" && <H2H id={id} />}
          </>
        );
      }}
    </Async>
  );
}
