import React from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getTeams } from "../api.js";
import Async, { Empty } from "../components/Async.jsx";
import Pagination from "../components/Pagination.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { PAGE_SIZE } from "../lib/format.js";
import { useListParams } from "../lib/useListParams.js";

export default function Teams() {
  const { params, page, update } = useListParams();
  const q = params.get("q") || "";
  const query = useQuery({
    queryKey: ["teams", page, q],
    queryFn: () => getTeams({ page, search: q || undefined }),
    placeholderData: keepPreviousData,
  });
  return (
    <>
      <div className="page-head">
        <h1>Teams</h1>
        <input type="search" value={q} onChange={(e) => update({ q: e.target.value })} placeholder="Search teams" aria-label="Search teams" />
      </div>
      <Async query={query}>
        {(data) => (
          <>
            {data.results.length === 0 ? <Empty>No teams found.</Empty> : (
              <div className="grid">
                {data.results.map((team) => (
                  <Link key={team.id} to={`/teams/${team.id}`} className="card tile">
                    <TeamLogo team={team} size={36} />
                    <span><strong>{team.name}</strong><small>{team.country}</small></span>
                  </Link>
                ))}
              </div>
            )}
            <Pagination page={page} count={data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
      </Async>
    </>
  );
}
