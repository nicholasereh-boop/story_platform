import React from "react";
import { getResults } from "../api.js";
import MatchListPage from "./MatchListPage.jsx";

export default function Results() {
  return <MatchListPage title="Results" name="results" fetcher={getResults} by="day" emptyText="No results yet." />;
}
