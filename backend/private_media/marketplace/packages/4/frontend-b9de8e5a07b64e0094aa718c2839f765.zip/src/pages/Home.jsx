import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getLiveMatches, getNews, getTodayMatches, getUpcomingMatches } from "../api.js";
import Async from "../components/Async.jsx";
import NewsCard from "../components/NewsCard.jsx";
import MatchGroups from "../components/MatchGroups.jsx";

export default function Home() {
  const live = useQuery({ queryKey: ["home", "live"], queryFn: () => getLiveMatches(), refetchInterval: 30000 });
  const today = useQuery({ queryKey: ["home", "today"], queryFn: () => getTodayMatches({ page_size: 50 }), refetchInterval: 60000 });
  const upcoming = useQuery({ queryKey: ["home", "upcoming"], queryFn: () => getUpcomingMatches({ page_size: 8 }) });

  const news = useQuery({ queryKey: ["news", "home"], queryFn: () => getNews({ page_size: 4 }), staleTime: 60000 });
  const articles = news.data?.results ?? [];

  return (
    <>
      <section className="hero">
        <h1>Football Live</h1>
        <p>Live scores, fixtures, results and tables.</p>
      </section>

      <section>
        <div className="section-head"><h2>Live now</h2><Link to="/live">Open live page</Link></div>
        <Async query={live}>{(matches) => <MatchGroups matches={matches} emptyText="No matches are live right now." />}</Async>
      </section>

      <section>
        <div className="section-head"><h2>Today</h2></div>
        <Async query={today}>{(data) => <MatchGroups matches={data.results} emptyText="No matches today." />}</Async>
      </section>

      <section>
        <div className="section-head"><h2>Coming up</h2><Link to="/fixtures">All fixtures</Link></div>
        <Async query={upcoming}>{(data) => <MatchGroups matches={data.results} by="day" emptyText="No upcoming fixtures." />}</Async>
      </section>

      {articles.length > 0 && (
        <section>
          <div className="section-head"><h2>Latest news</h2><Link to="/news">All news</Link></div>
          <div className="news-grid">{articles.map((article) => <NewsCard key={article.id} article={article} compact />)}</div>
        </section>
      )}
    </>
  );
}
