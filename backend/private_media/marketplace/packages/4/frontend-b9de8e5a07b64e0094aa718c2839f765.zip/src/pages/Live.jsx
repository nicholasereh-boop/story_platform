import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getLiveMatches } from "../api.js";
import Async, { Empty } from "../components/Async.jsx";
import LiveCard from "../components/LiveCard.jsx";
import { groupByLeague } from "../lib/format.js";
import { ageLabel, filterByLeague, leagueOptions, secondsAgo } from "../lib/live.js";
import { useLiveMatches } from "../live/useLive.js";
import { useScoreFlash } from "../live/useScoreFlash.js";

function Indicator({ connection, synced, updatedAt }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 5000);
    return () => clearInterval(timer);
  }, []);

  const connected = connection === "open" && synced;
  const label = connected ? "LIVE" : connection === "open" ? "Syncing..." : "Reconnecting...";
  const age = ageLabel(secondsAgo(updatedAt, now));
  return (
    <span className="live-indicator" role="status">
      <span className={connected ? "badge badge-open" : "badge"}>{label}</span>
      {connected && age && <small className="muted">updated {age}</small>}
      {!connected && <small className="muted">showing the latest saved scores</small>}
    </span>
  );
}

function LeagueFilter({ options, value, onChange }) {
  if (options.length < 2 && !value) return null;
  return (
    <div className="chips" role="group" aria-label="League filter">
      <button type="button" className={value ? "chip" : "chip active"} onClick={() => onChange("")}>All</button>
      {options.map((option) => (
        <button key={option.id} type="button" className={String(option.id) === value ? "chip active" : "chip"} onClick={() => onChange(String(option.id))}>
          {option.name} <span className="count">{option.count}</span>
        </button>
      ))}
    </div>
  );
}

export default function Live() {
  const { matches: streamed, connection, synced, updatedAt } = useLiveMatches();
  const [params, setParams] = useSearchParams();
  const league = params.get("league") || "";
  const streaming = connection === "open" && synced;

  // Until the socket has delivered its snapshot (or while it is down) fall back to polling the REST API.
  const fallback = useQuery({
    queryKey: ["live", "fallback"],
    queryFn: () => getLiveMatches(),
    enabled: !streaming,
    refetchInterval: streaming ? false : 15000,
  });

  const all = streaming ? streamed : fallback.data ?? streamed;
  const options = useMemo(() => leagueOptions(all), [all]);
  const visible = useMemo(() => filterByLeague(all, league), [all, league]);
  const groups = useMemo(() => groupByLeague(visible), [visible]);
  const flashing = useScoreFlash(all);

  useEffect(() => {
    document.title = all.length ? `(${all.length}) Live scores - Football Live` : "Live scores - Football Live";
    return () => { document.title = "Football Live"; };
  }, [all.length]);

  const setLeague = (value) => setParams(value ? { league: value } : {}, { replace: true });

  const body = (
    <>
      <LeagueFilter options={options} value={league} onChange={setLeague} />
      {all.length === 0 ? (
        <Empty>No matches are live right now.</Empty>
      ) : visible.length === 0 ? (
        <Empty>No live matches in this league. <button type="button" className="link-button" onClick={() => setLeague("")}>Show all</button></Empty>
      ) : (
        groups.map((group) => (
          <section key={group.key} className="group">
            <h3>{group.label}</h3>
            <div className="grid">{group.items.map((match) => <LiveCard key={match.id} match={match} flash={flashing.has(match.id)} />)}</div>
          </section>
        ))
      )}
    </>
  );

  return (
    <>
      <div className="page-head">
        <h1>Live</h1>
        <Indicator connection={connection} synced={synced} updatedAt={updatedAt} />
      </div>
      {streaming || streamed.length > 0 || fallback.data ? body : <Async query={fallback}>{() => body}</Async>}
    </>
  );
}
