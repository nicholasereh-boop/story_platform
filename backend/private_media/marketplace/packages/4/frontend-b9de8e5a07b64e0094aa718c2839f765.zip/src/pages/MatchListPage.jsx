import React from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getLeagues } from "../api.js";
import Async from "../components/Async.jsx";
import MatchGroups from "../components/MatchGroups.jsx";
import Pagination from "../components/Pagination.jsx";
import { PAGE_SIZE } from "../lib/format.js";
import { useListParams } from "../lib/useListParams.js";

export default function MatchListPage({ title, name, fetcher, by, emptyText }) {
  const { params, page, update } = useListParams();
  const league = params.get("league") || "";

  const leagues = useQuery({ queryKey: ["leagues", "all"], queryFn: () => getLeagues({ page_size: 100 }), staleTime: 300000 });
  const query = useQuery({
    queryKey: [name, page, league],
    queryFn: () => fetcher({ page, league: league || undefined }),
    placeholderData: keepPreviousData,
  });

  return (
    <>
      <div className="page-head">
        <h1>{title}</h1>
        <select value={league} onChange={(e) => update({ league: e.target.value })} aria-label="League">
          <option value="">All leagues</option>
          {(leagues.data?.results ?? []).map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </div>
      <Async query={query}>
        {(data) => (
          <>
            <MatchGroups matches={data.results} by={by} emptyText={emptyText} />
            <Pagination page={page} count={data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
      </Async>
    </>
  );
}
