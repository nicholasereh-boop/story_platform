import React, { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { login } from "../auth/session.js";
import { useAuth } from "../auth/store.js";
import Field from "../components/Field.jsx";
import PasswordInput from "../components/PasswordInput.jsx";
import { messageFrom } from "../lib/errors.js";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const status = useAuth((state) => state.status);
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (field) => (event) => setForm({ ...form, [field]: event.target.value });
  const destination = location.state?.from || "/profile";

  if (status === "authenticated") return <Navigate to={destination} replace />;

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      await login(form.identifier, form.password);
      navigate(destination, { replace: true });
    } catch (err) {
      setError(err?.response?.status === 401 ? "Wrong username/email or password." : messageFrom(err, "Could not log in."));
      setBusy(false);
    }
  }

  return (
    <>
      <h1>Log in</h1>
      <form onSubmit={submit} className="form">
        <Field label="Username or email" value={form.identifier} onChange={set("identifier")} required autoComplete="username" autoFocus />
        <PasswordInput label="Password" value={form.password} onChange={set("password")} required autoComplete="current-password" />
        <button disabled={busy}>{busy ? "Logging in..." : "Log in"}</button>
        {error && <p role="alert" className="error">{error}</p>}
        <p className="muted">New here? <Link to="/register" className="text-link">Create an account</Link></p>
      </form>
    </>
  );
}
