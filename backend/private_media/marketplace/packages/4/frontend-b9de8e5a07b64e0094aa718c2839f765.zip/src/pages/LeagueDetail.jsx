import React from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getLeague, getLeagueStandings, getSeasons } from "../api.js";
import Async, { Empty } from "../components/Async.jsx";
import LeagueMatches from "../components/league/LeagueMatches.jsx";
import LeagueOverview from "../components/league/LeagueOverview.jsx";
import LeagueStats from "../components/league/LeagueStats.jsx";
import LeagueTeams from "../components/league/LeagueTeams.jsx";
import FavoriteButton from "../components/FavoriteButton.jsx";
import RelatedNews from "../components/RelatedNews.jsx";
import StandingsTable from "../components/StandingsTable.jsx";
import TeamLogo from "../components/TeamLogo.jsx";
import { LEAGUE_TABS, leagueTab } from "../lib/league.js";
import { useListParams } from "../lib/useListParams.js";

function Standings({ leagueId, season }) {
  const query = useQuery({
    queryKey: ["league", leagueId, "standings", season],
    queryFn: () => getLeagueStandings(leagueId, { season: season || undefined }),
    retry: false,
  });
  if (query.isError && query.error?.response?.status === 404) return <Empty>No table available yet.</Empty>;
  return (
    <Async query={query}>
      {(data) => <><p className="muted note">Season {data.season.name}</p><StandingsTable rows={data.table} /></>}
    </Async>
  );
}

export default function LeagueDetail() {
  const { id } = useParams();
  const { params, page, update } = useListParams();
  const tab = leagueTab(params.get("tab"));
  const season = params.get("season") || "";

  const league = useQuery({ queryKey: ["league", id], queryFn: () => getLeague(id), staleTime: 300000 });
  const seasons = useQuery({ queryKey: ["league", id, "seasons"], queryFn: () => getSeasons({ league: id, page_size: 50 }), staleTime: 300000 });

  return (
    <Async query={league}>
      {(data) => (
        <>
          <div className="page-head">
            <div>
              <h1 className="inline"><TeamLogo team={data} size={40} /> {data.name}</h1>
              <div><small className="muted">{data.country}</small></div>
              <FavoriteButton kind="leagues" id={data.id} />
            </div>
            {(seasons.data?.results.length ?? 0) > 0 && (
              <select value={season} onChange={(e) => update({ season: e.target.value })} aria-label="Season">
                <option value="">Current season</option>
                {seasons.data.results.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            )}
          </div>

          <div className="tabs" role="tablist">
            {LEAGUE_TABS.map(([key, label]) => (
              <button key={key} type="button" role="tab" aria-selected={tab === key} className={tab === key ? "tab active" : "tab"} onClick={() => update({ tab: key === "overview" ? "" : key })}>{label}</button>
            ))}
          </div>

          {tab === "overview" && <LeagueOverview leagueId={id} season={season} onTab={(key) => update({ tab: key })} />}
          {tab === "fixtures" && <LeagueMatches leagueId={id} season={season} kind="fixtures" page={page} onPage={(p) => update({ page: p })} />}
          {tab === "results" && <LeagueMatches leagueId={id} season={season} kind="results" page={page} onPage={(p) => update({ page: p })} />}
          {tab === "standings" && <Standings leagueId={id} season={season} />}
          {tab === "teams" && <LeagueTeams leagueId={id} season={season} />}
          {tab === "statistics" && <LeagueStats leagueId={id} season={season} />}
          {tab === "overview" && <RelatedNews filter="league" id={id} />}
        </>
      )}
    </Async>
  );
}
