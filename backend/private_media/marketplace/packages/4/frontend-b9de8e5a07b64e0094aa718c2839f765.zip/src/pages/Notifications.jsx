import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Empty, ErrorBox, Loading } from "../components/Async.jsx";
import Pagination from "../components/Pagination.jsx";
import { KIND_ICONS, KIND_LABELS, SOURCE_LABELS, timeAgo } from "../lib/notifications.js";
import { useListParams } from "../lib/useListParams.js";
import { useDismiss, useMarkRead, useNotifications } from "../notifications/hooks.js";

const PAGE_SIZE = 20;

export default function Notifications() {
  const navigate = useNavigate();
  const { params, page, update } = useListParams();
  const unreadOnly = params.get("unread") === "1";
  const query = useNotifications({ page, unread: unreadOnly });
  const markRead = useMarkRead();
  const dismiss = useDismiss();

  function open(note) {
    if (!note.read) markRead.mutate({ ids: [note.id] });
    if (note.match) navigate(`/matches/${note.match}`);
  }

  return (
    <>
      <div className="page-head">
        <h1>Notifications</h1>
        <button type="button" className="secondary" onClick={() => markRead.mutate({ all: true })} disabled={markRead.isPending}>Mark all as read</button>
      </div>
      <div className="chips">
        <button type="button" className={unreadOnly ? "chip" : "chip active"} onClick={() => update({ unread: "" })}>All</button>
        <button type="button" className={unreadOnly ? "chip active" : "chip"} onClick={() => update({ unread: "1" })}>Unread</button>
        <Link to="/settings" className="chip">Settings</Link>
      </div>

      {query.isPending ? <Loading />
        : query.isError ? <ErrorBox error={query.error} onRetry={query.refetch} />
        : query.data.results.length === 0 ? (
          <Empty>
            {unreadOnly ? "You are all caught up." : <>Nothing yet. Follow a <Link to="/teams" className="text-link">team</Link> or <Link to="/leagues" className="text-link">league</Link> and goals, kick-offs and results will show up here.</>}
          </Empty>
        ) : (
          <>
            <div className="card list">
              {query.data.results.map((note) => (
                <div key={note.id} className={note.read ? "note" : "note unread"}>
                  <button type="button" className="note-main" onClick={() => open(note)}>
                    <span className="note-icon" aria-hidden="true">{KIND_ICONS[note.kind]}</span>
                    <span className="note-text">
                      <strong>{note.title}</strong>
                      {note.body && <span>{note.body}</span>}
                      <small className="muted">{KIND_LABELS[note.kind]} · {SOURCE_LABELS[note.source]} · {timeAgo(note.created_at)}</small>
                    </span>
                  </button>
                  <button type="button" className="note-dismiss" aria-label="Dismiss" onClick={() => dismiss.mutate(note.id)}>×</button>
                </div>
              ))}
            </div>
            <Pagination page={page} count={query.data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
    </>
  );
}
