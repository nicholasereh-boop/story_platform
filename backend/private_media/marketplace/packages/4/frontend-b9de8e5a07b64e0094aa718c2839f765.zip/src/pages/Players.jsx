import React from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getPlayers } from "../api.js";
import Async, { Empty } from "../components/Async.jsx";
import Pagination from "../components/Pagination.jsx";
import { PAGE_SIZE } from "../lib/format.js";
import { useListParams } from "../lib/useListParams.js";

export default function Players() {
  const { params, page, update } = useListParams();
  const q = params.get("q") || "";
  const query = useQuery({
    queryKey: ["players", page, q],
    queryFn: () => getPlayers({ page, search: q || undefined }),
    placeholderData: keepPreviousData,
  });
  return (
    <>
      <div className="page-head">
        <h1>Players</h1>
        <input type="search" value={q} onChange={(e) => update({ q: e.target.value })} placeholder="Search players" aria-label="Search players" />
      </div>
      <Async query={query}>
        {(data) => (
          <>
            {data.results.length === 0 ? <Empty>No players found.</Empty> : (
              <div className="card list">
                {data.results.map((player) => (
                  <Link key={player.id} to={`/players/${player.id}`} className="squad-row">
                    <span>{player.display_name}</span>
                    <small className="muted">{[player.position, player.current_team?.name].filter(Boolean).join(" · ")}</small>
                  </Link>
                ))}
              </div>
            )}
            <Pagination page={page} count={data.count} size={PAGE_SIZE} onChange={(p) => update({ page: p })} />
          </>
        )}
      </Async>
    </>
  );
}
