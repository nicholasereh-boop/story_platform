// Finds broken local imports before Vite does: files that do not exist, and named imports a file does not export.
// Run from the frontend folder:  node scripts/check-imports.mjs
import fs from "node:fs";
import path from "node:path";

const SRC = path.resolve("src");
const EXTENSIONS = ["", ".js", ".jsx", ".json", "/index.js", "/index.jsx"];
const problems = [];

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) return walk(full);
    return /\.(jsx?|mjs)$/.test(entry.name) ? [full] : [];
  });
}

function resolve(from, spec) {
  const base = path.resolve(path.dirname(from), spec);
  for (const ext of EXTENSIONS) {
    const candidate = base + ext;
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
  }
  return null;
}

const exportCache = new Map();
function exportsOf(file) {
  if (exportCache.has(file)) return exportCache.get(file);
  const text = fs.readFileSync(file, "utf8");
  const names = new Set();
  for (const m of text.matchAll(/export\s+(?:async\s+)?(?:const|let|var|function\*?|class)\s+([A-Za-z_$][\w$]*)/g)) names.add(m[1]);
  for (const m of text.matchAll(/export\s*\{([^}]*)\}/g)) {
    for (const part of m[1].split(",")) {
      const name = part.trim().split(/\s+as\s+/).pop();
      if (name) names.add(name);
    }
  }
  if (/export\s+default\b/.test(text)) names.add("default");
  exportCache.set(file, names);
  return names;
}

const IMPORT = /import\s+(?:([A-Za-z_$][\w$]*)\s*,?\s*)?(?:\{([^}]*)\})?\s*from\s*["'](\.{1,2}\/[^"']+)["']/g;

for (const file of walk(SRC)) {
  const text = fs.readFileSync(file, "utf8");
  const rel = path.relative(process.cwd(), file);
  for (const m of text.matchAll(IMPORT)) {
    const [, defaultName, named, spec] = m;
    const target = resolve(file, spec);
    if (!target) {
      problems.push(`${rel}: missing file  ${spec}`);
      continue;
    }
    if (!/\.(jsx?|mjs)$/.test(target)) continue;
    const available = exportsOf(target);
    if (defaultName && !available.has("default")) problems.push(`${rel}: ${spec} has no default export`);
    for (const part of (named || "").split(",")) {
      const name = part.trim().split(/\s+as\s+/)[0].trim();
      if (name && !available.has(name)) problems.push(`${rel}: ${spec} does not export "${name}"`);
    }
  }
  for (const m of text.matchAll(/import\(\s*["'](\.{1,2}\/[^"']+)["']\s*\)/g)) {
    if (!resolve(file, m[1])) problems.push(`${rel}: missing file  ${m[1]}`);
  }
}

if (problems.length === 0) {
  console.log("All local imports resolve.");
} else {
  console.log(`${problems.length} problem(s):\n` + problems.map((p) => "  " + p).join("\n"));
  process.exitCode = 1;
}
