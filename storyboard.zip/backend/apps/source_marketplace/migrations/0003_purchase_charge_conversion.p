from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('source_marketplace', '0002_project_description_videos'),
    ]

    operations = [
        migrations.AddField(
            model_name='sourcepurchase',
            name='fx_rate',
            field=models.DecimalField(blank=True, decimal_places=6, max_digits=16, null=True),
        ),
        migrations.AddField(
            model_name='sourcepurchase',
            name='list_currency',
            field=models.CharField(blank=True, max_length=3),
        ),
        migrations.AddField(
            model_name='sourcepurchase',
            name='list_price',
            field=models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True),
        ),
    ]