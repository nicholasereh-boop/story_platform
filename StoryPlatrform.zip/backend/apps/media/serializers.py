from rest_framework import serializers

from apps.accounts.utils import display_name

from .models import MediaAsset
from .services import asset_usage


class MediaAssetSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()
    uploaded_by = serializers.SerializerMethodField()

    class Meta:
        model = MediaAsset
        fields = [
            "id", "url", "file_type", "mime_type", "width", "height", "size_bytes",
            "alt_text", "caption", "uploaded_by", "created_at",
        ]

    def get_url(self, obj):
        return obj.file.url if obj.file else None  # relative on local disk, absolute with object storage

    def get_uploaded_by(self, obj):
        return display_name(obj.uploaded_by)


class MediaAssetDetailSerializer(MediaAssetSerializer):
    used_in = serializers.SerializerMethodField()

    class Meta(MediaAssetSerializer.Meta):
        fields = MediaAssetSerializer.Meta.fields + ["used_in"]

    def get_used_in(self, obj):
        return asset_usage(obj)


class MediaAssetUpdateSerializer(serializers.ModelSerializer):
    """Only the descriptive text may change. Everything else about an asset is derived from the file."""

    class Meta:
        model = MediaAsset
        fields = ["alt_text", "caption"]


class MediaCoverSerializer(serializers.ModelSerializer):
    """Compact form embedded in stories as `cover`."""

    url = serializers.SerializerMethodField()

    class Meta:
        model = MediaAsset
        fields = ["id", "url", "alt_text", "width", "height"]

    def get_url(self, obj):
        return obj.file.url if obj.file else None
